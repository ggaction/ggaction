import fs from 'node:fs/promises';
import path from 'node:path';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {testOptionalDependencies} from '../../scripts/consumers/optional-peers.js';
import {testNodeConsumer} from '../../scripts/consumers/node.js';
const packageSpec=JSON.parse(await fs.readFile('.artifacts/calendar/final-package.json')).file;
const consumer=await preparePackageConsumer({packageSpec});
try { await testOptionalDependencies(consumer); await testNodeConsumer(consumer.directory); console.log(JSON.stringify({node:process.version,packageSpec,status:'passed'})); }
finally { await fs.copyFile('.artifacts/consumers/node-cases.json',`.artifacts/calendar/installed-repair-${process.versions.node.split('.')[0]}.json`);await consumer.cleanup(); }
