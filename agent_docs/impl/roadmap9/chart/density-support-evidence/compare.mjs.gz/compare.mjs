import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createRouteDensityField } from '../../src/grammar/graph/routes/densityField.js';
import { createRouteBudget } from '../../src/grammar/graph/routes/budget.js';
const root=process.cwd(),oldFile=root+'/.artifacts/density-work/densityField-before.js';
const oldCode=fs.readFileSync(oldFile,'utf8').replace('"./polyline.js"',JSON.stringify(pathToFileURL(root+'/src/grammar/graph/routes/polyline.js').href));
const old=await import('data:text/javascript;base64,'+Buffer.from(oldCode).toString('base64'));
const hash=v=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
let oldWork=0,newWork=0;const hashes=[];
for(let seed=0;seed<120;seed++){
 const bounds={x:-.25,y:.125,width:1.5,height:.75},size=[8,17,65][seed%3],bandwidth=[.015625,.1,.3][Math.floor(seed/3)%3],directed=Boolean(seed%2);
 const samples=Array.from({length:3+seed%13},(_,i)=>({x:Math.sin(seed*1.1+i)*.85+.5,y:Math.cos(seed*.3+i*.75)*.6+.4,weight:i%7===0?0:(i+1)/32,angle:seed*.01+i*.7}));
 const a=createRouteBudget(),b=createRouteBudget(),before=old.createRouteDensityField(samples,bounds,{size,bandwidth,directed},a),after=createRouteDensityField(samples,bounds,{size,bandwidth,directed},b);
 const ah=hash([...before.cells]),bh=hash([...after.cells]);if(ah!==bh)throw Error('Field mismatch '+seed);
 oldWork+=a.diagnostics().work;newWork+=b.diagnostics().work;hashes.push(ah);
}
const publicSource=`
import fs from 'node:fs';import {registerHooks}from 'node:module';
if(process.env.DENSITY_BEFORE==='1')registerHooks({load(url,context,next){const r=next(url,context);return url.endsWith('/src/grammar/graph/routes/densityField.js')?{...r,source:fs.readFileSync(${JSON.stringify(oldFile)},'utf8')}:r;}});
const {normalizeObservedGraph}=await import('./src/grammar/graph/normalize.js');
const {bundleDensityRoutes}=await import('./src/grammar/graph/routes/density.js');const results=[];
for(let seed=0;seed<8;seed++){const points=[{x:0,y:0},{x:1,y:seed/1000},{x:0,y:.02+seed/1000},{x:1,y:.02}];
const model=normalizeObservedGraph(points.map((_,key)=>({key})),[{key:'a',sourceKey:0,targetKey:1},{key:'b',sourceKey:2,targetKey:3}],{directed:Boolean(seed%2),selfLoops:true});
const r=bundleDensityRoutes({model,positions:model.nodes.map((n,i)=>({key:n.key,...points[i]})),order:{nodes:[0,1,2,3],edges:['a','b']}});results.push({...r,diagnostics:{...r.diagnostics,work:0}});}
console.log(JSON.stringify(results));`;
const publicHashes=[];
for(const variant of ['1','0']){const r=spawnSync(process.execPath,['--input-type=module','-e',publicSource],{cwd:root,encoding:'utf8',env:{...process.env,DENSITY_BEFORE:variant},maxBuffer:50e6});if(r.status!==0)throw Error(r.stderr);publicHashes.push(hash(JSON.parse(r.stdout)));}
if(publicHashes[0]!==publicHashes[1])throw Error('Full solver mismatch');
console.log(JSON.stringify({fields:hashes.length,oldWork,newWork,fieldAggregate:hash(hashes),fullSolverCases:8,fullSolverHashes:publicHashes,comparison:'Exact ordered sparse entries and complete route outputs; only intentional work diagnostic excluded.'},null,2));
