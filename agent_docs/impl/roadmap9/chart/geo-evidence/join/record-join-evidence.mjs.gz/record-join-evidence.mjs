import fs from 'node:fs/promises';import path from'node:path';import {gzipSync}from'node:zlib';import {createHash}from'node:crypto';
const source='.artifacts/geo/join', destination='agent_docs/impl/roadmap9/chart/geo-evidence/join';await fs.mkdir(destination,{recursive:true});
const checks={};for(const name of ['unit-geo-1','unit-geo-2','types-boundaries-1','realistic-1','shared-resource-regressions','contracts-1','coverage-1','coverage-2','coverage-3','identity-equivalence','inventory-check','inventory-check-2','docs-first','docs-2','contracts-final','catalog-check','route-union','route-union-2']){
 const log=await fs.readFile(path.join(source,name+'.log'),'utf8');const last=field=>[...log.matchAll(new RegExp(`^# ${field} (\\d+)$`,'gm'))].at(-1)?.[1];checks[name]={tests:Number(last('tests')),pass:Number(last('pass')),fail:Number(last('fail'))};
}
const read=name=>fs.readFile(path.join(source,name+'.json'),'utf8').then(JSON.parse), artifact=await read('package'), inputs=await read('package-inputs');
const status={sourceBase:'7ee7821f9',scope:'Typed geographic joins: exact geometry/table correspondence, immutable revision closure, field inspection and offline restoration',approval:'AUTHORIZATION.json remainingApproval',checks,
 focusedCoverage:{tests:99,pass:99,lines:100,branches:98.21,functions:100,criticalOwners:33,floors:'Existing 95/90/100 Geo family floors unchanged; no global/full-suite coverage claim.'},
 archive:{sha256:artifact.sha256,entries:artifact.entryCount,packedBytes:artifact.size,unpackedBytes:artifact.unpackedSize,inputParity:await read('package-input-parity'),sourceInputDigest:createHash('sha256').update(JSON.stringify(inputs)).digest('hex')},
 installed:Object.fromEntries(await Promise.all(['20','22','24'].map(async major=>[major,await read('installed-'+major)]))),packageMeasurement:await read('package-limits'),bundleMeasurement:await read('bundle-limits'),
 documentation:{source:{tests:197,pass:197},build:'passed',built:{pages:172,machineArtifacts:1511},browser:'Desktop search/accessibility plus all documentation pages at 320/390/768 passed'},
 originalFailures:[
  'unit-geo-1: existing invalid-projection error wording expectation; original message preserved before unit-geo-2.',
  'coverage-1: all tests passed but topology branch absent; representative retained shared-arc join added.',
  'coverage-2: fixture expected duplicate-key failure during asynchronous prepare; actual validation belongs to applyDataUpdate. Corrected owning test; runtime unchanged.',
  'docs-first: missing new action CHANGELOG entries and measured search payload limit; docs-2 passed all 197.',
  'inventory-check: geo-join allocated namespaces were not normalized by the independent replay helper; narrow method support and rowMap/source/identity mutation regression added. Renderer-free ledger has four fewer requirements than default ledger. inventory-check-2 passed 10.',
  'route-union: responsive fixture fitted fixed Geo pixels outside the admitted plot. Explicit bounded projection viewport padding keeps them within the plot; runtime unchanged. route-union-2 passed 33.'
 ],
 integrationObligations:['Root executes common realistic-lifecycle-factor-effects.test.js, realistic-scenario-generator.test.js, realistic-scenario-generation-isolation.test.js once on combined integration.','Shared-arc/hierarchy LOD, geographic field encodings, guides/labels, camera and current-frame consumers remain assigned STEP045–046 scope.'],
 checksNotRepeated:['No full unit/contracts/global coverage sweep; affected canonical checks plus focused coverage are recorded separately.','No repeated whole installed consumer corpus; same-tar focused new runtime, strict types, executable docs and five browser bundle qualifications.']};
await fs.writeFile(path.join(destination,'status.json'),JSON.stringify(status,null,2)+'\n');
const files=await fs.readdir(source), manifest=[];for(const name of files.filter(name=>/\.(?:log|json)$/.test(name))){const bytes=await fs.readFile(path.join(source,name));await fs.writeFile(path.join(destination,name+'.gz'),gzipSync(bytes,{level:9,mtime:0}));manifest.push({file:name+'.gz',sourceBytes:bytes.length,sourceSha256:createHash('sha256').update(bytes).digest('hex')});}
for(const name of ['join-installed.mjs','run-join-installed.mjs','measure-join-package.mjs','record-join-evidence.mjs']){const bytes=await fs.readFile(path.join('.artifacts/geo',name));await fs.writeFile(path.join(destination,name+'.gz'),gzipSync(bytes,{level:9,mtime:0}));manifest.push({file:name+'.gz',sourceBytes:bytes.length,sourceSha256:createHash('sha256').update(bytes).digest('hex')});}
await fs.writeFile(path.join(destination,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');console.log({checks,archive:status.archive});
