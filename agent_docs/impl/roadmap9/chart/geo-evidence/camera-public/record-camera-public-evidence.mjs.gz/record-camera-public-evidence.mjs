import fs from 'node:fs/promises';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const root='.artifacts/geo', data=path.join(root,'camera-public');
const dest='agent_docs/impl/roadmap9/chart/geo-evidence/camera-public';
await fs.mkdir(dest,{recursive:true});
const read=async file=>JSON.parse(await fs.readFile(path.join(data,file),'utf8'));
const artifact=await read('package.json');
const status={
 scope:'명시적 native projection camera action과 읽기 전용 view snapshot',
 base:'9c8193c94',approval:'AUTHORIZATION.json remainingApproval: STEP077 전체 설계·시각 승인 재사용',
 checks:{
  geo:{tests:178,pass:178},ownerCoverage:{tests:23,pass:23,owners:['actions/geo/camera.js','grammar/geo/camera.js','grammar/geo/cameraInterpolation.js'],coverage:[100,100,100],unchangedFloor:[95,90,100]},
  sourcePackageTypesCards:{tests:52,pass:52},snapshotPackageBoundaries:{tests:16,pass:16},packageContracts:{tests:7,pass:7},
  actualData:{tests:16,pass:16,datasets:5,recipesPerDataset:3},inventory:{tests:10,pass:10},
  primitive:{tests:5,pass:5},renderers:{tests:10,pass:10,backends:['Canvas','SVG','PNG','PDF']},browser:{tests:5,pass:5,backends:['Canvas','SVG'],dpr:[1,2]},
  snippets:{tests:111,pass:111},sourceDocs:{initial:{tests:202,pass:197},afterMetadata:{tests:202,pass:200},final:'pending source pin'},
  builtDocs:{beforeSourcePin:{pages:172,llmArtifacts:1529,responsiveWidths:[320,390,768]},final:'pending source pin'}
 },
 package:{sha256:artifact.sha256,entries:artifact.entryCount,packedBytes:artifact.size,unpackedBytes:artifact.unpackedSize,
  limits:{entries:1039,packedBytes:1476000,unpackedBytes:6718000,fullBundleGzip:728000},
  measurements:await Promise.all([20,22,24].map(major=>read(`package-size-${major}.json`))),
  inputParity:await read('package-input-parity.json'),
  installed:await Promise.all([20,22,24].map(major=>read(`installed-${major}.json`))),
  finalSnippet:await read('final-snippet.json')},
 commands:[
  'node --test test/unit/geo/*.test.js',
  'node --experimental-test-coverage --test-coverage-include=src/actions/geo/camera.js --test-coverage-include=src/grammar/geo/camera.js --test-coverage-include=src/grammar/geo/cameraInterpolation.js --test test/unit/geo/camera-actions.test.js test/unit/geo/camera.test.js',
  'node scripts/run-tests.js realistic contracts/realistic-geographic-camera.test.js',
  'node scripts/run-tests.js realistic contracts/generated-lifecycle-scenarios.test.js contracts/generated-scenario-feature-coverage.test.js',
  'node scripts/run-tests.js charts charts/geographic-marks/public.test.js',
  'node scripts/run-render-tests.js charts/geographic-marks/backends.render.js',
  'node scripts/run-tests.js browser browser/geographic-marks.browser.js',
  'node .artifacts/geo/run-camera-public-installed.mjs',
  'node .artifacts/geo/camera-public-package-parity.mjs'
 ],
 repairs:[
  '최초 회전 fixture의 coordinateKind 누락(7/8), 카드 sample operation 누락(45/46), inventory 기대 action 수(8/10)는 fixture/metadata를 고쳐 검증했다.',
  '기존 fields primitive에 실수로 추가된 camera argument를 원복하여 chart 4/5, render 8/10, browser 4/5를 각각 5/5, 10/10, 5/5로 회복했다.',
  '문서 첫197/202는 search cap·provenance·source pin·empty Canvas snippet 문제였다. Search 실측에 맞춘 cap, 생성물 및 resource-only snippet을 고쳤다. Source pin은 푸시 이후 별도 최종 검증한다.',
  '설치용 최초 relative output directory 및 미생성 archive 실패는 패키지 harness 문제이며 실제 제품 시험이 아니다. 절대 경로로 생성한 같은 tar의 세 Node 검사는 모두 통과했다.'
 ],
 limits:[
  '전체 unit/global coverage를 새로 실행했다고 주장하지 않는다. Geo와 camera owner 및 영향 범위 검증이다.',
  'Canvas 없는 resource-only view의 viewport는 null이며 초기 baseline은 caller가 보존한다. 저장 camera 상태나 자동 추론 zoom은 없다.',
  'Session gesture/history/keyboard/abort와 root generic player/current-frame hit/reduced-motion 연결은 후행 소비자 의무다.',
  'Conditional resource-grain fields와 feature/graticule labels는 다음 Geo 개념으로 남는다.',
  'buildDirectDataResources에 native pan이 추가됐다. 공통 realistic-lifecycle-factor-effects, realistic-scenario-generator, realistic-scenario-generation-isolation의 최종 합산 재검증은 root가 수행한다.'
 ]
};
try{const previous=JSON.parse(await fs.readFile(path.join(dest,'status.json'),'utf8'));for(const key of ['sourceCommit','metadataFollowup'])if(previous[key])status[key]=previous[key];for(const key of ['sourceDocs','builtDocs'])if(previous.checks[key]?.final?.pass||previous.checks[key]?.final?.pages)status.checks[key]=previous.checks[key];}catch{}
const manifest=[];
async function retain(file,name){const bytes=await fs.readFile(file);await fs.writeFile(path.join(dest,name+'.gz'),gzipSync(bytes,{level:9,mtime:0}));manifest.push({file:name+'.gz',sourceBytes:bytes.length,sourceSha256:createHash('sha256').update(bytes).digest('hex')});}
for(const name of(await fs.readdir(root)).filter(name=>name.startsWith('camera-')&&/\.(?:log|json|mjs)$/.test(name)&&!/(?:kernel|node20|node24)/.test(name)))await retain(path.join(root,name),name);
for(const name of(await fs.readdir(data)).filter(name=>/\.(?:log|json)$/.test(name)))await retain(path.join(data,name),name);
for(const name of ['record-camera-public-evidence.mjs','run-camera-public-installed.mjs','measure-camera-public-package.mjs','measure-camera-public-bundles.mjs'])await retain(path.join(root,name),name);
await fs.writeFile(path.join(dest,'status.json'),JSON.stringify(status,null,2)+'\n');
await fs.writeFile(path.join(dest,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log({files:manifest.length,archive:artifact.sha256});
