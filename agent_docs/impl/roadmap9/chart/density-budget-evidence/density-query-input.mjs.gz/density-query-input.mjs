import{sampleRouteGradient}from'./src/grammar/graph/routes/densityField.js';import{chart}from'./src/index.js';import{prepareGraphEdgeRoutes}from'./src/graph.js';function fixture(edgeCount, method) {
  const count = method === 'hierarchical' ? Math.min(edgeCount, 9999) : edgeCount;
  const nodes = Array.from({ length: count }, (_, id) => ({ id }));
  const edges = Array.from({ length: edgeCount }, (_, id) => ({ id, source: id % count, target: (id + Math.floor(count / 3)) % count }));
  let p = chart().createCanvas({ width: 400, height: 400, margin: 0, background: 'white' }), positions, options;
  if (method === 'hierarchical') {
    p = p.createData({ id: 'tree', values: [{ key: 'root', parent: null, value: 0 }, ...nodes.map(({ id }) => ({ key: id, parent: 'root', value: 1 }))] })
      .createHierarchyData({ id: 'hierarchy', data: 'tree', key: 'key', parent: 'parent', value: 'value' })
      .layoutHierarchy({ id: 'tree-layout', method: 'tree', options: { nodeSize: [1, 1], siblingGap: 1, depthGap: 100, orientation: 'vertical' } });
    const hierarchy = p.semanticSpec.resources.find(r => r.kind === 'hierarchy');
    const anchors = new Map(p.semanticSpec.resources.find(r => r.kind === 'layout').result.nodes.map(node => [node.key, node]));
    positions = hierarchy.result.nodes.filter(node => node.depth === 1).map(node => ({ key: nodes[node.sourceRows[0] - 1].id, x: anchors.get(node.key).x, y: anchors.get(node.key).y }));
    options = { hierarchy: 'hierarchy', hierarchyLayout: 'tree-layout', mapping: nodes.map(({ id }) => ({ nodeKey: id, hierarchyKey: id })) };
  } else positions = nodes.map(({ id }) => ({ key: id, x: 200 + 150 * Math.cos(2 * Math.PI * id / count), y: 200 + 150 * Math.sin(2 * Math.PI * id / count) }));
  p = p.createData({ id: 'nodes', values: nodes, keyField: 'id' }).createData({ id: 'edges', values: edges, keyField: 'id' })
    .createGraphData({ id: 'graph', nodes: 'nodes', edges: 'edges', nodeKey: 'id', edgeKey: 'id', source: 'source', target: 'target' })
    .layoutGraph({ id: 'layout', method: 'fixed', options: { positions } });
  return { program: p, request: { kind: 'create', id: 'routes', graph: 'graph', layout: 'layout', method, ...(options ? { options } : {}) }, nodes: count };
}

function analyze(routes,samples,bounds,{size,bandwidth,directed}) {
 if(directed)throw new Error("This audit requires the original undirected fixture");
 const dx=bounds.width/(size-1),dy=bounds.height/(size-1),needed=new Set(),neededGradients=new Set();
 let interiorSamples=0;
 for(const points of routes)for(let i=1;i<points.length-1;i++){
  interiorSamples++;
  const gx=Math.max(0,Math.min(size-1,(points[i].x-bounds.x)/dx)),gy=Math.max(0,Math.min(size-1,(points[i].y-bounds.y)/dy));
  const x=Math.min(size-2,Math.floor(gx)),y=Math.min(size-2,Math.floor(gy));
  for(const [cx,cy]of[[x,y],[x+1,y],[x,y+1],[x+1,y+1]])neededGradients.add(cy*size+cx);
  for(const [cx,cy]of[[x,y],[x+1,y],[x,y+1],[x+1,y+1]])for(const [sx,sy]of[[Math.max(0,cx-1),cy],[Math.min(size-1,cx+1),cy],[cx,Math.max(0,cy-1)],[cx,Math.min(size-1,cy+1)]])needed.add(sy*size+sx);
 }
 const prefixes=Array.from({length:size},(_,y)=>{const p=new Uint32Array(size+1);for(let x=0;x<size;x++)p[x+1]=p[x]+Number(needed.has(y*size+x));return p;});
 let rows=0,candidates=0,queriedCandidates=0;
 const endpointLowerBound=routes.reduce((total,p)=>total+Math.max(2,Math.ceil(Math.hypot(p.at(-1).x-p[0].x,p.at(-1).y-p[0].y)/Math.min(bandwidth/4,1/256))+1),0);
 for(const s of samples){if(s.weight===0)continue;
  const x0=Math.max(0,Math.ceil((s.x-bandwidth-bounds.x)/dx)),x1=Math.min(size-1,Math.floor((s.x+bandwidth-bounds.x)/dx));
  const y0=Math.max(0,Math.ceil((s.y-bandwidth-bounds.y)/dy)),y1=Math.min(size-1,Math.floor((s.y+bandwidth-bounds.y)/dy));
  for(let y=y0;y<=y1;y++){rows++;const deltaY=bounds.y+y*dy-s.y;const radius=Math.sqrt(Math.max(0,(bandwidth-Math.abs(deltaY))*(bandwidth+Math.abs(deltaY))));const first=Math.max(x0,Math.ceil((s.x-radius-bounds.x)/dx)-1),last=Math.min(x1,Math.floor((s.x+radius-bounds.x)/dx)+1);const count=Math.max(0,last-first+1);candidates+=count;if(count)queriedCandidates+=prefixes[y][last+1]-prefixes[y][first];}
 }
 const actualKeys=new Set();let actualReads=0;
 const actualField={bounds,size,dx,dy,directed:false,cells:{get(key){actualReads++;actualKeys.add(key);return 0;}}};
 for(const points of routes)for(let i=1;i<points.length-1;i++)sampleRouteGradient(actualField,points[i],0);
 if(actualReads!==interiorSamples*16||actualKeys.size!==needed.size||[...actualKeys].some(key=>!needed.has(key)))throw new Error('Independent query keys differ from actual scalar owner');
 return {directed,samples:samples.length,interiorSamples,actualReads,gradientCalls:interiorSamples*4,uniqueGradients:neededGradients.size,endpointLowerBound,twentyBaseAtEndpointCount:endpointLowerBound*24*20,neededCells:needed.size,gridCells:size*size,rows,candidates,queriedCandidates,unqueriedCandidates:candidates-queriedCandidates,queriedFraction:queriedCandidates/candidates};
}
for(const size of [100,1000]){globalThis.__capture=(...args)=>{console.log(JSON.stringify({size,iteration:0,...analyze(...args)}));};const made=fixture(size,'density');try{await prepareGraphEdgeRoutes(made.program,made.request,{requestToken:'query-audit'});}catch(e){if(e.message!=='diagnostic captured before field')throw e;}}