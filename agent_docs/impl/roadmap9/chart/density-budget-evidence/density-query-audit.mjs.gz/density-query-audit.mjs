import { build } from 'esbuild';
import { readFile,writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
const canonical=execFileSync('git',['show','0bd402486:scripts/benchmarks/routes.browser.js'],{encoding:'utf8'});
const fixture=canonical.slice(canonical.indexOf('function fixture('),canonical.indexOf('const percentile'));
function analyze(routes,samples,bounds,{size,bandwidth,directed}) {
 if(directed)throw new Error("This audit requires the original undirected fixture");
 const dx=bounds.width/(size-1),dy=bounds.height/(size-1),needed=new Set(),neededGradients=new Set();
 let interiorSamples=0;
 for(const points of routes)for(let i=1;i<points.length-1;i++){
  interiorSamples++;
  const gx=Math.max(0,Math.min(size-1,(points[i].x-bounds.x)/dx)),gy=Math.max(0,Math.min(size-1,(points[i].y-bounds.y)/dy));
  const x=Math.min(size-2,Math.floor(gx)),y=Math.min(size-2,Math.floor(gy));
  for(const [cx,cy]of[[x,y],[x+1,y],[x,y+1],[x+1,y+1]])neededGradients.add(cy*size+cx);
  for(const [cx,cy]of[[x,y],[x+1,y],[x,y+1],[x+1,y+1]])for(const [sx,sy]of[[Math.max(0,cx-1),cy],[Math.min(size-1,cx+1),cy],[cx,Math.max(0,cy-1)],[cx,Math.min(size-1,cy+1)]])needed.add(sy*size+sx);
 }
 const prefixes=Array.from({length:size},(_,y)=>{const p=new Uint32Array(size+1);for(let x=0;x<size;x++)p[x+1]=p[x]+Number(needed.has(y*size+x));return p;});
 let rows=0,candidates=0,queriedCandidates=0;
 const endpointLowerBound=routes.reduce((total,p)=>total+Math.max(2,Math.ceil(Math.hypot(p.at(-1).x-p[0].x,p.at(-1).y-p[0].y)/Math.min(bandwidth/4,1/256))+1),0);
 for(const s of samples){if(s.weight===0)continue;
  const x0=Math.max(0,Math.ceil((s.x-bandwidth-bounds.x)/dx)),x1=Math.min(size-1,Math.floor((s.x+bandwidth-bounds.x)/dx));
  const y0=Math.max(0,Math.ceil((s.y-bandwidth-bounds.y)/dy)),y1=Math.min(size-1,Math.floor((s.y+bandwidth-bounds.y)/dy));
  for(let y=y0;y<=y1;y++){rows++;const deltaY=bounds.y+y*dy-s.y;const radius=Math.sqrt(Math.max(0,(bandwidth-Math.abs(deltaY))*(bandwidth+Math.abs(deltaY))));const first=Math.max(x0,Math.ceil((s.x-radius-bounds.x)/dx)-1),last=Math.min(x1,Math.floor((s.x+radius-bounds.x)/dx)+1);const count=Math.max(0,last-first+1);candidates+=count;if(count)queriedCandidates+=prefixes[y][last+1]-prefixes[y][first];}
 }
 const actualKeys=new Set();let actualReads=0;
 const actualField={bounds,size,dx,dy,directed:false,cells:{get(key){actualReads++;actualKeys.add(key);return 0;}}};
 for(const points of routes)for(let i=1;i<points.length-1;i++)sampleRouteGradient(actualField,points[i],0);
 if(actualReads!==interiorSamples*16||actualKeys.size!==needed.size||[...actualKeys].some(key=>!needed.has(key)))throw new Error('Independent query keys differ from actual scalar owner');
 return {directed,samples:samples.length,interiorSamples,actualReads,gradientCalls:interiorSamples*4,uniqueGradients:neededGradients.size,endpointLowerBound,twentyBaseAtEndpointCount:endpointLowerBound*24*20,neededCells:needed.size,gridCells:size*size,rows,candidates,queriedCandidates,unqueriedCandidates:candidates-queriedCandidates,queriedFraction:queriedCandidates/candidates};
}
const entry=`import{sampleRouteGradient}from'./src/grammar/graph/routes/densityField.js';import{chart}from'./src/index.js';import{prepareGraphEdgeRoutes}from'./src/graph.js';${fixture}\n${analyze.toString()}\nfor(const size of [100,1000]){globalThis.__capture=(...args)=>{console.log(JSON.stringify({size,iteration:0,...analyze(...args)}));};const made=fixture(size,'density');try{await prepareGraphEdgeRoutes(made.program,made.request,{requestToken:'query-audit'});}catch(e){if(e.message!=='diagnostic captured before field')throw e;}}`;
const result=await build({stdin:{contents:entry,resolveDir:process.cwd(),sourcefile:'density-query-input.mjs'},bundle:true,format:'esm',platform:'node',target:'node22',packages:'external',write:false,plugins:[{name:'capture-only',setup(b){b.onLoad({filter:/src\/grammar\/graph\/routes\/density\.js$/},async({path:file})=>({contents:(await readFile(file,'utf8')).replace('const field = createRouteDensityField',`globalThis.__capture(routes,flat,densityBounds(flat,bandwidth),{size:GRID_SIZE,bandwidth,directed:context.model.directed});throw new Error('diagnostic captured before field');const field = createRouteDensityField`),loader:'js',resolveDir:path.dirname(file)}));}}]});
await writeFile('.artifacts/density-query-input.mjs',entry);await writeFile('.artifacts/density-query-bundle.mjs',result.outputFiles[0].text);
