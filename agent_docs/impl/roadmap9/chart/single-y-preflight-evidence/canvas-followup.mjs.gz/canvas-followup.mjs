import assert from 'node:assert/strict';
import { chart } from '../../src/index.js';
const Base = chart().constructor;
let armed = false;
const calls = [];
class CapturingProgram extends Base {
  editGraphics(args) {
    if (armed) calls.push({ op: 'editGraphics', target: args.target, property: args.property });
    return super.editGraphics(args);
  }
}
const rows = [{ x: 1, y: 2 }, { x: 2, y: 3 }];
let source = new CapturingProgram().createCanvas({ width: 500, height: 300, margin: 20 })
  .createData({ id: 'rows', values: rows });
for (const [id, alignX] of [['left', 'start'], ['right', 'end']]) {
  source = source.createCoordinate({ id })
    .editCoordinate({ target: id, aspect: { mode: 'frame', ratio: 0.4, alignX } })
    .createScatterPlot({ id, data: 'rows', coordinate: id,
      x: { field: 'x', scale: { id: `${id}X` } }, y: { field: 'y', scale: { id: `${id}Y` } }, guides: false });
}
const before = JSON.stringify(source);
armed = true;
let error;
try { source.editCanvas({ width: 100 }); } catch (caught) { error = caught.message; }
assert.match(error, /overlaps an independent/);
assert.equal(JSON.stringify(source), before);
armed = false;
assert.doesNotThrow(() => source.editCanvas({ width: 600 }));
const annotation = chart().createCanvas({ width: 500, height: 300, margin: 20 })
  .createData({ values: rows }).createScatterPlot({ x: 'x', y: 'y', guides: false })
  .createAnnotation({ id: 'note', text: 'Note', space: 'plot', x: 0.5, y: 0.5 });
assert.doesNotThrow(() => annotation.editCanvas({ width: 400 }));
console.log(JSON.stringify({ status: 'root-integration-followup', rejected: { input: { width: 100 }, error, observedChildren: calls },
  controls: { separatedFrames: { width: 600, pass: true }, normalizedPlotAnnotation: { width: 400, pass: true } },
  pendingOnLatestMain: [
    'Reject newly overlapping prospective frame bounds before the first child.',
    'Preserve non-overlapping frames and wrapped materialization steps.',
    'Validate Routes viewport preparation and typed resource revisions against the same prospective Canvas before replacement.',
    'Keep source-owned labels, literal annotations, normalized plot anchors and detached snapshots outside data-Y admission.',
    'Use the responsive final derived plot bounds, including nested facet/concat child placement.'
  ] }, null, 2));
