import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {REALISTIC_LIFECYCLE_SCENARIO_RECIPES} from '../test/support/scenarios/lifecycle-recipes.js';
import {inspectAnalyticLayerIntegrity} from '../test/oracles/analytic-layer-integrity.js';
import {releaseTidyTuesdaySourceCache} from '../test/support/datasets/tidytuesday.js';
const oldSource=execFileSync('git',['show','c749a4f40:test/oracles/analytic-layer-integrity.js'],{encoding:'utf8'});
const old=await import(`data:text/javascript;base64,${Buffer.from(oldSource).toString('base64')}`);
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const recipe=REALISTIC_LIFECYCLE_SCENARIO_RECIPES.find(r=>r.id==='realistic-action-direct-data-resources');
const records=[];
for(const factors of [
 {dataset:'tt-new-zealand-names',width:1040,background:'#f8fafc',bandwidth:.7,steps:48,bins:5,includeEmpty:true},
 {dataset:'tt-global-temperatures',width:920,background:'#ffffff',bandwidth:.35,steps:24,bins:3,includeEmpty:false}
]) {
 try {
  const program=recipe.build(factors),source=program.children.trail.semanticSpec.datasets.find(d=>d.id==='trailSource');
  const graphic=program.children.trail.graphicSpec.objects.directTrail;
  const before={source:hash(source.values),graphic:hash(graphic)};
  const previous=old.inspectAnalyticLayerIntegrity(program),current=inspectAnalyticLayerIntegrity(program);
  assert.equal(previous.issues.length,1);assert.match(previous.issues[0],/directTrail.*no finite, non-zero geometry/);
  assert.deepEqual(current.issues,[]);
  assert.deepEqual(before,{source:hash(source.values),graphic:hash(graphic)});
  records.push({dataset:factors.dataset,factors,sourceRows:source.values.length,sourceValuesSha256:before.source,
   graphicSha256:before.graphic,trailItems:graphic.items.length,strokeWidths:[...new Set(graphic.items.map(i=>i.properties.strokeWidth))],
   previousIssues:previous.issues,currentIssues:current.issues,metrics:current.metrics,sourceAndGeometryMutated:false});
 }finally {releaseTidyTuesdaySourceCache(factors.dataset)}
}
writeFileSync('.artifacts/trail-corpus-proof.json',JSON.stringify({baseline:'c749a4f40',runtimeDelta:0,records},null,2)+'\n');
console.log(JSON.stringify(records,null,2));
