import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { preparePackageConsumer } from '../scripts/package-consumer.js';
import { testOptionalDependencies } from '../scripts/consumers/optional-peers.js';
import { documentationPrograms, copyDocumentationSupportFiles } from '../scripts/doc-snippets.js';
const tar='/Users/hyeonjeon/.codex/worktrees/roadmap9-integration/ggactionnewbrand/.artifacts/integration-archives/ggaction-3364bce3f7fad099c1e7adb25e8a4f0d88dfc8841ed285b0d0c129c8da0e1451.tgz';
const sha=createHash('sha256').update(await readFile(tar)).digest('hex');
const c=await preparePackageConsumer({packageSpec:tar}),records=[];
try {
 await testOptionalDependencies(c);
 const examples=(await documentationPrograms()).filter(e=>/^recipes\/(marginal|bullet|combo)\.md$/.test(e.file));
 for(const e of examples){
  const dir=c.directory+'/'+e.file.replace(/\W/g,'-');await mkdir(dir);await copyDocumentationSupportFiles(e,dir);
  const code=`import assert from 'node:assert/strict';import{createCanvas}from'@napi-rs/canvas';const canvas=createCanvas(1,1);const document={querySelector(s){assert.equal(s,'#chart');return canvas;}};\n${e.code}\nassert.ok(canvas.width>1&&canvas.height>1);const pixels=canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height).data;assert.ok(pixels.some((v,i)=>i%4!==3&&v<200));assert.match(import.meta.resolve('ggaction'),/node_modules\\/ggaction/);`;
  await writeFile(dir+'/main.mjs',code);execFileSync(process.execPath,['main.mjs'],{cwd:dir,stdio:'inherit'});records.push({file:e.file,sha256:e.sha256,status:'passed'});
 }
 await writeFile('.artifacts/composition-recipes-snippets-installed.json',JSON.stringify({node:process.versions.node,sha,records},null,2)+'\n');
} finally {await c.cleanup();}
