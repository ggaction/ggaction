import { readFile, writeFile, copyFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { preparePackageConsumer } from '../scripts/package-consumer.js';
import { testOptionalDependencies } from '../scripts/consumers/optional-peers.js';
import { copyCompositionRecipeExamples } from '../scripts/consumers/composition-recipes.js';
const tar='/Users/hyeonjeon/.codex/worktrees/roadmap9-integration/ggactionnewbrand/.artifacts/integration-archives/ggaction-3364bce3f7fad099c1e7adb25e8a4f0d88dfc8841ed285b0d0c129c8da0e1451.tgz';
const sha=createHash('sha256').update(await readFile(tar)).digest('hex');
if(sha!=='3364bce3f7fad099c1e7adb25e8a4f0d88dfc8841ed285b0d0c129c8da0e1451')throw Error('Artifact changed');
const c=await preparePackageConsumer({packageSpec:tar});
try {
 await testOptionalDependencies(c); await copyCompositionRecipeExamples(c.directory);
 await copyFile('scripts/consumers/fixtures/node/composition-recipes.mjs',c.directory+'/composition-recipes.mjs');
 await writeFile(c.directory+'/run.mjs',`import{cases}from'./composition-recipes.mjs';import{writeFile}from'node:fs/promises';const records=[];for(const c of cases){const t=performance.now();try{await c.run();records.push({id:c.id,status:'passed',durationMs:performance.now()-t});}catch(e){records.push({id:c.id,status:'failed',error:e.stack});}}await writeFile('receipt.json',JSON.stringify(records,null,2));if(records.some(r=>r.status==='failed'))process.exitCode=1;`);
 let error;try{execFileSync(process.execPath,['run.mjs'],{cwd:c.directory,stdio:'inherit'});}catch(e){error=e;}
 const records=JSON.parse(await readFile(c.directory+'/receipt.json','utf8'));
 await writeFile(`.artifacts/composition-recipes-installed-${process.versions.node}.json`,JSON.stringify({node:process.versions.node,sha,sourceCandidate:'69089faccecc0e2de8429a78c4f85c663b8ab621',scope:'Current integration artifact; not final STEP077 release qualification',peers:c.resolvedPeers,records},null,2)+'\n');
 console.log(JSON.stringify(records));if(error)throw error;
} finally {await c.cleanup();}
