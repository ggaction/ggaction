import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.cwd(), entry=file=>import(pathToFileURL(path.join(root,file)));
const {preparePackageConsumer}=await entry('scripts/package-consumer.js');
const {testTypeScriptConsumer}=await entry('scripts/consumers/types.js');
const {testOptionalDependencies}=await entry('scripts/consumers/optional-peers.js');
const {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS}=await entry('scripts/browser-bundle-size.js');
const tar=path.resolve(process.argv[2]),consumer=await preparePackageConsumer({packageSpec:tar});
try {
 await testOptionalDependencies(consumer);
 const source=(await readFile('test/unit/grammar/financial-roles.test.js','utf8')).replace('../../../src/grammar/ohlc.js','./node_modules/ggaction/src/grammar/ohlc.js').replace('../../../src/grammar/waterfall.js','./node_modules/ggaction/src/grammar/waterfall.js').replace('../../oracles/geometry.js','./geometry.js');
 await writeFile(path.join(consumer.directory,'financial.test.mjs'),source);
 await copyFile('test/oracles/geometry.js',path.join(consumer.directory,'geometry.js'));
 process.stdout.write(execFileSync(process.execPath,['--test','financial.test.mjs'],{cwd:consumer.directory,encoding:'utf8'}));
 const files=['observed-graphs.mjs','inferred-graphs.mjs','contours.mjs','interaction.mjs','logical-selection.mjs','calendar-plots.mjs','responsive-guides.mjs','nested-responsive.mjs','edge-routes.mjs'];
 for(const [file,example]of[['responsive-public.js','responsive-guides'],['nested-responsive-public.js','nested-responsive']])await writeFile(path.join(consumer.directory,file),(await readFile(path.join('examples',example,'program.js'),'utf8')).replace('"../../src/index.js"','"ggaction"'));
 for(const file of files)await copyFile(path.join('scripts/consumers/fixtures/node',file),path.join(consumer.directory,file));
 await writeFile(path.join(consumer.directory,'verify.mjs'),'const records=[];for(const file of '+JSON.stringify(files)+'){const {cases}=await import("./"+file);for(const entry of cases){await entry.run();records.push({id:entry.id,status:"passed"})}}console.log(JSON.stringify(records));');
 const records=JSON.parse(execFileSync(process.execPath,['verify.mjs'],{cwd:consumer.directory,encoding:'utf8'}));
 await testTypeScriptConsumer(consumer.directory);
 const bundles={};for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)){
  const result=await measureMinimalBrowserBundle(consumer.directory,{specifier});
  if(result.gzipBytes>BROWSER_BUNDLE_GZIP_LIMITS[specifier])throw new Error(specifier+' budget exceeded');
  bundles[specifier]=result;
 }
 const result={node:process.version,tar,kernelTests:8,records,types:'passed',optionalPeers:consumer.resolvedPeers,bundles};
 await writeFile(path.resolve(process.argv[3]),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await consumer.cleanup()}
