from pathlib import Path
import json,gzip,hashlib,re,subprocess
p=Path('.artifacts/inference-execution-merged');out=Path('agent_docs/impl/roadmap9/qualification/inference-execution-merged-evidence');out.mkdir(exist_ok=True)
checks={}
for f in ['owning.log','contracts.log','coverage-policy.log','docs.log']:
 s=(p/f).read_text();assert '# fail 0' in s,f;checks[f]=int(re.search(r'# tests (\d+)',s)[1])
a=json.loads((p/'frozen.json').read_text());installed=[]
for n in [20,22,24]:
 r=json.loads((p/f'installed-{n}.json').read_text());assert r['status']=='passed' and r['sha256']==a['sha256'];assert len(r['checks'])==3 and all(x['status']=='passed' for x in r['checks']);installed.append(r)
for n in [20,22,24]:assert json.loads((p/f'pack{n}.json').read_text())['entryCount']==1246
same=json.loads((p/'source-equality.json').read_text());assert same['different']==[] and len(same['files'])==16
files={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.stderr','.mjs','.py']:
  raw=f.read_bytes();(out/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[f.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q={'status':'explicit-inference-policy-integrated; worker-and-final-native-qualification-pending','base':'ee7a9d739','incoming':'2f768950d','approval':'../../AUTHORIZATION.json#remainingApproval','archive':a,'sourceInputEquality':same,'checks':checks,'installed':installed,'built':{'pages':186,'selectiveArtifacts':1604,'status':'passed'},'coverageReuse':{'sourceIdenticalTo':'2f768950d','criticalOwners':16,'source':'../inference-execution-evidence/critical.json','newCoverageRunClaimed':False},'limits':{'entries':1246,'packedBytes':1791600,'unpackedBytes':8062400,'FullGzip':785500,'searchBytes':1091600},'reuse':{'upstreamLargeEditableCodec':'86,871,543 bytes exact roundtrip; program codec has no global 64MiB cap','browser':'Unchanged UI/renderer; prior root handles/point and upstream inference docs browser evidence reused. No new whole-browser run claimed.'},'pending':['Dedicated inference worker integration','Original AT82 large performance P95/heap/100-cycle qualification','Final combined candidate required suites'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
(out/'README.md').write_text('''# 명시 inferred graph 실행 정책 통합\n\n기존 remainingApproval과32c26e969 구체안 채택을 재사용했다. 원10000nodes/k10 전체100000간선과 source rows·방향·typed key를 보존한다. 기본10M과 일반 layout/graphic/route 한도는 유지하며 명시 owner별 execution 정책만 전달한다. Native receiver/state와 renderer 경계는 기존대로다.\n\n루트 source210, contracts31, coverage-policy7, docs242를 실제 실행했다. 일부 회귀와 owning 검사는 중복 범위로 합산하지 않는다. 동일 archive를 Node20/22/24 각각 설치해3runtime(원100k간선 포함), strict 타입·실행문서·optional peers·6entry bundle를 검증했다.16개 runtime owner는 incoming2f768950d와 byte-identical이라 기존 critical coverage를 재사용하고 root 전수 coverage를 새로 실행했다고 주장하지 않는다. 선언은 먼저 합친 point100k 추가를 보존한 채 inference execution 선언을 합쳤다.\n\n최초 unmatched selector 오류, package entry/packed 상한 실패, 검색 크기로 실패한 문서2개를 원본 그대로 보존했다. 측정1246entries/Node20·24 packed1,791,515/unpacked8,062,345에 최소1246/1,791,600/8,062,400 상한, Full785,427에785,500, 검색1,091,539에1,091,600만 적용했다. 별도 runtime 작업량·P95·heap 기준은 변경하지 않았다.\n\n기존 editable program86,871,543bytes exact roundtrip 증거는 source가 같은 upstream에서 재사용한다. 일반 program codec에64MiB 전역 guard가 없음을 유지한다. Worker 공개 통합과 실제 최종 AT82 성능 자격은 다음 작업이며 STEP077 전체 완료로 세지 않는다.\n''')
print(checks,a['sha256'])
