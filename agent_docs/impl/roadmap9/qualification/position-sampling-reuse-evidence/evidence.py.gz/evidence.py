from pathlib import Path
import json,gzip,hashlib,re
p=Path('.artifacts/position-profile');out=Path('agent_docs/impl/roadmap9/qualification/position-sampling-reuse-evidence');out.mkdir(exist_ok=True)
checks={}
for name in ['owning.log','coverage.log','boundaries.log','package-contracts.log','browser.log','docs.log']:
 s=(p/name).read_text();assert '# fail 0' in s,name;checks[name]=int(re.search(r'# tests (\d+)',s)[1])
assert re.search(r'positions\.js\s*\|\s*100\.00\s*\|\s*96\.20\s*\|\s*100\.00',(p/'coverage.log').read_text())
a=json.loads((p/'frozen.json').read_text());installed=[]
for v in [20,22,24]:
 r=json.loads((p/f'installed-{v}.json').read_text());assert r['status']=='passed' and r['sha256']==a['sha256'];assert len(r['checks'])==6 and all(c['status']=='passed' for c in r['checks']);assert r['types']=='passed' and len(r['bundles'])==6;installed.append(r)
 pack=json.loads((p/f'pack{v}.json').read_text());assert pack['entryCount']==1251 and pack['unpackedBytes']==8088155 and pack['packedBytes']<=1795800
assert 'checked 186 built documentation pages' in (p/'built.log').read_text();assert 'verified 1606 selective LLM artifacts' in (p/'built.log').read_text()
alloc=json.loads((p/'same-plan-allocations.json').read_text());assert alloc['exactFrameEqual'] and alloc['count']==1000 and alloc['delta']=={'calls':0,'allocations':-10000,'ownedAdds':-4000,'descriptorWalks':-2000}
files={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.mjs','.py','.txt']:
  raw=f.read_bytes();(out/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[f.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q={'status':'owned-position-scale-reuse-verified; full-native-performance-pending','base':'968485634','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Only exact privately registered position plans reuse closed-record validation. Locally created scalar scale and its new domain/range arrays become owned before mapping. External copied/frozen inputs retain complete validation and remain unowned. No API/schema/math/guard/SLO change.','sourceSHA256':hashlib.sha256(Path('src/grammar/animation/positions.js').read_bytes()).hexdigest(),'archive':a,'checks':checks,'installed':installed,'critical':{'grammar/animation/positions.js':{'lines':100,'branches':96.20,'functions':100,'actualRootRun':True}},'built':{'pages':186,'selectiveArtifacts':1606,'status':'passed'},'allocationAttribution':alloc,'limits':{'entries':1251,'packedBytes':1795800,'unpackedBytes':8088200,'FullGzip':786200,'animationGzip':333900},'corrections':['First Node20 strict pack failed at1795790 over1795700; first six-bundle premeasure found animation333816 over333800. Only these measured artifact thresholds and unpacked8088155 to8088200 were reassessed; runtime guards and performance SLO unchanged.'],'reuse':{'builtBrowser':'Public prose, snippets, CSS and UI unchanged; responsive/accessibility evidence reused; two actual Canvas/SVG animation browser regressions rerun'},'pending':['Original100k common frame and Canvas playback performance','Combined native P95/heap/lifecycle qualification','Sequential STEP057-070 and final required suites'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({'checks':checks,'archive':a['sha256'],'allocationDelta':alloc['delta']}))
