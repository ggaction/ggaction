import {registerHooks} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const immutableUrl=new URL('../../src/core/immutable.js',import.meta.url).href;
const ownDataUrl=new URL('../../src/core/ownData.js',import.meta.url).href;
const positionsUrl=new URL('../../src/grammar/animation/positions.js',import.meta.url).href;
const baseline=await readFile(new URL('./positions-before.js.txt',import.meta.url),'utf8');
const baselineFunction=baseline.slice(baseline.indexOf('export function samplePositionInterpolation')).replace('export function samplePositionInterpolation','function baselineSample');
registerHooks({load(url,context,next){
 const result=next(url,context);let source=String(result.source);
 if(url===positionsUrl){
  source=source.replace('export function samplePositionInterpolation','function optimizedSample');
  return {...result,source:source+'\n'+baselineFunction+'\nexport let samplePositionInterpolation=optimizedSample;\nexport function selectAttributionPhase(phase){samplePositionInterpolation=phase===\'before\'?baselineSample:optimizedSample;}\n'};
 }
 if(url===ownDataUrl){
  const marker='export function ownDataProperties(value, label) {';
  if(!source.includes(marker))throw Error('Descriptor instrumentation owner changed');
  return {...result,source:source.replace(marker,marker+'\n  if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.descriptorWalks++;')};
 }
 if(url!==immutableUrl)return result;
 const entry='export function cloneAndFreeze(value, ancestors = new WeakSet(), path = "state") {';
 const allocation='const clone = array ? new Array(input.length) : {};';
 const freeze='Object.freeze(value);';
 for(const marker of [entry,allocation,freeze])if(!source.includes(marker))throw Error('Instrumentation owner changed');
 source=source.replace(entry,entry+'\n  if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.calls++;');
 source=source.replace(allocation,allocation+'\n    if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.allocations++;');
 source=source.replace(freeze,freeze+'\n    if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.ownedAdds++;');
 return {...result,source};
}});
const {prepareNativeWorkload}=await import('../../scripts/benchmarks/workloads.browser.js');
const {selectAttributionPhase}=await import(positionsUrl);
const stage=prepareNativeWorkload('points',1000).stages.find(value=>value.name==='full-frame').prepare();
for(let index=0;index<5;index++)stage.validate(stage.run());
const results=[];
for(const phase of ['before','after']){
 selectAttributionPhase(phase);
 globalThis.__frameAllocationCounters={calls:0,allocations:0,ownedAdds:0,descriptorWalks:0};
 const result=stage.run(),counts=globalThis.__frameAllocationCounters;
 delete globalThis.__frameAllocationCounters;
 results.push({phase,counts,witness:stage.validate(result),frame:result.frame});
}
assert.deepEqual(results[0].frame,results[1].frame);
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const report={kind:'position-same-plan-temporary-loader-allocation-attribution-not-performance',count:1000,exactFrameEqual:true,
 frameSHA256:hash(results[0].frame),before:results[0].counts,after:results[1].counts,witness:results[0].witness,
 delta:Object.fromEntries(Object.keys(results[0].counts).map(key=>[key,results[1].counts[key]-results[0].counts[key]]))};
assert.deepEqual(report.delta,{calls:0,allocations:-10000,ownedAdds:-4000,descriptorWalks:-2000});
await writeFile(new URL('./same-plan-allocations.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
