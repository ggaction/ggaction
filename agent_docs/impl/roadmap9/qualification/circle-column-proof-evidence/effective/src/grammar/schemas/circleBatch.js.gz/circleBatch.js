import { freezeOwned } from '../../core/immutable.js';
import { ownArray, ownRecord } from "../../core/ownData.js";

export const MAX_CIRCLE_BATCH_ROWS = 10_000;
const keys = new WeakMap();
const constructedColumns = new WeakSet();
// Prototype: only this function owns allocation/writes/freeze. No caller array
// can be marked as constructed. Callback gets an index, never the local array.
export function createCircleBatchColumn(length, valueAt) {
  if (!Number.isInteger(length) || length < 1 || length > MAX_CIRCLE_BATCH_ROWS) throw new RangeError('Circle column construction requires 1..10000 rows.');
  const column = Array.from({ __proto__: null, length }, (_, index) => {
    const value = valueAt(index);
    if (typeof value !== 'number') throw new TypeError('Circle column construction requires numeric results.');
    return value;
  });
  freezeOwned(column); constructedColumns.add(column); return column;
}

export function validateCircleBatchColumn(value, name) {
  if (!Array.isArray(value) || value.length < 1 || value.length > MAX_CIRCLE_BATCH_ROWS) {
    throw new RangeError(`circle-batch.${name} requires 1..${MAX_CIRCLE_BATCH_ROWS} rows.`);
  }
  if (!constructedColumns.has(value)) ownArray(value, `circle-batch.${name}`);
  for (const number of value) {
    if (!Number.isFinite(number)) throw new TypeError(`circle-batch.${name} requires finite numbers.`);
    if (name === "radius" && number < 0) throw new RangeError("circle-batch.radius must not be negative.");
  }
}

export function validateCircleBatchProperties(properties, validateAppearance) {
  ownRecord(properties, "circle-batch.properties");
  if (Object.keys(properties).length !== 4 || ["x", "y", "radius", "appearance"].some(key => !Object.hasOwn(properties, key))) {
    throw new TypeError("circle-batch.properties requires exactly x, y, radius and appearance.");
  }
  for (const key of ["x", "y", "radius"]) validateCircleBatchColumn(properties[key], key);
  if (properties.x.length !== properties.y.length || properties.x.length !== properties.radius.length) {
    throw new RangeError("circle-batch columns require equal row counts.");
  }
  validateAppearance(properties.appearance);
  return properties;
}

// Read fully materialized coordinates; never infer semantics or combine painting.
export function circleBatchRow(properties, index) {
  return { ...properties.appearance, x: properties.x[index], y: properties.y[index], radius: properties.radius[index] };
}

// Renderer-private preparation identity is disjoint from every authored string ID.
// Keep only tiny row tokens, never an expanded scene or a backend object.
export function circleBatchRowKey(object, index) {
  let rows = keys.get(object);
  if (rows === undefined) { rows = []; keys.set(object, rows); }
  return rows[index] ??= Object.freeze({ rowIndex: index });
}
