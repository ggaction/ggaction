import assert from 'node:assert/strict';import{writeFile}from'node:fs/promises';
import * as schema from '../../src/grammar/schemas/circleBatch.js';
import{validateConcreteGraphicProperties}from'../../src/grammar/schemas/concreteGraphic.js';
import{isOwned}from'../../src/core/immutable.js';
const prototype=process.env.PROTOTYPE==='yes';const col=values=>prototype?schema.createCircleBatchColumn(values.length,i=>values[i]):Object.freeze([...values]);
const result=[];let reads=0;
const cases=[()=>({x:col([1,-0]),y:col([2,3]),radius:col([1,2]),appearance:{fill:'red'}}),()=>({x:col([Infinity]),y:col([NaN]),radius:col([-1]),appearance:{fill:'bad'}}),()=>({x:col([1]),y:col([NaN]),radius:col([-1]),appearance:{fill:'bad'}}),()=>({x:col([1]),y:col([2]),radius:col([Infinity]),appearance:{fill:'bad'}}),()=>({x:col([1]),y:col([2]),radius:col([-1]),appearance:{fill:'bad'}}),()=>({x:col([1]),y:col([2,3]),radius:col([1]),appearance:{fill:'bad'}}),()=>({x:Object.freeze(Object.defineProperty([],'0',{get(){reads++;return 1},enumerable:true})),y:[1],radius:[1],appearance:{fill:'red'}}),()=>({x:Object.freeze(Object.assign([1],{extra:1})),y:[1],radius:[1],appearance:{fill:'red'}}),()=>({x:Object.freeze(new Array(1)),y:[1],radius:[1],appearance:{fill:'red'}}),()=>({x:col([1]),y:col([2]),radius:col([1]),appearance:{fill:'invalid paint'}})];
for(const make of cases){const properties=make();try{validateConcreteGraphicProperties('circle-batch',properties);result.push({ok:true,negativeZero:Object.is(properties.x[1],-0)});}catch(error){result.push({name:error.name,message:error.message});}}
assert.equal(reads,0);let creator;
if(prototype){let escaped,visited=0;const failure={};assert.throws(()=>{escaped=schema.createCircleBatchColumn(3,i=>{visited++;if(i===1)throw failure;return i;});},e=>e===failure);assert.equal(escaped,undefined);assert.equal(visited,2);for(const n of[0,10001,1.5])assert.throws(()=>schema.createCircleBatchColumn(n,()=>0),RangeError);assert.throws(()=>schema.createCircleBatchColumn(1,()=>({})),TypeError);const input=[1,-0,Number.MAX_VALUE],output=schema.createCircleBatchColumn(input.length,i=>input[i]);input[0]=9;assert.equal(output[0],1);assert.equal(Object.is(output[1],-0),true);assert.equal(isOwned(output),true);assert.equal(Object.isFrozen(output),true);assert.throws(()=>{output[0]=8},TypeError);let inheritedResult;
const previous = Object.getOwnPropertyDescriptor(Array.prototype, '0');
try {
 Object.defineProperty(Array.prototype, '0', {get(){return 999},set(){},configurable:true});
 inheritedResult = schema.createCircleBatchColumn(1, () => 4);
} finally { if(previous)Object.defineProperty(Array.prototype,'0',previous);else delete Array.prototype[0]; }
assert.equal(Object.hasOwn(inheritedResult,0),true);assert.equal(inheritedResult[0],4);
creator={inheritedSetterCannotInterceptOwnWrites:true,callbackFailureUnpublished:true,primitiveNumericOnly:true,callerArrayUnmodified:true,outputDeepOwned:true};}
await writeFile(`.artifacts/column-proof-review/oracle-${prototype?'candidate':'control'}.json`,JSON.stringify({result,reads,creator},null,2)+'\n');
