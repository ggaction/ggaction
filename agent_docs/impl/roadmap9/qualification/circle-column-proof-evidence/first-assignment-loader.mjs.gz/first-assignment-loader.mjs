import {readFile} from 'node:fs/promises';
const anchors=(source,before,after)=>{if(!source.includes(before))throw Error('Prototype anchor missing: '+before.slice(0,100));return source.replace(before,after);};
export async function load(url,context,next){
 let source;
 if(url.endsWith('/src/grammar/schemas/circleBatch.js')){
  source=await readFile(new URL(url),'utf8');
  source="import { freezeOwned } from '../../core/immutable.js';\n"+source;
  source=anchors(source,'const keys = new WeakMap();',`const keys = new WeakMap();
const constructedColumns = new WeakSet();
// Prototype: only this function owns allocation/writes/freeze. No caller array
// can be marked as constructed. Callback gets an index, never the local array.
export function createCircleBatchColumn(length, valueAt) {
  if (!Number.isInteger(length) || length < 1 || length > MAX_CIRCLE_BATCH_ROWS) throw new RangeError('Circle column construction requires 1..10000 rows.');
  const column = new Array(length);
  for (let index = 0; index < length; index++) {
    const value = valueAt(index);
    if (typeof value !== 'number') throw new TypeError('Circle column construction requires numeric results.');
    column[index] = value;
  }
  freezeOwned(column); constructedColumns.add(column); return column;
}`);
  source=anchors(source,'  ownArray(value, `circle-batch.${name}`);','  if (!constructedColumns.has(value)) ownArray(value, `circle-batch.${name}`);');
 }else if(url.endsWith('/src/grammar/animation/positions.js')){
  source=await readFile(new URL(url),'utf8');
  source="import { createCircleBatchColumn } from '../schemas/circleBatch.js';\n"+source;
  const start=source.indexOf('  const mapper = prepareContinuousScaleScalar(first.scale), values = new Array(plans.length), positions = new Array(plans.length);');
  if(start<0)throw Error('Positions anchor missing');
  source=source.slice(0,start)+`  const mapper = prepareContinuousScaleScalar(first.scale), values = new Array(plans.length), failure = {};
  let positions;
  try {
    positions = createCircleBatchColumn(plans.length, index => {
      if (index === 0) { values[0] = first.value; return first.position; }
      const plan = plans[index], value = progress === 0 ? plan.from.value : progress === 1 ? plan.to.value : interpolateNumber(plan.from.value, plan.to.value, progress);
      let position;
      try { position = mapPreparedContinuousScaleValue(mapper, value); }
      catch (error) { if (!(error instanceof RangeError)) throw error; throw failure; }
      if (!Number.isFinite(position)) throw failure;
      values[index] = value; return position;
    });
  } catch (error) { if (error !== failure) throw error; return fade('nonfinite-position'); }
  return freezeOwned({ kind: 'position-batch', values: freezeOwned(values), positions, scale: first.scale });
}
`;
 }else if(url.endsWith('/src/animation/batchSample.js')){
  source=await readFile(new URL(url),'utf8');
  source="import { createCircleBatchColumn } from '../grammar/schemas/circleBatch.js';\n"+source;
  source=anchors(source,'    const radius = new Array(group.keys.length);\n    for (let row = 0; row < radius.length; row++) {','    const radius = createCircleBatchColumn(group.keys.length, row => {');
  source=anchors(source,'      radius[row] = interpolateNumber(source.properties.radius, target.properties.radius, at);\n    }','      return interpolateNumber(source.properties.radius, target.properties.radius, at);\n    });');
 }
 return source===undefined?next(url,context):{format:'module',shortCircuit:true,source};
}
