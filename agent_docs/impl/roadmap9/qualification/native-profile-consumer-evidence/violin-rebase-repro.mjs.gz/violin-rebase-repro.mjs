import assert from "node:assert/strict";
import test from "node:test";
import { chart, hconcat } from "../../src/index.js";
import { getMarkItems } from "../../src/inspection.js";
import { exportAccessibleData } from "../../src/accessibility.js";
import { createInteractionSession } from "../../src/interaction.js";
import { serializeProgram, deserializeProgram } from "../../src/persistence.js";
import { planTransition, sampleTransition, serializeAnimation, deserializeAnimation } from "../../src/animation.js";

const rows = Object.freeze([
  { id: "a0", series: "A", x: 0, value: 1 }, { id: "a1", series: "A", x: 1, value: 3 }, { id: "a2", series: "A", x: 2, value: 2 },
  { id: "b0", series: "B", x: 0, value: 2 }, { id: "b1", series: "B", x: 1, value: 4 }, { id: "b2", series: "B", x: 2, value: 3 }
].map(Object.freeze));
const base = () => chart().createCanvas({ width: 400, height: 300, margin: 50 })
  .createData({ id: "data", keyField: "id", values: rows });
const families = {
  rose: { build: p => p.createRosePlot({ id: "m", category: "series", value: "value", aggregate: "sum", guides: false }), point: { x: 200, y: 110 }, appearance: "fill" },
  radar: { build: p => p.createRadarPlot({ id: "m", category: { field: "x", fieldType: "ordinal" }, value: { field: "value", scale: { domain: [0, 4], nice: false } }, groupBy: "series", color: "series", guides: false }), point: { x: 200, y: 225 }, appearance: "stroke" },
  streamgraph: { build: p => p.createAreaPlot({ id: "m", x: "x", y: { field: "value", scale: { nice: false } }, groupBy: "series", layout: "wiggle", guides: false }), point: { x: 200, y: 200 }, appearance: "fill" },
  violin: { build: p => p.createViolinPlot({ id: "m", x: "series", y: { field: "value", scale: { domain: [0, 5], nice: false } }, density: { bandwidth: 1, extent: [0, 5], steps: 10 }, guides: false }), point: { x: 125, y: 170 }, appearance: "fill" }
};
const items = p => getMarkItems(p, { target: "m" });
const accessible = p => exportAccessibleData(p, { format: "items" });
const revise = p => p.reviseData({ source: "data", id: "revised", values: rows.map(row => ({ ...row, value: row.value + (row.series === "A" ? .5 : 0) })) });

const from = families.violin.build(base());
const plan = planTransition({from, to: revise(from), options:{durationMs:100,easing:"linear"}});
const rebased = planTransition({from: sampleTransition(plan,40), to: from, options:{durationMs:60,easing:"linear"}});
const expected = sampleTransition(rebased,30);
const actual = sampleTransition(deserializeAnimation(serializeAnimation(rebased)).plan,30);
assert.deepEqual(actual.graphicSpec,expected.graphicSpec);
assert.deepEqual(actual.scene,expected.scene);
assert.deepEqual(actual.decisions.map(d=>[d.kind,d.reason]),expected.decisions.map(d=>[d.kind,d.reason]));
