import { Session } from 'node:inspector';
const repo = process.argv[2], count = Number(process.argv[3]);
const { prepareNativeWorkload } = await import(repo + '/scripts/benchmarks/workloads.browser.js');
const w = prepareNativeWorkload('geo', count), p = w.stages.find(s => s.name === 'camera-preview').prepare();
const t = []; for (let i = 0; i < 10; i++) { const r = p.run(); t.push(r.metrics.cameraPreviewMs); if (i === 0) p.validate(r); }
console.log('ms', t.map(v => v.toFixed(1)).join(' '));
const s = new Session(); s.connect(); const post = (m, a = {}) => new Promise((r, j) => s.post(m, a, (e, v) => e ? j(e) : r(v)));
await post('Profiler.enable'); await post('Profiler.setSamplingInterval', { interval: 200 }); await post('Profiler.start');
for (let i = 0; i < 5; i++) p.run();
const { profile } = await post('Profiler.stop');
const byId = new Map(profile.nodes.map(x => [x.id, x])), self = new Map(), parent = new Map();
for (const n of profile.nodes) for (const c of n.children || []) parent.set(c, n.id);
profile.samples.forEach((id, i) => self.set(id, (self.get(id) || 0) + (profile.timeDeltas[i] || 0) / 1000 / 5));
const name = id => { const f = byId.get(id).callFrame; return f.functionName + ' ' + f.url.split('/').slice(-2).join('/') + ':' + f.lineNumber; };
const agg = new Map(); for (const [id, v] of self) agg.set(name(id), (agg.get(name(id)) || 0) + v);
console.log([...agg].sort((a, b) => b[1] - a[1]).slice(0, 16).map(([k, v]) => v.toFixed(1) + 'ms ' + k).join('\n'));
const callers = new Map(); for (const [id, v] of self) { const top = name(id); if (!/ownData|cloneAndFreeze|copy |freezeOwned|isPlainObject/.test(top)) continue; let c = parent.get(id), chain = []; while (c && chain.length < 3) { const nm = name(c); if (!/ownData|immutable/.test(nm)) chain.push(nm); c = parent.get(c); } const k = chain.join(' <- '); callers.set(k, (callers.get(k) || 0) + v); }
console.log('== ownership/copy callers'); console.log([...callers].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => v.toFixed(1) + 'ms ' + k).join('\n'));
