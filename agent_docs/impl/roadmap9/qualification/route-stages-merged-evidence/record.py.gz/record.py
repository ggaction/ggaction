from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,re
b=Path('.artifacts/route-stages-merged');d=Path('agent_docs/impl/roadmap9/qualification/route-stages-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
q={'schemaVersion':1,'status':'verified-private-route-stages-integration','base':'11ee73d13','upstream':'e5e71407f','archive':a,'sourceHashes':{},'evidenceFiles':{},'checks':{'sameArchiveNodeVersions':[20,22,24],'publicCasesPerNode':8,'privateCasesPerNode':9,'strictTypes':True,'browserBundles':6,'actualBrowserMinifiedWorker':True,'readmeCorrection':'First source pin found stale Basic ceiling. README synchronized; same final archive reinstalled on all three Nodes and actual browser.'},'remaining':['public native B update and full consumer union','fit and data/composition integration','original large route capacity and whole pipeline 100ms','isolated canonical P95 and original 100cycle lifetime','final combined qualification']}
for f in subprocess.check_output(['git','diff','--name-only','b86503b56','e5e71407f','--','src'],text=True).splitlines():
 actual=Path(f).read_bytes();expected=subprocess.check_output(['git','show','e5e71407f:'+f]);assert actual==expected,f;q['sourceHashes'][f]=hashlib.sha256(actual).hexdigest()
caps={'ggaction':793118,'ggaction/basic':426400,'ggaction/svg':26000,'ggaction/graph':74500,'ggaction/animation':343663,'ggaction/interaction':140172}
for n in [20,22,24]:
 r=json.loads((b/f'installed-{n}.json').read_text());assert r['sha256']==a['sha256'] and r['status']=='passed' and r['types']=='passed'
 assert len(r['runtime']['records'])==8 and r['runtime']['workers']==r['runtime']['terminated']==16 and r['runtime']['listeners']==0
 for row in r['runtime']['records']:assert row['nativeGeometryHash']==row['geometryHash']
 for row in r['bundles']:assert row['gzipBytes']<=caps[row['specifier']],row
 f=Path(f'.artifacts/route-screen-stages/installed-stages-{n}.json');v=json.loads(f.read_text());assert v['sha256']==a['sha256'] and v['tests']==9 and v['status']=='passed';shutil.copyfile(f,b/f.name)
r=json.loads((b/'browser.json').read_text());assert r['sha256']==a['sha256'] and r['workers']==r['terminated']==7 and r['listeners']==0
for label in ['owning','focused','boundaries']:
 s=(b/(label+'.log')).read_text();assert '# fail 0' in s;q['checks'][label]=int(re.search(r'# tests (\d+)',s)[1])
q['checks']['earlierSelectorFailure']='Nonexistent coverage-policy test selector failed before tests; corrected to existing source/package/discovery contracts.'
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/route-stages-merged.md').write_text('''# Native route continuation 합산 검증

기존 route/source DAG와 Canvas/screen/guide/responsive owner의 private generator 단계를 통합했다. 동기 v1은 같은 순서를 즉시 소비하며 native v2 준비만 실제 계산 완료 경계에서 대기한다. Exact constructor 등록과 원 primitive proof, receiver 검사, abort·ledger 경계, wrapped child action을 유지한다. Basic에는 graph solver나 host 의존성을 추가하지 않았다.

[합산 증거](route-stages-merged-evidence/qualification.json)는 변경된 runtime source가 upstream e5e71407f와 일치함을 검산한다. 합산 owning 1,423개 및 focused 23개, source/package/discovery 경계가 통과했다. 동일 canonical archive를 Node20/22/24에 설치하여 각각 public8·private9 cases, strict types와6bundles를 검증했다. Chromium minified 실제 worker7개가 모두 종료되었고 listener0과 abort publication0을 확인했다. 잘못 지정한 존재하지 않는 test selector의 최초 실패 로그도 보존한다.

Package1268entries/unpacked8,227,339bytes, Node22packed1,826,695·Node24packed1,830,363bytes다. 합산 Full793,118/Basic426,399/animation343,663/interaction140,166gzipbytes를 측정해 기존 artifact ceiling만 정합했다. Runtime quota·원 workload·SLO는 변경하지 않았다.

이는 private native continuation의 통합 checkpoint다. 공개 B update, 전체 consumer union, fit/data/composition, 원 route capacity, 전체100ms와 최종P95·100cycle lifetime은 미완료이며 STEP057–070/077 완료로 세지 않는다.
''')
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s if 'qualification/route-stages-merged.md' in s else s[:i]+'Route/source DAG와 Canvas·screen·guide·responsive의 private continuation을 합산했다([1,423회귀·동일 archive3Node/browser](qualification/route-stages-merged.md)). 공개 B update와 전체 union·성능 자격은 후속 의무다.\n\n'+s[i:];f.write_text(s)
print(q['checks'],a['sha256'])
