import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {execFileSync} from 'node:child_process';
const source=new URL('../../src/',import.meta.url).href;
const replace=(text,old,value)=>{assert.ok(text.includes(old),'Missing candidate seam: '+old);return text.replace(old,value);};
registerHooks({load(url,context,next){const result=next(url,context);if(!url.startsWith(source))return result;const file=url.slice(source.length);let content=String(result.source);
 if(process.env.FRAME_CANDIDATE==='0'&&['animation/sample.js','renderers/canvasScene.js'].includes(file))content=execFileSync('git',['show','012ecf039:src/'+file],{encoding:'utf8'});
 if(file==='core/immutable.js'){
 content=replace(content,'const clone = array ? new Array(input.length) : {};','const clone = array ? new Array(input.length) : {};if(globalThis.__counts)globalThis.__counts.clones++;');
 content=replace(content,'ownedValues.add(value);','ownedValues.add(value);if(globalThis.__counts)globalThis.__counts.ownedAdds++;');}
 if(file==='animation/resources.js')content=replace(content,'export function validateAnimationResourceWork(value,label,scope) {','export function validateAnimationResourceWork(value,label,scope) {if(globalThis.__work)globalThis.__work[label]=Math.max(globalThis.__work[label]??0,value);');
 return{...result,source:content};}});
