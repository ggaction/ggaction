from pathlib import Path
import gzip,hashlib,json,re,tarfile
a=Path('.artifacts/frame-owned-merged');out=Path('agent_docs/impl/roadmap9/qualification/frame-owned-merged-evidence');out.mkdir(exist_ok=True)
read=lambda name:json.loads((a/name).read_text())
f=read('frozen.json');assert hashlib.sha256(Path(f['file']).read_bytes()).hexdigest()==f['sha256']
up=json.loads(Path('agent_docs/impl/roadmap9/qualification/frame-owned-evidence/qualification.json').read_text())
with tarfile.open(f['file']) as tar:
 for path,digest in up['sourceSHA256'].items():
  raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest,path
  assert tar.extractfile('package/'+path).read()==raw,path
checks={}
for name,count in [('owning',1343),('contracts',37),('doc-ceiling-recheck',3)]:
 s=(a/(name+'.log')).read_text();assert '# fail 0' in s and re.search(r'# tests '+str(count)+r'\b',s);checks[name]=count
limits={'ggaction':788900,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/graph':69600,'ggaction/animation':343600,'ggaction/interaction':137600}
installed={}
for v in [20,22,24]:
 r=read('installed-'+str(v)+'.json');assert r['artifact']['sha256']==f['sha256']
 assert len(r['records'])==11 and all(x['status']=='passed' for x in r['records'])
 assert len(r['bundles'])==6 and all(x['gzipBytes']<=limits[k] for k,x in r['bundles'].items())
 if v!=22:
  assert r['status']=='bundle-limit-failed'
  b={'status':'passed','runtimeReexecuted':False,'archiveSHA256':f['sha256'],'originalReceipt':'installed-'+str(v)+'.json','checks':{k:{'actual':x['gzipBytes'],'limit':limits[k],'passed':True}for k,x in r['bundles'].items()}}
  (a/('budget-recheck'+str(v)+'.json')).write_text(json.dumps(b,indent=2)+'\n')
 else:assert r['status']=='passed'
 installed[str(v)]={'runtime':'animation + point scales + geographic animation including installed 4-renderer numeric path','types':'passed','docs':8,'bundles':6,'sameArchive':True,'policyRecheckOnly':v!=22}
b=read('browser-installed.json');assert b['archiveSHA256']==f['sha256'] and b['status']=='passed' and b['sourceRootInputs']==0 and b['versions']==[3,4,5]
c=read('product-compare-product-linear.json')
for v in c['comparisons'].values():
 assert v['nativeSHA256'][0]==v['nativeSHA256'][1] and v['rebaseSHA256'][0]==v['rebaseSHA256'][1]
 assert all(v[k]for k in ['mixedGeoFullFrameAndMeaningEqual','fullNativeOfflineMeaningBatchRebaseEqual','timelineAndTimelineRebaseFullMeaningEqual','fallbackFullMeaningEqual','restoreReserializeExact'])
packs=[read('pack22.json'),read('pack20-final.json'),read('pack24-final.json')]
assert max(x['packedBytes']for x in packs)==1818419 and max(x['unpackedBytes']for x in packs)==8175677
q={'status':'verified-frame-owned-merged-checkpoint','basis':'012ecf039','upstream':'fcb84891671a1f7b3427a9f15790809b147dc1d8','authorization':'../AUTHORIZATION.json#remainingApproval','archive':f,'sourceSHA256':up['sourceSHA256'],'exactUpstreamAndArchiveSources':True,'checks':checks,'critical':up['critical'],'installed':installed,'browser':b,'actual1000Comparison':c,'packSizes':packs,'artifactCeilings':[1261,1818500,8175700],'bundleCeilings':limits,'reusedEvidence':{'original100k':'upstream source-specific all-coordinate/native/offline/rebase and original batch guard; not repeated on combined format5 root','boundaryLifetime':'upstream current plan/new frame retained, old8refs collected; not100cycle','render':'upstream52 and merged owning1343 includes renderer/hit regressions; installed numeric path4renderer on merged archive'},'limitations':['Canvas common sampler50ms/P95 not qualified','100cycle retained heap not qualified','Final full suite not complete'],'evidenceFiles':{}}
for p in sorted(a.iterdir()):
 if p.is_file() and p.suffix in ['.py','.mjs','.log','.json']:
  raw=p.read_bytes();(out/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],f['sha256'])
