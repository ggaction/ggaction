from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,re
b=Path('.artifacts/route-layout-merged');d=Path('agent_docs/impl/roadmap9/qualification/route-layout-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
q={'schemaVersion':1,'status':'verified-private-graph-hierarchy-stages-integration','base':'4bceea06e','upstream':'3427ae56f','archive':a,'sourceHashes':{},'evidenceFiles':{},'checks':{'sameArchiveNodeVersions':[20,22,24],'publicCasesPerNode':8,'privateCasesPerNode':11,'strictTypes':True,'browserBundles':6,'actualBrowserMinifiedWorker':True},'remaining':['public native B update and full consumer union','data and fit invocation lifecycle integration','original route capacity and whole pipeline 100ms','exclusive canonical P95 and original 100cycle lifetime','final combined qualification']}
for f in subprocess.check_output(['git','diff','--name-only','e5e71407f','3427ae56f','--','src'],text=True).splitlines():
 raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','3427ae56f:'+f]),f;q['sourceHashes'][f]=hashlib.sha256(raw).hexdigest()
caps={'ggaction':793317,'ggaction/basic':426400,'ggaction/svg':26000,'ggaction/graph':74500,'ggaction/animation':343701,'ggaction/interaction':140172}
for n in [20,22,24]:
 r=json.loads((b/f'installed-{n}.json').read_text());assert r['sha256']==a['sha256'] and r['status']=='passed' and r['types']=='passed'
 assert len(r['runtime']['records'])==8 and r['runtime']['workers']==r['runtime']['terminated']==16 and r['runtime']['listeners']==0
 for row in r['runtime']['records']:assert row['nativeGeometryHash']==row['geometryHash']
 for row in r['bundles']:assert row['gzipBytes']<=caps[row['specifier']],row
 f=Path(f'.artifacts/route-layout-stages/installed-stages-{n}.json');v=json.loads(f.read_text());assert v['sha256']==a['sha256'] and v['tests']==11 and v['status']=='passed';shutil.copyfile(f,b/f.name)
r=json.loads((b/'browser.json').read_text());assert r['sha256']==a['sha256'] and r['workers']==r['terminated']==7 and r['listeners']==0
for label in ['owning','boundaries']:
 s=(b/(label+'.log')).read_text();assert '# fail 0' in s;q['checks'][label]=int(re.search(r'# tests (\d+)',s)[1])
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/route-layout-merged.md').write_text('''# Graph와 hierarchy native 단계 합산 검증

Graph/hierarchy resource와 layout의 기존 dependency 계산 순서를 private generator로 공유한다. 기존 동기 owner와 writeGraphResource의 wrapped actionSource 수명을 유지하며 async 준비 결과를 곧바로 공개 ChartProgram으로 반환하지 않는다. Graph·hierarchy의 원 primitive 검산, anchor mismatch 거부, apply ledger·abort를 그대로 유지한다.

[합산 증거](route-layout-merged-evidence/qualification.json)는 변경된3개 runtime source가 upstream3427ae56f와 같음을 확인한다. 합산 owning110개와 source/package/discovery/documentation 경계, 동일 canonical archive의 Node20/22/24 public8·private11cases, strict types 및6bundles가 통과했다. 실제 Chromium worker7개 종료와 listener0, 취소 publication0을 확인했다. Upstream의 각298개/critical coverage 증거는 upstream archive 기준으로 보존한다.

Package1268entries/unpacked8,228,755bytes, Node22packed1,827,030·Node24packed1,830,664bytes다. 합산 Full793,317gzipbytes를 측정해 artifact ceiling만 정합했다. 기존 runtime work/guard 및 원 SLO는 그대로다.

공개 B update와 전체 native union은 미완료다. 원 wrapped invocation의 theme/trace/override를 한 번만 수행하는 최종 apply 경계와 data/fit/composition, 원 capacity·100ms/P95·100cycle을 후속 의무로 유지한다. STEP057–070/077 완료가 아니다.
''')
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'Graph/hierarchy native 준비 단계를 합산했다([110회귀·동일 archive3Node/browser](qualification/route-layout-merged.md)). 최종 공개 B apply의 wrapped invocation과 전체 union은 후속 의무다.\n\n'+s[i:];f.write_text(s)
print(q['checks'],a['sha256'])
