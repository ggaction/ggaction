import {
  validateAggregate,
  validateAggregateFieldType
} from "../aggregate.js";
import {
  BAR_ORIENTATIONS,
  BAR_GRAINS,
  resolveBarGrain,
  resolveBarOffsetChannel,
  resolveBarOrientation
} from "../bars/policy.js";
import { resolveBin, validateStack } from "./common.js";
import { normalizeStatisticalWeight } from
  "../weightedStatistics.js";

function resolveBarChannelPolicy({
  markConfig = {},
  layer,
  channel,
  args,
  fieldType,
  field
}) {
  let bin;
  let aggregate;
  let stack;
  const xEncoding = layer.encoding?.x;
  const opposite = layer.encoding?.[channel === "x" ? "y" : "x"];
  const pendingRange = markConfig.boxPlot !== undefined ||
    layer.encoding?.[`${channel}2`] !== undefined;

  if (layer.mark?.orientation !== undefined) {
    if (fieldType !== "quantitative" || ["bin", "aggregate", "stack", "weight"].some(key => args[key] !== undefined)) {
      throw new Error("Oriented numeric bars require raw quantitative positions without bin, aggregate, stack, or weight.");
    }
    return { bin, aggregate, stack };
  }

  if (["nominal", "ordinal", "temporal"].includes(fieldType)) {
    if (args.aggregate !== undefined || args.bin !== undefined || args.stack !== undefined) {
      throw new Error(
        "Categorical bar position does not support bin or aggregate; a binned bar requires a quantitative field."
      );
    }
  } else if (fieldType === "quantitative" && channel === "x" && args.bin !== undefined) {
    if (args.aggregate !== undefined || args.stack !== undefined) {
      throw new Error("Binned bar x encoding does not support aggregate or stack.");
    }
    bin = resolveBin(args.bin);
    const weight = args.weight === undefined
      ? undefined
      : normalizeStatisticalWeight(args.weight, "Histogram weight");
    if (weight !== undefined && opposite?.aggregate !== undefined && opposite.aggregate !== "count") {
      throw new Error("Binned bar weights require count aggregation.");
    }
    return { bin, aggregate, stack, weight };
  } else if (
    fieldType === "quantitative" &&
    channel === "y" &&
    xEncoding?.bin !== undefined
  ) {
    if (args.bin !== undefined) {
      throw new Error("Histogram bar y encoding does not support bin.");
    }
    aggregate = validateAggregate(args.aggregate ?? "count");
    validateAggregateFieldType(aggregate, fieldType);
    if (aggregate === "count" && field !== xEncoding.field) {
      throw new Error("Count bar y field must match the binned x field.");
    }
    if (aggregate !== "count" && xEncoding.weight !== undefined) {
      throw new Error("Binned bar weights require count aggregation.");
    }
    stack = Object.hasOwn(args, "stack") ? args.stack : aggregate === "count" ? "zero" : null;
    stack = validateStack(stack, "Histogram bar y encoding");
    if (stack === "center") {
      throw new Error("Centered bars are not supported.");
    }
  } else if (fieldType === "quantitative") {
    if (args.bin !== undefined) {
      throw new Error(
        channel === "y"
          ? "Bar y does not support bin; histogram y requires a binned x encoding."
          : "Quantitative bar measure encoding does not support bin."
      );
    }
    aggregate = args.aggregate ?? (
      ["nominal", "ordinal", "temporal"].includes(opposite?.fieldType) &&
      !pendingRange
        ? "mean"
        : undefined
    );
    if (pendingRange && args.aggregate === undefined) {
      return { bin, aggregate, stack };
    }
    stack = Object.hasOwn(args, "stack") ? args.stack : opposite === undefined ? undefined : null;
    if (aggregate !== undefined) {
      aggregate = validateAggregate(aggregate);
      validateAggregateFieldType(aggregate, fieldType);
    }
    if (stack !== undefined) stack = validateStack(stack, `Bar ${channel} encoding`);
    if (stack === "center") {
      throw new Error("Centered bars are not supported.");
    }
  } else {
    throw new Error(
      "Bar position requires quantitative, temporal, ordinal, or nominal fields."
    );
  }

  if (args.weight !== undefined) {
    throw new Error("Bar weight is supported only for a binned x encoding.");
  }
  return { bin, aggregate, stack };
}

export function resolveBarPositionPolicy(context) {
  const { markConfig = {}, layer, channel, field, fieldType } = context;
  const policy = resolveBarChannelPolicy(context);
  const oppositeChannel = channel === "x" ? "y" : "x";
  const opposite = layer.encoding?.[oppositeChannel];
  const pendingRange = markConfig.boxPlot !== undefined ||
    layer.encoding?.[`${channel}2`] !== undefined;
  const candidate = {
    ...layer,
    encoding: {
      ...layer.encoding,
      [channel]: { field, fieldType, ...policy }
    }
  };
  // The same channel policy owns a measure whether it is authored first or last.
  // Absence of an aggregate/stack is sufficient to represent an unresolved role.
  let companion;
  if (
    !pendingRange && resolveBarGrain(layer) === undefined &&
    opposite?.fieldType === "quantitative" && opposite.bin === undefined
  ) {
    const resolved = resolveBarChannelPolicy({
      ...context,
      layer: candidate,
      channel: oppositeChannel,
      field: opposite.field,
      fieldType: opposite.fieldType,
      args: opposite
    });
    candidate.encoding[oppositeChannel] = { ...opposite, ...resolved };
    if (
      (opposite.aggregate === undefined && resolved.aggregate !== undefined) ||
      opposite.stack !== resolved.stack
    ) {
      companion = { channel: oppositeChannel, encoding: candidate.encoding[oppositeChannel] };
    }
  }
  const orientation = resolveBarOrientation(candidate);
  if (opposite !== undefined && orientation === undefined && !pendingRange) {
    throw new Error(
      `Bar ${channel} encoding requires a quantitative field opposite a categorical position.`
    );
  }
  const expectedOffset = resolveBarOffsetChannel(candidate);
  const incompatibleOffset = orientation === BAR_ORIENTATIONS.horizontal
    ? "xOffset"
    : orientation === BAR_ORIENTATIONS.vertical
      ? "yOffset"
      : undefined;
  if (incompatibleOffset !== undefined && candidate.encoding?.[incompatibleOffset] !== undefined) {
    throw new Error(
      `${orientation} bars require ${expectedOffset}; remove the incompatible ${incompatibleOffset} encoding.`
    );
  }
  if (
    markConfig.barWidth !== undefined &&
    resolveBarGrain(candidate) === BAR_GRAINS.histogram
  ) {
    throw new Error("A saved Bar width requires an aggregate or ranged category slot and cannot be applied to histogram bins.");
  }
  return companion === undefined ? policy : { ...policy, companion };
}
