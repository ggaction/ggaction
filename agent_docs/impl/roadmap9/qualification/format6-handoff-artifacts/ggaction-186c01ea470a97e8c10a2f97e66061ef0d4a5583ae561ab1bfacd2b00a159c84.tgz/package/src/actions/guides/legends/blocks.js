import { resolveEffectiveLegendBlockConfig } from "../../../materialization/guides/legendConfig.js";
import {validateColorSizeShapeSamples} from "../../../grammar/colorSizeLegend.js";
import { editFacetParentLegend } from "../../../materialization/facetGuides/edit.js";

import {patchLegendClipHeight, validateLegendClip} from "../../../grammar/legendClip.js";
import { LEGEND_POSITIONS } from "../../../core/vocabulary.js";
import { action } from "../../../core/action.js";
import { isPlainObject } from "../../../core/immutable.js";
import {
  validateNonEmptyString,
  validateNonNegativeFinite,
  validateOptionObject,
  validatePositiveFinite,
  validateUnitInterval
} from "../../../core/validation.js";
import { isNominalValue } from "../../../grammar/scales/fields.js";
import { withGuideLayoutValidation } from "../../../materialization/guides/layout.js";
import { legendResourcePolicy } from "../../../materialization/guides/resources.js";
import {
  preserveGraphicPlacement,
  resolveLegendGraphicPlacement
} from "../../../materialization/graphicHierarchy.js";
import { normalizeLegendSampling, validateSamplingAgainstScale } from "../../../grammar/legendSampling.js";
import {
  legendBlockKey,
  resolveLegendBlock
} from "./target.js";
import { validateFontWeight } from "./categorical/validation.js";
import { normalizeLegendDisplayLabelMap } from "../../../grammar/displayLabels.js";

const OPTIONS = Object.freeze([
  "target", "channel", "title", "values", "count", "order", "gap", "text", "symbol",
  "labelMap", "position", "clipHeight"
]);
const TEXT_OPTIONS = Object.freeze(["fontSize", "fontFamily", "fontWeight", "color"]);
const SYMBOL_OPTIONS = Object.freeze(["size", "fill", "stroke", "strokeWidth", "opacity"]);

function validatePatchObject(value, keys, label) {
  if (!isPlainObject(value)) throw new TypeError(`${label} must be a plain object.`);
  validateOptionObject(value, keys, label);
}

function normalizeTextPatch(value) {
  validatePatchObject(value, TEXT_OPTIONS, "editLegendBlock text");
  if (value.fontSize !== undefined) {
    validatePositiveFinite(value.fontSize, "editLegendBlock text.fontSize");
  }
  if (value.fontFamily !== undefined) {
    validateNonEmptyString(value.fontFamily, "editLegendBlock text.fontFamily");
  }
  if (value.fontWeight !== undefined) {
    validateFontWeight(value.fontWeight, "editLegendBlock text.fontWeight");
  }
  if (value.color !== undefined) {
    validateNonEmptyString(value.color, "editLegendBlock text.color");
  }
  return { ...value };
}

function categoricalSupports(config, property) {
  const types = new Set(config.symbol.layers.map(layer => layer.type));
  if (property === "size") return types.has("point");
  if (property === "fill") return types.has("point") || types.has("swatch");
  return types.size > 0;
}

function validateSymbolSupport(descriptor, property) {
  const { channels, family, kind, config } = descriptor;
  if(kind === "colorSize" && ['size',config.colorChannel==='stroke'?'stroke':'fill'].includes(property)) throw new Error("Color-size symbols cannot override mapped hue or size.");
  if (family === "gradient") {
    throw new Error(`editLegendBlock symbol.${property} is unsupported for gradient blocks.`);
  }
  if (family === "categorical") {
    if (property === "size" && channels.includes("size")) throw new Error("Combined size-shape block cannot override mapped size.");
    if (property === "fill" && channels.includes("color")) {
      throw new Error("editLegendBlock symbol.fill conflicts with the color mapping.");
    }
    if (property === "stroke" && channels.includes("stroke")) {
      throw new Error("editLegendBlock symbol.stroke conflicts with the stroke mapping.");
    }
    if (!categoricalSupports(config, property)) {
      throw new Error(`editLegendBlock symbol.${property} is unsupported by this categorical recipe.`);
    }
    return;
  }
  if (kind === "gradient" && property === "fill") throw new Error("editLegendBlock symbol.fill conflicts with the color mapping.");
  if (kind === "size" && property === "size") {
    throw new Error("editLegendBlock symbol.size conflicts with the size mapping.");
  }
  if (kind === "opacity" && property === "opacity") {
    throw new Error("editLegendBlock symbol.opacity conflicts with the opacity mapping.");
  }
  if (kind === "strokeWidth" && property === "strokeWidth") {
    throw new Error("editLegendBlock symbol.strokeWidth conflicts with the strokeWidth mapping.");
  }
  if (kind === "strokeWidth" && ["size", "fill"].includes(property)) {
    throw new Error(`editLegendBlock symbol.${property} is unsupported for strokeWidth blocks.`);
  }
  if (kind === "interval" && property === "fill") {
    throw new Error("editLegendBlock symbol.fill conflicts with the color mapping.");
  }
  if (kind === "strokeInterval" && property === "stroke") {
    throw new Error("editLegendBlock symbol.stroke conflicts with the stroke mapping.");
  }
  if (["interval", "strokeInterval"].includes(kind) && property === "size") {
    throw new Error(`editLegendBlock symbol.size is unsupported for ${kind} blocks.`);
  }
}

function normalizeSymbolPatch(value, descriptor) {
  validatePatchObject(value, SYMBOL_OPTIONS, "editLegendBlock symbol");
  if (value.size !== undefined) {
    validateNonNegativeFinite(value.size, "editLegendBlock symbol.size");
  }
  if (value.fill !== undefined) {
    validateNonEmptyString(value.fill, "editLegendBlock symbol.fill");
  }
  if (value.stroke !== undefined) {
    validateNonEmptyString(value.stroke, "editLegendBlock symbol.stroke");
  }
  if (value.strokeWidth !== undefined) {
    validateNonNegativeFinite(value.strokeWidth, "editLegendBlock symbol.strokeWidth");
  }
  if (value.opacity !== undefined) {
    validateUnitInterval(value.opacity, "editLegendBlock symbol.opacity");
  }
  for (const property of Object.keys(value)) {
    validateSymbolSupport(descriptor, property);
  }
  return { ...value };
}

export function validateLegendBlockOverride(descriptor, override, scaleType) {
  if (override.alongOffset !== undefined && !Number.isFinite(override.alongOffset)) throw new TypeError("Legend alongOffset must be finite.");
  if (override.position !== undefined && !LEGEND_POSITIONS.includes(override.position)) throw new Error("Invalid local legend position.");
  if (override.symbol !== undefined) normalizeSymbolPatch(override.symbol, descriptor);
  if (override.labelMap !== undefined) {
    normalizeLegendDisplayLabelMap(descriptor, override.labelMap, scaleType);
  }
  return override;
}

function exactCategoricalOrder(program, descriptor, value) {
  if (descriptor.family !== "categorical") {
    throw new Error("editLegendBlock order requires a categorical block.");
  }
  if (!Array.isArray(value) || value.length === 0) {
    throw new TypeError("editLegendBlock order must be a non-empty array.");
  }
  if (!value.every(isNominalValue)) {
    throw new TypeError("editLegendBlock order must contain categorical values.");
  }
  if (value.some((item, index) =>
    value.slice(0, index).some(previous => Object.is(previous, item)))) {
    throw new Error("editLegendBlock order values must be unique.");
  }
  const domain = program.resolvedScales[descriptor.scaleIds[0]].domain;
  if (domain.length !== value.length ||
    domain.some(item => !value.some(candidate => Object.is(candidate, item)))) {
    throw new Error("editLegendBlock order must be an exact permutation of the current domain.");
  }
  return Object.freeze({ values: Object.freeze([...value]) });
}

function withoutEmptyNested(entry, key, value) {
  if (Object.keys(value).length > 0) return { ...entry, [key]: value };
  const { [key]: _removed, ...rest } = entry;
  return rest;
}

export function patchLegendBlockOverride(config, key, patch) {
  const previous = config.blockOverrides?.[key] ?? {};
  let entry = { ...previous };
  if (Object.hasOwn(patch, "title")) entry.title = patch.title;
  if (Object.hasOwn(patch, "gap")) entry.gap = patch.gap;
  if (Object.hasOwn(patch, "text")) {
    entry = withoutEmptyNested(entry, "text", patch.text);
  }
  if (Object.hasOwn(patch, "symbol")) {
    entry = withoutEmptyNested(entry, "symbol", patch.symbol);
  }
  if (Object.hasOwn(patch, "labelMap")) entry.labelMap = patch.labelMap;
  if (Object.hasOwn(patch, "position")) entry.position = patch.position;
  if (Object.hasOwn(patch, "alongOffset")) entry.alongOffset = patch.alongOffset;
  if (patch.removePosition === true) { delete entry.position; delete entry.alongOffset; }
  if (patch.removeLabelMap === true) delete entry.labelMap;
  const blockOverrides = { ...(config.blockOverrides ?? {}) };
  if (Object.keys(entry).length === 0) delete blockOverrides[key];
  else blockOverrides[key] = entry;
  return Object.keys(blockOverrides).length === 0
    ? undefined
    : blockOverrides;
}

function titleGraphicId(kind) {
  return legendResourcePolicy(kind).graphicIds.find(id => id.endsWith("Title"));
}

export function reconcileLegendBlockTitleGraphic(program, kind, visible) {
  const id = titleGraphicId(kind);
  const exists = program.graphicSpec.objects[id] !== undefined;
  if (!visible && exists) return program.editGraphics({ target: id, remove: true });
  if (visible && !exists) {
    const owned = new Set(legendResourcePolicy(kind).graphicIds);
    const anchor = program.graphicSpec.objects.canvas.children
      .filter(childId => childId !== id && owned.has(childId))
      .at(-1);
    if (anchor === undefined) {
      throw new Error(`editLegendBlock cannot place the ${kind} legend title.`);
    }
    return program.createGraphics({
      id,
      type: "text",
      ...resolveLegendGraphicPlacement(program, { after: anchor })
    });
  }
  return program;
}

const SPECIALIZED_SYMBOLS = Object.freeze({
  colorSize: Object.freeze({id:"colorSizeLegendSymbols",type:"circle"}),
  gradient: Object.freeze({ id: "colorGradientSymbols", type: "circle" }),
  size: Object.freeze({ id: "sizeLegendSymbols", type: "circle" }),
  opacity: Object.freeze({ id: "opacityLegendSymbols", type: "circle" }),
  strokeWidth: Object.freeze({ id: "strokeWidthLegendSymbols", type: "line" }),
  interval: Object.freeze({ id: "colorLegendSymbols", type: "rect" }),
  strokeInterval: Object.freeze({ id: "strokeIntervalSymbols", type: "rect" })
});

// Symbol patches replace the complete block-local patch. Recreating the concrete
// symbol owner removes properties that existed only in the previous patch before
// the ordinary rematerializer writes the new effective appearance.
function recreateSymbolGraphics(program, descriptor) {
  if (descriptor.family === "gradient") return program;
  if (descriptor.family === "categorical") {
    const symbolIds = legendResourcePolicy(descriptor.kind).graphicIds
      .filter(id => id.includes("Symbol"));
    let next = program;
    for (const id of symbolIds) {
      if (next.graphicSpec.objects[id] !== undefined) {
        next = next.editGraphics({ target: id, remove: true });
      }
    }
    return next.createLegendSymbols({ kind: descriptor.kind });
  }
  const symbol = SPECIALIZED_SYMBOLS[descriptor.kind];
  if (symbol === undefined || program.graphicSpec.objects[symbol.id] === undefined) {
    throw new Error(`editLegendBlock cannot recreate ${descriptor.kind} legend symbols.`);
  }
  const placement = preserveGraphicPlacement(program, symbol.id);
  return program
    .editGraphics({ target: symbol.id, remove: true })
    .createGraphics({ id: symbol.id, ...(descriptor.config.shapeScale===undefined?{type:symbol.type,length:0}:{type:'collection'}), ...placement });
}

function normalizeBlockPatch(args, descriptor, scaleType) {
  const patch = {};
  if (Object.hasOwn(args, "position")) {
    if (args.position === "inherit") patch.removePosition = true;
    else {
      if (!LEGEND_POSITIONS.includes(args.position)) throw new Error("Legend block position requires an anchor or inherit.");
      patch.position = args.position;
    }
  }
  if (Object.hasOwn(args, "title")) {
    if (typeof args.title !== "string") {
      throw new TypeError("editLegendBlock title must be a string.");
    }
    patch.title = args.title;
  }
  if (Object.hasOwn(args, "gap")) {
    validateNonNegativeFinite(args.gap, "editLegendBlock gap");
    patch.gap = args.gap;
  }
  if (Object.hasOwn(args, "text")) patch.text = normalizeTextPatch(args.text);
  if (Object.hasOwn(args, "symbol")) {
    patch.symbol = normalizeSymbolPatch(args.symbol, descriptor);
  }
  if (Object.hasOwn(args, "labelMap")) {
    // Validate eligibility even for a reset, without introducing an empty map owner.
    const map = normalizeLegendDisplayLabelMap(descriptor, args.labelMap === "auto" ? [] : args.labelMap, scaleType);
    if (args.labelMap === "auto") patch.removeLabelMap = true;
    else patch.labelMap = map;
  }
  return patch;
}

export const editLegendBlock = /* @__PURE__ */ action(
  {
    op: "editLegendBlock", scope: "any",
    description: "Edit one logical legend block selected by channel."
  },
  withGuideLayoutValidation(function (args = {}) {
    if (this.compositionSpec !== undefined) return editFacetParentLegend(this, "editLegendBlock", args);
    validateOptionObject(args, OPTIONS, "editLegendBlock");
    if (!Object.hasOwn(args, "target") || typeof args.target !== "string") {
      throw new TypeError("editLegendBlock target must be an explicit legend target id.");
    }
    if (!Object.hasOwn(args, "channel") || typeof args.channel !== "string") {
      throw new TypeError("editLegendBlock channel must be explicit.");
    }
    if (!Object.keys(args).some(key => !["target", "channel"].includes(key))) {
      throw new Error("editLegendBlock requires at least one change.");
    }
    const descriptor = resolveLegendBlock(this, args, "editLegendBlock");
    if ((Object.hasOwn(args, "values") || Object.hasOwn(args, "count")) &&
      descriptor.family !== "sampled") {
      throw new Error("editLegendBlock values and count require a sampled legend block.");
    }
    const patch = normalizeBlockPatch(args, descriptor, this.resolvedScales[descriptor.scaleIds[0]]?.type);
    let config = Object.hasOwn(args, "clipHeight")
      ? patchLegendClipHeight(descriptor.config, args.clipHeight) : descriptor.config;
    validateLegendClip(descriptor.kind, config);
    const blockOverrides = patchLegendBlockOverride(config, descriptor.key, patch);
    if (blockOverrides === undefined) {
      const { blockOverrides: _removed, ...rest } = config;
      config = rest;
    } else {
      config = { ...config, blockOverrides };
    }
    if (Object.hasOwn(args, "values") || Object.hasOwn(args, "count")) {
      const sampling = normalizeLegendSampling(args, {
        previous: config,
        operation: "edit",
        label: `editLegendBlock ${descriptor.channel ?? args.channel} legend`
      });
      if(config.combine==='color-size-shape')validateColorSizeShapeSamples(sampling,this.resolvedScales[config.colorScale]);
      else validateSamplingAgainstScale(sampling, this.resolvedScales[descriptor.scaleIds[0]],
        "editLegendBlock values");
      const { count: _legacyCount, ...withoutCount } = config;
      config = { ...withoutCount, sampling };
    }
    const order = Object.hasOwn(args, "order")
      ? exactCategoricalOrder(this, descriptor, args.order)
      : undefined;
    if (args.title !== undefined && args.title !== "") {
      config = { ...config, title: args.title, inferredTitle: false };
    }
    let next = this._withLegendConfig(descriptor.kind, config);
    const semanticKind = legendResourcePolicy(descriptor.kind).semanticKind;
    if (order !== undefined) {
      next = next.editSemantic({
        property: `guide.legend.${semanticKind}.order`,
        value: order
      });
    }
    if (args.title !== undefined && args.title !== "") {
      next = next.editSemantic({
        property: `guide.legend.${semanticKind}.title`,
        value: args.title
      });
    }
    const effective = resolveEffectiveLegendBlockConfig(next, descriptor.kind,
      next.guideConfigs.legend[descriptor.kind]);
    if (Object.hasOwn(args, "symbol")) {
      next = recreateSymbolGraphics(next, descriptor);
    }
    next = reconcileLegendBlockTitleGraphic(next, descriptor.kind,
      effective.titleVisible !== false);
    return Object.hasOwn(args, "position")
      ? next.editLegend({target: args.target, channel: args.channel, position: args.position})
      : next.rematerializeLegend();
  })
);
