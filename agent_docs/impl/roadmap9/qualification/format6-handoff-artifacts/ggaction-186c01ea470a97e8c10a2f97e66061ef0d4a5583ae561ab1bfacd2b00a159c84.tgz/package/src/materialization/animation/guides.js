import { axisLabelDependencyGroup, axisLabelDependencySnapshot, axisLabelDependencyInk } from "./axisLabelDependencies.js";
import { hasInferredLegendLane } from "./legendLaneGuides.js";
import { legendAxisReferenceKeys, legendAxisLaneMatchesNode } from "./legendAxisLaneState.js";
import { guideAnimationKey } from "../../grammar/animation/guideState.js";
import { legendLaneAnimationMatchesNode } from "./legendLaneState.js";
import { axisTitleAnimationItems } from "./axisTitleGuides.js";
import { axisTitleAnimationMatchesNode } from "./axisTitleState.js";
import { legendGroupAnimationMatchesNode } from "./legendGroupState.js";
import { categoricalLegendAnimationMatchesNode } from "./categoricalLegendState.js";
import { sizeLegendAnimationMatchesNode } from "./sizeLegendState.js";
import { prepareAxisAnimationLayout, normalizeAxisLabelAnimationState, axisLabelAnimationMatchesNode } from "./axisLabelState.js";
import { findCanvasGraphic } from "../graphicHierarchy.js";
import { legendAnimationItems } from "./legendGuides.js";
import { legendAnimationMatchesNode } from "./legendState.js";
import { cloneAndFreeze } from "../../core/immutable.js";
import { validateWorkLimit, validateGeneratedItemLimit } from "../../core/validation.js";
import { cartesianPosition } from "../../grammar/animation/cartesianPosition.js";
import { guideAnimationMatchesNode, normalizeGuideAnimationState } from "../../grammar/animation/guideState.js";
import { resolveAxisLineRange } from "../../grammar/axisGeometry.js";
import { cartesianAxisOwners, axisGraphicIds } from "../../selectors/axes.js";
import { gridNames } from "../../selectors/grids.js";
import { requireSemanticScale } from "../../selectors/scales.js";
import { namespaceGraphicId } from "../../selectors/graphicCapacity.js";
import { graphicScopes } from "../../selectors/graphicScopes.js";
import { resolveCartesianAxisFrameBounds, resolveGuideCoordinateBounds, resolveCoordinatePolarFrame } from "../coordinateBounds.js";
import { axisGuideItems } from "../guides/axisItems.js";
import { guideAnchorItems } from "./guideAnchors.js";
import { valuesFromTickConfig, mapPolarGuideValues } from "../guides/tickValues.js";

function scopedGuides(program, namespaces, spend, axislabels) {
  const result = new Map(), labelLayouts = new Map(), objects = program.graphicSpec.objects;
  const identity = (owner, component, value, line = 0) => ({ namespaces, owner, component, value, line });
  const add = (id, state) => { spend(1 + id.length); result.set(id, normalizeGuideAnimationState(state)); };
  const mapping = (value, config) => cartesianPosition(value, program.resolvedScales[config.scale]);
  const polarFrame = config => {
    const frame = resolveCoordinatePolarFrame(program, config.coordinate);
    return { centerX: frame.centerX, centerY: frame.centerY, availableRadius: frame.availableRadius };
  };
  const angle = () => program.materializationConfigs.guides.axis?.radius?.layout?.angle ?? 0;
  for (const item of axisGuideItems(program, spend)) {
    if (item.component === "title") continue;
    const { channel, component: kind, config } = item;
    const id = identity(item.ownerId, kind, item.rawValue, item.line);
    const cartesian = channel === "x" || channel === "y";
    if (kind === "labels" && cartesian && (hasInferredLegendLane(program, config.position) || config.flush === true || config.rotation !== 0 ||
        program.materializationConfigs.canvas?.plot !== undefined || program.materializationConfigs.canvas?.responsive !== undefined)) {
      if (config.maxWidth !== undefined || config.responsive !== undefined || config.responsiveResult !== undefined || config.lineHeight !== undefined && config.lineHeight !== config.fontSize * 1.2) {
        add(item.graphicId, { identity: id, reason: "guide-layout" });
      } else {
        if (!labelLayouts.has(config)) {
          const frame = resolveCartesianAxisFrameBounds(program, channel, config.position, config.scale, item.ownerId);
          const { width, height } = findCanvasGraphic(program).properties;
          labelLayouts.set(config, prepareAxisAnimationLayout({ values: valuesFromTickConfig(program, config),
            scale: program.resolvedScales[config.scale], config, channel, frame, canvas: { width, height },
            profile: program.materializationConfigs.textMetrics,
            edgeAligned: program.materializationConfigs.canvas?.plot !== undefined || program.materializationConfigs.canvas?.responsive !== undefined }));
        }
        result.set(item.graphicId, normalizeAxisLabelAnimationState({ identity: id, kind: "label-layout", layout: labelLayouts.get(config) }));
      }
      continue;
    }
    const frame = cartesian ? resolveCartesianAxisFrameBounds(program, channel, config.position, config.scale, item.ownerId) : polarFrame(config);
    const policy = cartesian
      ? { side: config.position, alongOffset: config.alongOffset ?? 0,
          ...(kind === "ticks" ? { length: config.length } : { offset: config.offset, lineCount: item.lineCount,
            lineHeight: config.lineHeight ?? config.fontSize * 1.2, align: config.align ?? null }) }
      : { ...(channel === "radius" ? { angle: angle() } : {}),
          ...(kind === "ticks" ? { length: config.length } : { offset: config.offset, align: config.align ?? null }) };
    add(item.graphicId, { identity: id, kind, channel, frame, mapping: mapping(item.rawValue, config), policy });
  }
  for (const owner of cartesianAxisOwners(program)) {
    const id = axisGraphicIds(owner.channel, owner.id)[0], config = owner.config?.line;
    if (config === undefined || objects[id] === undefined) continue;
    const frame = resolveCartesianAxisFrameBounds(program, owner.channel, config.position, owner.scale, owner.id);
    const range = resolveAxisLineRange(program.resolvedScales[owner.scale], frame, owner.channel, Array.isArray(requireSemanticScale(program, owner.scale).range));
    add(id, { identity: identity(owner.id, "line", null), kind: "line", channel: owner.channel, frame, range, policy: { side: config.position } });
  }
  for (const channel of ["theta", "radius"]) {
    const id = axisGraphicIds(channel)[0], config = program.materializationConfigs.guides?.axis?.[channel]?.line;
    if (config === undefined || objects[id] === undefined) continue;
    add(id, { identity: identity(channel, "line", null), kind: "line", channel, frame: polarFrame(config),
      range: channel === "theta" ? [] : program.resolvedScales[config.scale].range,
      policy: channel === "theta" ? {} : { angle: angle() } });
  }
  for (const [direction, config] of Object.entries(program.materializationConfigs.guides?.grid ?? {})) {
    const cartesian = direction === "horizontal" || direction === "vertical";
    const channel = cartesian ? gridNames(direction).channel : direction === "radial" ? "radius" : "theta";
    const id = cartesian ? gridNames(direction).graphic : direction === "radial" ? "radialGridCircles" : "thetaGridLines";
    const object = objects[id];
    if (object === undefined || config.bandPosition === "boundary") continue;
    const values = cartesian ? valuesFromTickConfig(program, config) : (() => {
      const mapped = mapPolarGuideValues(program, config);
      return mapped.values.filter((_, index) => channel !== "radius" || mapped.positions[index] > 0);
    })();
    spend(values.length);
    if (object.items?.length !== values.length) throw new TypeError(`Grid "${id}" has stale semantic item correspondence.`);
    const frame = cartesian ? resolveGuideCoordinateBounds(program, { channel, scale: config.scale, coordinate: config.coordinate }) : polarFrame(config);
    values.forEach((value, index) => add(object.items[index].id, { identity: identity(`grid:${direction}`, "grid", value), kind: "grid", channel,
      frame, mapping: mapping(value, config), policy: cartesian ? { alongOffset: config.alongOffset ?? 0 } : {} }));
  }
  for (const item of guideAnchorItems(program, spend)) {
    const parallel = item.field !== undefined;
    const id = identity(item.owner, parallel ? `parallel-${item.component}` : item.component,
      parallel ? { field: item.field, value: item.value } : item.value, item.line);
    add(item.graphicId, item.reason === undefined ? { identity: id, kind: "anchor", anchor: item.anchor } : { identity: id, reason: item.reason });
  }
  for (const item of axisTitleAnimationItems(program, namespaces, spend, axislabels)) result.set(item.graphicId, item.state);
  for (const item of legendAnimationItems(program, namespaces, spend, [...result.values()], axislabels)) {
    spend(1 + item.graphicId.length);
    result.set(item.graphicId, item.state);
  }
  return result;
}

export function projectGuideAnimationState(program, endpoint, axislabels, maxOutputNodes) {
  validateGeneratedItemLimit(endpoint.scene.nodes.length, "Animation guide endpoint size", maxOutputNodes);
  const states = new Map();
  let work = 0;
  const spend = (count = 1) => validateWorkLimit(work += count, "Animation guide preparation work");
  for (const context of graphicScopes(program, spend)) {
    for (const [id, state] of scopedGuides(context.program, context.namespaces, spend, axislabels)) {
      spend(id.length + context.namespaces.reduce((sum, value) => sum + 6 * value.length + 2, 0));
      const qualified = context.namespaces.reduceRight((value, namespace) => namespaceGraphicId(namespace, value), id);
      if (states.has(qualified)) throw new TypeError("Animation guides contain ambiguous native ownership.");
      states.set(qualified, state);
    }
  }
  const editedGroups = new Set(), editedLanes = new Set();
  const laneKey = state => JSON.stringify([state.identity.namespaces, state.layout.edge]);
  const groupKey = state => JSON.stringify([state.identity.namespaces, state.identity.owner]);
  const projected = endpoint.sources.map((source, index) => {
    const state = states.get(source.graphicId);
    if (state === undefined || state.reason !== undefined || state.kind === "legend-axis-lane") return state ?? null;
    const matches = (state.kind === "legend-lane" ? legendLaneAnimationMatchesNode : state.kind === "title-layout" ? axisTitleAnimationMatchesNode : state.kind === "legend-group" ? legendGroupAnimationMatchesNode : state.kind === "categorical-legend" ? categoricalLegendAnimationMatchesNode : state.kind === "size-legend" ? sizeLegendAnimationMatchesNode : state.kind === "legend" ? legendAnimationMatchesNode : state.kind === "label-layout" ? axisLabelAnimationMatchesNode : guideAnimationMatchesNode)(state, endpoint.scene.nodes[index], state.layout?.labels?.group === undefined ? undefined : axisLabelDependencyInk(axisLabelDependencySnapshot(axisLabelDependencyGroup(axislabels, state.layout.labels.group)), endpoint.scene.nodes[index]));
    if (!matches && state.kind === "legend-group") editedGroups.add(groupKey(state));
    if (!matches && state.kind === "legend-lane") editedLanes.add(laneKey(state));
    return matches ? state : { identity: state.identity, reason: "guide-edited" };
  });
  for (const [index, state] of projected.entries()) {
    if (state?.kind !== "legend-axis-lane") continue;
    spend(projected.length * 2 + state.axes.length);
    const keys = legendAxisReferenceKeys(projected, state.identity.namespaces, state.layout.edge, axislabels);
    const references = new Set(state.axes);
    const dependencies = projected.flatMap((axis, position) => axis !== null && references.has(guideAnimationKey(axis.identity))
      ? [{ state: axis, node: endpoint.scene.nodes[position] }] : []);
    if (JSON.stringify(keys) !== JSON.stringify(state.axes) || !legendAxisLaneMatchesNode(state, endpoint.scene.nodes[index], dependencies, (state.labelGroups ?? []).map(key => ({ key, current: axisLabelDependencySnapshot(axisLabelDependencyGroup(axislabels, key)) })))) {
      editedLanes.add(laneKey(state)); projected[index] = { identity: state.identity, reason: "guide-edited" };
    }
  }
  const editedLabels = new Set(projected.filter(state => state?.identity.component === "labels" && state.reason !== undefined).map(groupKey));
  return cloneAndFreeze(projected.map(state => ["legend-lane", "legend-axis-lane"].includes(state?.kind) && editedLanes.has(laneKey(state))
    ? { identity: state.identity, reason: "guide-edited" } : state?.kind === "title-layout" && state.layout.labels?.group === undefined && editedLabels.has(groupKey(state))
    ? { identity: state.identity, reason: "guide-edited" } : state?.kind === "legend-group" && editedGroups.has(groupKey(state))
    ? { identity: state.identity, reason: "guide-edited" } : state));
}
