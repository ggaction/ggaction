const PRIMITIVE_DRAWABLE_TYPES = new Set([
  "circle",
  "circle-batch",
  "rect",
  "line",
  "text",
  "path",
  "image",
  "weighted-blend"
]);
const DRAWABLE_TYPES = new Set([
  ...PRIMITIVE_DRAWABLE_TYPES,
  "collection"
]);
const STRUCTURAL_TYPES = new Set(["canvas"]);
const GRAPHIC_PROPERTIES = Object.freeze({
  "weighted-blend": new Set(["sources", "opacity", "blend", "length"]),
  canvas: new Set(["x", "y", "width", "height", "background"]),
  collection: new Set([
    "items",
    "x",
    "y",
    "x1",
    "y1",
    "x2",
    "y2",
    "width",
    "height",
    "radius",
    "fill",
    "outline",
    "stroke",
    "strokeWidth",
    "strokeDash",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "fontSize",
    "fontFamily",
    "fontWeight",
    "fontStyle",
    "text",
    "textAlign",
    "textBaseline",
    "rotation",
    "commands",
    "fillRule",
    "opacity"
  ]),
  image: new Set(["image", "x", "y", "width", "height", "opacity", "shadow", "length"]),
  "circle-batch": new Set(["x", "y", "radius", "appearance"]),
  circle: new Set([
    "x",
    "y",
    "radius",
    "fill",
    "outline",
    "stroke",
    "strokeWidth",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "opacity",
    "blend",
    "shadow",
    "length"
  ]),
  rect: new Set([
    "x",
    "y",
    "width",
    "height",
    "fill",
    "outline",
    "stroke",
    "strokeWidth",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "opacity",
    "blend",
    "shadow",
    "length"
  ]),
  line: new Set([
    "x1",
    "y1",
    "x2",
    "y2",
    "stroke",
    "strokeWidth",
    "strokeDash",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "opacity",
    "blend",
    "shadow",
    "length"
  ]),
  text: new Set([
    "fillBounds",
    "font",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "x",
    "y",
    "text",
    "lines",
    "fill",
    "outline",
    "fontSize",
    "fontFamily",
    "fontWeight",
    "fontStyle",
    "textAlign",
    "textBaseline",
    "rotation",
    "opacity",
    "blend",
    "shadow",
    "length"
  ]),
  path: new Set([
    "commands", "maxCommands",
    "fillRule",
    "fill",
    "outline",
    "stroke",
    "strokeWidth",
    "strokeDash",
    "lineCap",
    "lineJoin",
    "miterLimit",
    "opacity",
    "blend",
    "shadow",
    "length"
  ])
});

export function validateGraphicType(type) {
  if (!DRAWABLE_TYPES.has(type) && !STRUCTURAL_TYPES.has(type)) {
    throw new Error(`Unknown graphic type "${type}".`);
  }

  return type;
}

export function isDrawableGraphicType(type) {
  return DRAWABLE_TYPES.has(type);
}

export function isPrimitiveDrawableGraphicType(type) {
  return PRIMITIVE_DRAWABLE_TYPES.has(type);
}

export function isStructuralGraphicType(type) {
  return STRUCTURAL_TYPES.has(type);
}

export function isGraphicContainerType(type) {
  return type === "canvas" || type === "collection";
}

export function validateGraphicProperty(type, property) {
  if (typeof property !== "string" || property.length === 0) {
    throw new TypeError("editGraphics requires a non-empty property string.");
  }

  if (!GRAPHIC_PROPERTIES[type]?.has(property)) {
    throw new Error(`Unknown ${type} graphic property "${property}".`);
  }

  return property;
}
