import { applyMarkBlend } from "../blend.js";
import { validateRequestedMarkBlend } from "../../../grammar/markBlend.js";
import { requestedMarkOutline } from "../../../grammar/markOutline.js";
import { requestedMarkShadow } from "../../../grammar/markShadow.js";
import { validateFillPaint } from "../../../grammar/paint.js";
import { assertIndependentOverlayGeometry } from "../../../grammar/overlay.js";
import { requestedMarkClip, validateMarkClipCoordinate } from "../../../selectors/markClip.js";
import { action } from "../../../core/action.js";
import { validateUserId } from "../../../core/identifiers.js";
import {
  validateNonEmptyString,
  validateNonNegativeFinite,
  validateUnitInterval,
  validatePointItemCapacity,
  validateGraphicItemLimit
} from "../../../core/validation.js";
import { resolveGraphicItemCapacity } from "../../../selectors/graphicCapacity.js";
import { validatePointShape } from "../../../grammar/pointShapes.js";
import {
  requestedStrokeDetails,
  STROKE_STYLE_PROPERTIES
} from "../../../grammar/strokeStyle.js";
import { resolveEligibleLayer } from "../../../selectors/layers.js";
import { rematerializeExistingLegend } from "../../encodings/shared.js";
import { validateMarkOptions } from "../shared.js";
import { validateItemMissing } from "../../../grammar/itemMissing.js";

const OPTIONS = Object.freeze([
  "blend",
  "target", "maxItems", "clip", "missing", "shape", "fill", "opacity", "outline", "shadow", "stroke", "strokeWidth",
  ...STROKE_STYLE_PROPERTIES
]);

export const editPointMark = /* @__PURE__ */ action(
  {
    op: "editPointMark",
    description: "Edit constant point-mark appearance."
  },
  function (args = {}) {
    validateMarkOptions(args, OPTIONS, "editPointMark");
    validateRequestedMarkBlend(args, "point");
    requestedMarkClip(args);
    const strokeDetails = requestedStrokeDetails(args, "editPointMark");
    if (Object.hasOwn(args, "maxItems")) validatePointItemCapacity(args.maxItems);
    const editable = [
      "blend", "maxItems", "clip", "missing", "shape", "fill", "opacity", "outline", "shadow", "stroke", "strokeWidth",
      ...STROKE_STYLE_PROPERTIES
    ];
    if (!editable.some(property => Object.hasOwn(args, property))) {
      throw new Error(
        "editPointMark requires shape, fill, opacity, stroke, strokeWidth, missing, or maxItems."
      );
    }
    if (args.target !== undefined) validateUserId(args.target, "Point mark id");
    const layer = resolveEligibleLayer(this, {
      target: args.target,
      predicate: candidate => candidate.mark?.type === "point",
      label: "point mark"
    });
    if (Object.hasOwn(args, "missing")) assertIndependentOverlayGeometry(layer, "editPointMark missing");
    const id = layer.id;
    if (Object.hasOwn(args, "maxItems")) {
      validateGraphicItemLimit(this.graphicSpec.objects[id]?.items?.length ?? 0, {
        ...resolveGraphicItemCapacity(this, { id, label: "Point mark item count" }),
        maxItems: args.maxItems
      });
    }
    if (Object.hasOwn(args, "shape") && layer.encoding?.shape !== undefined) {
      throw new Error(
        "editPointMark shape cannot be combined with a shape encoding."
      );
    }
    if (Object.hasOwn(args, "fill") && layer.encoding?.color !== undefined) {
      throw new Error(
        "editPointMark fill cannot be combined with a color encoding."
      );
    }
    if (Object.hasOwn(args, "stroke") && layer.encoding?.stroke !== undefined) {
      throw new Error(
        "editPointMark stroke conflicts with a field encoding; use encodeStroke with value to replace it."
      );
    }
    if (Object.hasOwn(args, "opacity") && layer.encoding?.opacity?.field !== undefined) {
      throw new Error("editPointMark opacity conflicts with a field encoding; use encodeOpacity with value to replace it.");
    }
    validateMarkClipCoordinate(this, layer, args.clip ?? this.markConfigs[id]?.clip);
    let semantic = Object.hasOwn(args, "missing")
      ? this.editSemantic({
          property: `layer[${id}].mark.missing`,
          value: validateItemMissing(args.missing, "Point missing")
        })
      : this;
    semantic = applyMarkBlend(semantic, layer.id, args);
    const config = { ...semantic.markConfigs[id], ...requestedMarkClip(args) };
    if (Object.hasOwn(args, "maxItems")) {
      if (args.maxItems === undefined) delete config.maxItems;
      else config.maxItems = args.maxItems;
    }
    Object.assign(config, strokeDetails, requestedMarkOutline(args), requestedMarkShadow(args));
    if (Object.hasOwn(args, "shape")) {
      config.shape = validatePointShape(args.shape);
    }
    if (Object.hasOwn(args, "fill")) {
      config.fill = validateFillPaint(args.fill, "Point fill");
    }
    if (Object.hasOwn(args, "opacity")) {
      config.opacity = validateUnitInterval(args.opacity, "Point opacity");
    }
    if (args.stroke === false && Object.hasOwn(args, "strokeWidth")) {
      throw new Error(
        "editPointMark cannot set strokeWidth while removing stroke."
      );
    }
    if (Object.hasOwn(args, "stroke")) {
      if (args.stroke === false) {
        config.stroke = false;
        delete config.strokeWidth;
      } else {
        const restoresStroke = config.stroke === false;
        config.stroke = validateNonEmptyString(args.stroke, "Point stroke");
        if (restoresStroke) config.strokeWidth = 1;
        else config.strokeWidth ??= 1;
      }
    }
    if (Object.hasOwn(args, "strokeWidth")) {
      if (typeof config.stroke !== "string" && layer.encoding?.stroke?.field === undefined) {
        throw new Error("Point strokeWidth requires an active stroke.");
      }
      config.strokeWidth = validateNonNegativeFinite(
        args.strokeWidth,
        "Point strokeWidth"
      );
    }
    const next = semantic
      ._withMarkConfig(id, config)
      .rematerializePointMark({ id });
    return rematerializeExistingLegend(next);
  }
);
