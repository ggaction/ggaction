import { reviseSourceDataResources } from "./resourceRevision.js";
import { bindFilterTransform } from "./filterBinding.js";
import { ownRecord } from "../../core/ownData.js";
import {resolveDatasetTransformInputs} from "./shared.js";
import { bindComputedTransform } from "./computedBinding.js";
import { action, closedAction } from "../../core/action.js";
import { isPlainObject } from "../../core/immutable.js";
import { validateUserId } from "../../core/identifiers.js";
import { validateKeys, validateWorkLimit } from "../../core/validation.js";
import {orderedDatasetClosure, orderedDatasetDependents} from "../../grammar/datasetDependencies.js";
import {rebindTransformDatasetInputs} from "../../core/datasetReferences.js";
import {
  findTransformPolicy,
  normalizeDatasetTransformEdit,
  requestedDatasetTransform
} from "../../grammar/transforms.js";
import {
  findDataset,
  hasDataset
} from "../../selectors/datasets.js";
import { withLogicalDataReplacements } from
  "../../materialization/revisionIdentity.js";
import { derivedIdentityBase } from "../../grammar/rowLineage.js";
import { withPreparedDatasetIdentity } from "../primitives/datasetIdentity.js";
import {
  outputFieldChanges,
  rebindLayerOutputFields,
  rebindMaterializationDataReferences
} from "./revisionBindings.js";

const GENERIC_OPTIONS = Object.freeze([
  "target", "definition", "dependents"
]);
const DEPENDENT_POLICIES = new Set(["reject", "recompute"]);
const CREATOR_BY_TYPE = Object.freeze({
  bin: "createBinData",
  bin2d: "createBin2DData",
  complete: "createCompleteData",
  computed: "createComputedData",
  density: "createDensityData",
  ecdf: "createECDFData",
  filter: "filterData",
  flatten: "createFlattenData",
  lookup:"createLookupData",
  fold: "createFoldData",
  pivot: "createPivotData",
  impute: "createImputedData",
  interval: "createIntervalData",
  normalize: "createNormalizedData",
  regression: "createRegressionData",
  regressionStatistics: "createRegressionStatisticsData",
  sort: "createSortedData",
  stack: "createStackData",
  summary: "createSummaryData",
  timeUnit: "createTimeUnitData",
  window: "createWindowData"
});
const REVISION_ROLE = Object.freeze({
  bin: "BinData",
  bin2d: "Bin2DData",
  complete: "CompleteData",
  computed: "ComputedData",
  density: "DensityData",
  ecdf: "ECDFData",
  filter: "FilteredData",
  flatten: "FlattenData",
  lookup:"LookupData",
  fold: "FoldData",
  pivot: "PivotData",
  impute: "ImputedData",
  interval: "IntervalData",
  normalize: "NormalizedData",
  regression: "RegressionData",
  regressionStatistics: "RegressionStatisticsData",
  sort: "SortedData",
  stack: "StackData",
  summary: "SummaryData",
  timeUnit: "TimeUnitData",
  window: "WindowData"
});

function ownerRecords(program, type) {
  const families = program.materializationConfigs.data ?? {};
  return Object.entries(families).flatMap(([family, owners]) =>
    Object.entries(owners ?? {}).flatMap(([owner, config]) => {
      if (typeof config?.current !== "string") return [];
      const dataset = findDataset(program, config.current);
      const currentType = dataset?.transform?.[0]?.type ?? family;
      if (type !== undefined && currentType !== type) return [];
      return [{ family, owner, current: config.current, dataset }];
    })
  );
}

function escapedPattern(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function staleOwnerRecord(program, requested, type) {
  return ownerRecords(program, type).find(record => {
    const transformType = record.dataset?.transform?.[0]?.type ?? record.family;
    const role = REVISION_ROLE[transformType];
    if (role === undefined || requested === record.current) return false;
    return new RegExp(
      `^${escapedPattern(record.owner)}${role}Revision\\d+$`
    ).test(requested);
  });
}

function topLevelCreatorRecorded(program, dataset) {
  const creator = CREATOR_BY_TYPE[dataset.transform?.[0]?.type];
  return creator !== undefined && program.trace.children.some(node =>
    node.op === creator && node.args?.id === dataset.id
  );
}

export function resolveDerivedDataOwner(program, target, type) {
  const requested = validateUserId(target, "Derived dataset target");
  const matching = ownerRecords(program, type).filter(record =>
    record.owner === requested || record.current === requested
  );
  if (matching.length > 1) {
    throw new Error(`Derived dataset target "${requested}" is ambiguous.`);
  }
  if (matching.length === 1) {
    const record = matching[0];
    if (record.dataset === undefined) {
      throw new Error(
        `Derived dataset owner "${record.owner}" has no current dataset.`
      );
    }
    return { ...record, lazy: false };
  }

  const dataset = findDataset(program, requested);
  if (dataset === undefined) {
    throw new Error(staleOwnerRecord(program, requested, type) !== undefined
      ? `Derived dataset revision "${requested}" is stale.`
      : `Unknown derived dataset owner "${requested}".`
    );
  }
  if (staleOwnerRecord(program, requested, type) !== undefined) {
    throw new Error(`Derived dataset revision "${requested}" is stale.`);
  }
  if (dataset.source === undefined || dataset.transform?.length !== 1) {
    throw new Error(
      `Dataset "${requested}" is a source dataset and cannot be edited.`
    );
  }
  const currentType = dataset.transform[0].type;
  if (type !== undefined && currentType !== type) {
    throw new Error(
      `Derived dataset "${requested}" is ${currentType}, not ${type}.`
    );
  }
  if (
    findTransformPolicy(currentType)?.editable !== true ||
    !topLevelCreatorRecorded(program, dataset)
  ) {
    throw new Error(
      `Derived dataset "${requested}" is chart-owned; use its owning chart editor.`
    );
  }
  return {
    family: currentType,
    owner: dataset.id,
    current: dataset.id,
    dataset,
    lazy: true
  };
}

export function normalizeDerivedDependentPolicy(value) {
  const policy = value ?? "reject";
  if (!DEPENDENT_POLICIES.has(policy)) {
    throw new Error(
      'Derived data dependents must be "reject" or "recompute".'
    );
  }
  return policy;
}

function downstreamDatasets(program, root) {
  // Statistical reference data is an owned cache; its mark lifecycle replays it.
  const result=orderedDatasetDependents(program.semanticSpec.datasets,root,{skip:dataset=>dataset.transform?.[0]?.type==="statisticalReference"});
  for(const child of result){
      if (child.transform?.length !== 1) {
        throw new Error(
          `Derived dataset "${child.id}" requires one replayable transform.`
        );
      }
      const policy = findTransformPolicy(child.transform[0].type);
      if (typeof policy?.materializeOp !== "string") {
        throw new Error(
          `Derived dataset "${child.id}" has unsupported transform ` +
          `"${child.transform[0].type ?? "unknown"}".`
        );
      }
  }
  return result;
}

function ownerForCurrent(program, dataset) {
  const matches = ownerRecords(program).filter(record =>
    record.current === dataset.id
  );
  if (matches.length > 1) {
    throw new Error(
      `Derived dataset "${dataset.id}" has ambiguous logical ownership.`
    );
  }
  return matches[0];
}

function nextRevisionId(program, owner, role, reserved, occupied) {
  let revision = 1;
  const prefix = `${owner}${role}Revision`;
  while (
    (occupied === undefined ? hasDataset(program, `${prefix}${revision}`) : occupied.has(`${prefix}${revision}`)) ||
    reserved.has(`${prefix}${revision}`)
  ) revision += 1;
  const id = `${prefix}${revision}`;
  reserved.add(id);
  return id;
}

function buildRevisionPlan(
  program,
  resolved,
  definition,
  dependents,
  rootSource = resolved.dataset.source
) {
  const downstream = downstreamDatasets(program, resolved.current);
  if (dependents === "reject" && downstream.length > 0) {
    throw new Error(
      `Cannot edit derived dataset "${resolved.owner}" while derived dataset ` +
      `"${downstream[0].id}" depends on it; use dependents: "recompute".`
    );
  }
  if (downstream.some(dataset => dataset.id === rootSource)) {
    throw new Error(
      `Derived dataset "${resolved.owner}" cannot use one of its dependents as source.`
    );
  }
  if(definition?.type==="lookup"&&[resolved.current,...downstream.map(d=>d.id)].includes(definition.lookup.data))throw new Error(`Derived dataset "${resolved.owner}" cannot use its own result or dependent as lookup data.`);
  const reserved = new Set(resolved.revision === undefined ? [] : [resolved.revision]);
  const revisions = [];
  const replacements = new Map();
  const add = (dataset, ownerRecord, transform, requestedSource) => {
    const owner = ownerRecord?.owner ?? dataset.id;
    const role = REVISION_ROLE[transform.type] ?? "DerivedData";
    const id = nextRevisionId(program, owner, role, reserved);
    const originalSource = requestedSource ?? dataset.source;
    const source = replacements.get(originalSource) ?? originalSource;
    const revision = {
      old: dataset.id,
      id,
      source,
      transform:rebindTransformDatasetInputs(transform,replacements),
      family: ownerRecord?.family,
      owner: ownerRecord?.owner
    };
    revisions.push(revision);
    replacements.set(dataset.id, id);
  };
  if (resolved.revision === undefined) {
    add(resolved.dataset, resolved, definition, rootSource);
  } else {
    revisions.push({ old: resolved.current, id: resolved.revision });
    replacements.set(resolved.current, resolved.revision);
  }
  if (dependents === "recompute") {
    for (const dataset of downstream) {
      const policy = findTransformPolicy(dataset.transform[0].type);
      const transform = policy.replayTransform?.(dataset.transform[0]) ??
        dataset.transform[0];
      add(dataset, ownerForCurrent(program, dataset), transform);
    }
  }
  return { revisions, replacements };
}

function directLayerConsumers(program, data) {
  return program.semanticSpec.layers
    .filter(layer => layer.data === data)
    .map(layer => layer.id);
}

export function applyRevisionPlan(program, resolved, plan, { retain = new Set(), parameterBudget = false } = {}) {
  return withLogicalDataReplacements(plan.replacements, () =>
    applyRevisionPlanWithIdentity(program, resolved, plan, { retain, parameterBudget }));
}

function applyRevisionPlanWithIdentity(program, resolved, plan, { retain, parameterBudget }) {
  const root = plan.revisions[0];
  const changes = resolved === undefined ? new Map() : outputFieldChanges(
    resolved.dataset.transform[0],
    root.transform
  );
  let next = program;
  let work = 0;
  for (const revision of plan.revisions) {
    if (revision.transform === undefined) continue;
    const policy = findTransformPolicy(revision.transform.type);
    const source = findDataset(next, revision.source), previous = findDataset(next, revision.old);
    if (parameterBudget) {
      const complexity = ["computed", "filter"].includes(revision.transform.type) ? (policy.validate(previous.transform[0]) ?? 1) : 1;
      work += (source.values?.length ?? 0) * complexity;
      validateWorkLimit(work, "Parameter revision work");
    }
    const identity = derivedIdentityBase(source, revision.id, previous);
    next = withPreparedDatasetIdentity({
      id: revision.id,
      source: revision.source,
      transform: [revision.transform]
    }, identity, args => next.createDerivedData(args));
    if (revision.transform.type === "markFilter") {
      next = next.rebindLayerData({
        id: revision.transform.target,
        data: revision.source
      });
    }
    next = next[policy.materializeOp]({ id: revision.id });
  }

  const consumers = plan.revisions.flatMap(revision =>
    directLayerConsumers(program, revision.old).map(id => ({
      id,
      old: revision.old,
      data: revision.id,
      root: revision.old === root.old
    }))
  );
  for (const consumer of consumers) {
    next = next.rebindLayerData({ id: consumer.id, data: consumer.data });
  }
  for (const consumer of consumers) {
    if (consumer.root) {
      next = rebindLayerOutputFields(next, consumer.id, changes);
    }
  }

  next = rebindMaterializationDataReferences(next, plan.replacements);
  for (const revision of plan.revisions) {
    if (revision.owner !== undefined) {
      next = next._withMaterializationConfig(
        ["data", revision.family, revision.owner],
        { current: revision.id }
      );
    }
  }
  next = reviseSourceDataResources(next, plan.replacements, consumers.map(consumer => consumer.id));
  for (const revision of [...plan.revisions].reverse()) {
    if (retain.has(revision.old)) continue;
    next = next.releaseDerivedData({ id: revision.old });
  }

  const currentData = plan.replacements.get(program.context.currentData) ??
    program.context.currentData;
  return next._withContext({ ...program.context, currentData });
}

export function buildSourceRevisionPlan(program, source, id) {
  return buildRevisionPlan(program, {
    current: source, dataset: findDataset(program, source), revision: id
  }, undefined, "recompute");
}

// Parameter edits can invalidate several roots of the same dataset DAG. Build
// one union before allocating revisions so a shared lookup/diamond is replayed
// once, after every changed input has been replaced.
export function buildParameterRevisionPlan(program, parameterId, { sourceRevisions = [] } = {}) {
  const datasets = program.semanticSpec.datasets;
  const roots = datasets.filter(dataset => dataset.transform?.some(transform =>
    transform.parameterInputs?.some(ref => ref.kind === "parameter" && ref.id === parameterId)));
  const ordered = orderedDatasetClosure(datasets, [...roots.map(dataset => dataset.id), ...sourceRevisions.map(source => source.old)], {
    skip: dataset => dataset.transform?.[0]?.type === "statisticalReference"
  });
  const owners = new Map(), occupied = new Set(datasets.map(dataset => dataset.id));
  for (const [family, records] of Object.entries(program.materializationConfigs.data ?? {})) {
    for (const [owner, config] of Object.entries(records)) {
      if (typeof config?.current !== "string") continue;
      occupied.add(owner);
      const list = owners.get(config.current) ?? [];
      list.push({ family, owner }); owners.set(config.current, list);
    }
  }
  const revisions = [], replacements = new Map(), reserved = new Set(), raw = new Map();
  for (const source of sourceRevisions) {
    if (raw.has(source.old)) throw new Error(`Source dataset "${source.old}" has multiple revision owners.`);
    const dataset = findDataset(program, source.old);
    if (dataset?.source !== undefined || !Array.isArray(dataset?.values)) {
      throw new Error(`Source "${source.old}" must be a materialized original dataset.`);
    }
    const id = source.id === undefined
      ? nextRevisionId(program, source.owner, "Data", reserved, occupied)
      : validateUserId(source.id, "Source revision dataset id");
    if (source.id !== undefined) {
      if (occupied.has(id) || reserved.has(id)) throw new Error(`Dataset "${id}" already exists.`);
      reserved.add(id);
    }
    raw.set(source.old, { old: source.old, id });
    replacements.set(source.old, id);
  }
  for (const dataset of ordered) {
    if (raw.has(dataset.id)) {
      revisions.push(raw.get(dataset.id));
      continue;
    }
    if (dataset.transform?.length !== 1) throw new Error(`Dataset "${dataset.id}" requires one replayable transform.`);
    const previous = dataset.transform[0], policy = findTransformPolicy(previous.type);
    if (typeof policy?.materializeOp !== "string") throw new Error(`Dataset "${dataset.id}" has no replayable materializer.`);
    const matches = owners.get(dataset.id) ?? [];
    if (matches.length > 1) throw new Error(`Derived dataset "${dataset.id}" has ambiguous logical ownership.`);
    const owner = matches[0];
    const id = nextRevisionId(program, owner?.owner ?? dataset.id,
      REVISION_ROLE[previous.type] ?? "DerivedData", reserved, occupied);
    const transform = policy.replayTransform?.(previous) ?? previous;
    revisions.push({ old: dataset.id, id,
      source: replacements.get(dataset.source) ?? dataset.source,
      transform: rebindTransformDatasetInputs(transform, replacements),
      family: owner?.family, owner: owner?.owner });
    replacements.set(dataset.id, id);
  }
  return { revisions, replacements };
}

function sameRequested(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

export function reviseDerivedData(program, {
  resolved,
  definition,
  dependents = "reject",
  source = resolved.dataset.source
}) {
  const policy = normalizeDerivedDependentPolicy(dependents);
  const plan = buildRevisionPlan(
    program,
    resolved,
    definition,
    policy,
    source
  );
  applyRevisionPlan(program, resolved, plan);
  return applyRevisionPlan(program, resolved, plan);
}

export const editDerivedData = /* @__PURE__ */ closedAction(
  {
    op: "editDerivedData",
    description: "Atomically revise one standalone derived-data definition."
  }, GENERIC_OPTIONS,
  function (args = {}) {
    if (!Object.hasOwn(args, "target")) {
      throw new TypeError("editDerivedData requires target.");
    }
    if (!isPlainObject(args.definition)) {
      throw new TypeError("editDerivedData definition must be a plain object.");
    }
    ownRecord(args.definition, "Derived definition");
    for (const forbidden of ["id", "source", "resolved", "current"]) {
      if (Object.hasOwn(args.definition, forbidden)) {
        throw new Error(`editDerivedData definition cannot include ${forbidden}.`);
      }
    }
    const dependents = normalizeDerivedDependentPolicy(args.dependents);
    const resolved = resolveDerivedDataOwner(
      this,
      args.target,
      args.definition.type
    );
    const definition = resolveDatasetTransformInputs(this,requestedDatasetTransform(args.definition));
    findTransformPolicy(definition.type).validate(definition.type === "computed"
      ? bindComputedTransform(this, findDataset(this, resolved.dataset.source), definition)
      : definition.type === "filter"
        ? bindFilterTransform(this, findDataset(this, resolved.dataset.source), definition)
        : definition);
    const previous = requestedDatasetTransform(resolved.dataset.transform[0]);
    if (sameRequested(definition, previous)) return this;

    return reviseDerivedData(this, { resolved, definition, dependents });
  }
);

function focusedEditor(op, type, properties) {
  const supported = Object.freeze(["target", "dependents", ...properties]);
  return action(
    { op, description: `Partially revise one standalone ${type} dataset.` },
    function (args = {}) {
      validateKeys(args, supported, op);
      if (!Object.hasOwn(args, "target")) {
        throw new TypeError(`${op} requires target.`);
      }
      const patch = Object.fromEntries(Object.entries(args).filter(
        ([key]) => key !== "target" && key !== "dependents"
      ));
      if (Object.keys(patch).length === 0) {
        throw new Error(`${op} requires at least one transform option.`);
      }
      const undefinedKey = Object.keys(patch).find(
        key => patch[key] === undefined
      );
      if (undefinedKey !== undefined) {
        throw new TypeError(
          `${op} ${undefinedKey} cannot be undefined; omission preserves it.`
        );
      }
      const resolved = resolveDerivedDataOwner(this, args.target, type);
      const definition = normalizeDatasetTransformEdit(
        resolved.dataset.transform[0],
        patch,
        resolved.owner
      );
      return this.editDerivedData({
        target: args.target,
        definition,
        ...(args.dependents === undefined
          ? {}
          : { dependents: args.dependents })
      });
    }
  );
}

export const editComputedData = /* @__PURE__ */ focusedEditor(
  "editComputedData", "computed", ["as", "expression"]
);
export const editFilteredData = /* @__PURE__ */ focusedEditor(
  "editFilteredData", "filter", ["field", "oneOf", "noneOf", "predicate", "range", "nulls", "where"]
);
export const editFlattenData = /* @__PURE__ */ focusedEditor(
  "editFlattenData", "flatten", ["fields", "as"]
);
export const editLookupData=/* @__PURE__ */focusedEditor(
  "editLookupData","lookup",["field","lookup"]
);
export const editFoldData = /* @__PURE__ */ focusedEditor(
  "editFoldData", "fold", ["fields", "as"]
);
export const editSummaryData = /* @__PURE__ */ focusedEditor(
  "editSummaryData", "summary", ["groupBy", "aggregates", "members", "weight", "missing", "empty"]
);
export const editBinData = /* @__PURE__ */ focusedEditor(
  "editBinData", "bin", [
    "field", "maxBins", "step", "boundaries", "extent", "nice", "zero",
    "includeEmpty", "members", "as", "weight", "missing"
  ]
);
export const editTimeUnitData = /* @__PURE__ */ focusedEditor(
  "editTimeUnitData", "timeUnit", [
    "field", "unit", "as", "temporalUnit", "timeZone", "weekStartsOn",
    "weekRule", "missing"
  ]
);
export const editWindowData = /* @__PURE__ */ focusedEditor(
  "editWindowData", "window", [
    "partitionBy", "sortBy", "operations", "temporalUnit"
  ]
);
export const editDensityData = /* @__PURE__ */ focusedEditor(
  "editDensityData", "density", [
    "field", "groupBy", "bandwidth", "extent", "steps", "kernel",
    "normalization", "as", "weight", "missing"
  ]
);
export const editStackData = /* @__PURE__ */ focusedEditor(
  "editStackData", "stack", ["category", "group", "value", "mode", "as"]
);
export const editRegressionData = /* @__PURE__ */ focusedEditor(
  "editRegressionData", "regression", [
    "x", "y", "groupBy", "method", "degree", "span", "robustIterations", "confidenceMethod",
    "level", "confidence", "interval", "predict"
  ]
);
export const editSortedData = /* @__PURE__ */ focusedEditor(
  "editSortedData", "sort", ["sortBy"]
);
export const editIntervalData = /* @__PURE__ */ focusedEditor(
  "editIntervalData", "interval", [
    "field", "groupBy", "center", "extent", "method", "level", "missing", "as"
  ]
);
export const editECDFData = /* @__PURE__ */ focusedEditor(
  "editECDFData", "ecdf", [
    "field", "groupBy", "weight", "missing", "as"
  ]
);
export const editNormalizedData = /* @__PURE__ */ focusedEditor(
  "editNormalizedData", "normalize", [
    "field", "as", "groupBy", "method", "variance", "zeroDenominator",
    "baseline", "sortBy"
  ]
);
export const editCompleteData = /* @__PURE__ */ focusedEditor(
  "editCompleteData", "complete", [
    "key", "groupBy", "values", "sequence", "calendar", "fill", "members"
  ]
);
export const editPivotData = /* @__PURE__ */ focusedEditor(
  "editPivotData", "pivot", ["field", "value", "groupBy", "columns", "op", "fill"]
);
export const editImputedData = /* @__PURE__ */ focusedEditor(
  "editImputedData", "impute", [
    "fields", "groupBy", "sortBy", "method", "value", "edges", "maxGap"
  ]
);

export const EDIT_DERIVED_DATA_ACTIONS = Object.freeze({
  editDerivedData,
  editComputedData,
  editFilteredData,
  editFlattenData,
  editLookupData,
  editFoldData,
  editSummaryData,
  editBinData,
  editTimeUnitData,
  editWindowData,
  editDensityData,
  editStackData,
  editRegressionData,
  editSortedData,
  editIntervalData,
  editECDFData,
  editNormalizedData,
  editCompleteData,
  editPivotData,
  editImputedData
});
