import { validateRadialMapping } from "../scales/radial.js";
import { validateAggregate } from "../aggregate.js";
import { validateNonEmptyString } from "../../core/validation.js";
import { emptyPositionPolicy } from "./common.js";

export function resolveArcPositionPolicy({ channel, args, fieldType, layer }) {
  if (args.bin !== undefined) {
    throw new Error(`Arc ${channel} encoding does not support bin.`);
  }
  if (args.stack !== undefined) {
    throw new Error(`Arc ${channel} encoding does not support stack.`);
  }
  if (channel === "radius") {
    if (args.mapping !== undefined) {
      validateRadialMapping(args.mapping);
      if (fieldType !== "quantitative" || !["count", "sum"].includes(args.aggregate)) {
        throw new Error("Measured radius requires quantitative count or sum aggregation.");
      }
      if (args.aggregate === "count" && Object.hasOwn(args, "field")) {
        throw new Error("Measured radius count does not accept a field.");
      }
      if (layer.encoding?.theta?.aggregate !== undefined) {
        throw new Error("Measured radius requires equal-angle theta without aggregation.");
      }
      return { ...emptyPositionPolicy(), aggregate: args.aggregate };
    }
    if (args.aggregate !== undefined) {
      if (!["count", "sum"].includes(args.aggregate)) throw new Error("Arc radius aggregate supports count or sum.");
      const theta = layer.encoding?.theta;
      if (theta !== undefined && !["count", "sum"].includes(theta.aggregate)) {
        throw new Error("Grouped arc radius requires aggregated categorical theta.");
      }
      if (args.aggregate === "count" && Object.hasOwn(args, "field")) {
        throw new Error("Arc radius count does not accept a field.");
      }
      if (args.weight !== undefined) throw new Error("Arc radius encoding does not support weight.");
      return { ...emptyPositionPolicy(), aggregate: args.aggregate };
    }
    if (args.weight !== undefined) {
      throw new Error("Arc radius encoding does not support weight.");
    }
    return emptyPositionPolicy();
  }
  if (fieldType === "quantitative") {
    if (layer.encoding?.radius?.aggregate !== undefined) {
      throw new Error("Grouped arc radius requires aggregated categorical theta.");
    }
    if (args.aggregate !== undefined) {
      throw new Error("Quantitative arc theta does not support aggregate.");
    }
    if (args.weight !== undefined) {
      throw new Error("Quantitative arc theta does not support weight.");
    }
    return emptyPositionPolicy();
  }
  if (!["ordinal", "nominal"].includes(fieldType)) {
    throw new Error(
      "Arc theta encoding requires a quantitative, ordinal, or nominal field."
    );
  }
  if (args.aggregate === undefined) {
    if (args.weight !== undefined) {
      throw new Error('Arc theta weight requires aggregate: "sum".');
    }
    return emptyPositionPolicy();
  }
  const aggregate = validateAggregate(args.aggregate);
  if (!["count", "sum"].includes(aggregate)) {
    throw new Error('Arc theta aggregate supports only "count" or "sum".');
  }
  if (aggregate === "count") {
    if (args.weight !== undefined) {
      throw new Error('Arc theta weight requires aggregate: "sum".');
    }
    return { bin: undefined, aggregate, stack: undefined, weight: undefined };
  }
  if (args.weight === undefined) {
    throw new Error('Arc theta aggregate "sum" requires weight.');
  }
  return {
    bin: undefined,
    aggregate,
    stack: undefined,
    weight: validateNonEmptyString(args.weight, "Arc theta weight")
  };
}
