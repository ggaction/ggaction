import { applyMarkBlend } from "../blend.js";
import { validateRequestedMarkBlend } from "../../../grammar/markBlend.js";
import { requestedMarkOutline } from "../../../grammar/markOutline.js";
import { requestedMarkShadow } from "../../../grammar/markShadow.js";
import { requestedMarkClip } from "../../../selectors/markClip.js";
import { action } from "../../../core/action.js";
import { validatePointShape } from "../../../grammar/pointShapes.js";
import { getPointGraphicType } from "../../../grammar/schemas/mark.js";
import {
  requestedStrokeDetails,
  STROKE_STYLE_PROPERTIES
} from "../../../grammar/strokeStyle.js";
import { resolveMarkGraphicPlacement } from
  "../../../materialization/graphicHierarchy.js";
import {
  applyLayeredMarkInheritance,
  assertMarkAvailable,
  materializeInheritedMark,
  resolveLayeredMarkInheritance,
  resolveMarkData,
  resolveMarkId,
  validateMarkOptions
} from "../shared.js";
import { validateItemMissing } from "../../../grammar/itemMissing.js";
import { validatePointItemCapacity } from "../../../core/validation.js";

const OPTIONS = Object.freeze([
  "blend",
  "clip", "id", "data", "maxItems", "missing", "shape", "fill", "opacity", "outline", "shadow", "stroke", "strokeWidth",
  ...STROKE_STYLE_PROPERTIES
]);

export const createPointMark = /* @__PURE__ */ action(
  {
    op: "createPointMark",
    description: "Create a semantic point mark and concrete point graphics."
  },
  function (args = {}) {
    validateMarkOptions(args, OPTIONS, "createPointMark");
    validateRequestedMarkBlend(args, "point");
    requestedMarkClip(args);
    requestedMarkOutline(args);
    requestedMarkShadow(args);
    requestedStrokeDetails(args, "createPointMark");
    const maxItems = validatePointItemCapacity(args.maxItems);
    const id = resolveMarkId(this, args.id, {
      defaultId: "point",
      label: "Point mark id",
      markType: "point",
      operation: "createPointMark"
    });
    const inherited = resolveLayeredMarkInheritance(this, args, "point");
    const { data, dataset } = resolveMarkData(this, {
      ...args,
      ...(args.data === undefined &&
        this.context.currentData === undefined &&
        inherited?.data !== undefined
        ? { data: inherited.data }
        : {})
    });
    const shape = validatePointShape(Object.hasOwn(args, "shape") ? args.shape : "circle");
    const resolvedType = getPointGraphicType(shape);
    const graphicType = resolvedType === "path" ? "circle" : resolvedType;

    assertMarkAvailable(this, id);

    let next = this
      .editSemantic({
        property: `layer[${id}].mark.type`,
        value: "point"
      })
      .editSemantic({
        property: `layer[${id}].data`,
        value: data
      });
    if (Object.hasOwn(args, "missing")) {
      next = next.editSemantic({
        property: `layer[${id}].mark.missing`,
        value: validateItemMissing(args.missing, "Point missing")
      });
    }
    next = applyMarkBlend(next, id, args);
    next = applyLayeredMarkInheritance(next, id, inherited)
      ._withMarkConfig(id, { shape, ...(args.maxItems === undefined ? {} : { maxItems }) })
      .createGraphics({
        id,
        type: graphicType,
        length: dataset.values.length,
        ...resolveMarkGraphicPlacement(next, { data, markType: "point" })
      });
    const created = materializeInheritedMark(next, id);
    const appearance = Object.fromEntries(
      ["clip", "fill", "opacity", "outline", "shadow", "stroke", "strokeWidth", ...STROKE_STYLE_PROPERTIES]
        .filter(property => Object.hasOwn(args, property))
        .map(property => [property, args[property]])
    );
    return Object.keys(appearance).length === 0
      ? created
      : created.editPointMark({ target: id, ...appearance });
  }
);
