import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {chromium} from 'playwright';
import AxeBuilder from '@axe-core/playwright';
const root=process.argv[2];
assert.ok(root, 'Expected a gallery directory');
const manifest=JSON.parse(await readFile(root+'/manifest.json','utf8'));
assert.equal(manifest.dirty,false);
assert.equal(manifest.charts.length,39);
assert.equal(manifest.charts.filter(c=>c.kind==='real').length,25);
assert.equal(manifest.charts.filter(c=>c.newType).length,17);
for(const c of manifest.charts) for(const [name,proof] of Object.entries(c.files??{})) {const b=await readFile(root+'/'+name);assert.equal(b.length,proof.bytes);assert.equal(createHash('sha256').update(b).digest('hex'),proof.sha256);}
const browser=await chromium.launch({headless:true}),errors=[];
const context=await browser.newContext({viewport:{width:1440,height:1000}});
const page=await context.newPage();
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto(pathToFileURL(root+'/index.html').href);
assert.equal(await page.locator('.card:visible').count(),17);
assert.equal(await page.locator('[data-filter=new]').getAttribute('aria-pressed'),'true');
await page.locator('[data-filter=all]').click();
await page.locator('.preview img').evaluateAll(images=>images.forEach(i=>i.loading='eager'));
await page.waitForFunction(()=>[...document.querySelectorAll('.preview img')].every(i=>i.complete&&i.naturalWidth>0));
assert.equal(await page.locator('.card:visible').count(),39);
for(const c of manifest.charts.filter(c=>c.kind==='real')) {
 await page.locator(`.preview[data-id="${c.id}"]`).click();
 await page.locator('#large').evaluate(i=>i.decode());
 await page.locator('#svg').click();await page.locator('#large').evaluate(i=>i.decode());
 assert.equal(await page.locator('#svg').getAttribute('aria-pressed'),'true');
 await page.keyboard.press('Escape');assert.equal(await page.locator('#viewer').evaluate(d=>d.open),false);
}
await page.locator('[data-filter=new]').click();await page.locator('input').fill('OHLC');assert.equal(await page.locator('.card:visible').count(),1);await page.locator('input').fill('');
for(const width of [1440,768,390]) {
 await page.setViewportSize({width,height:1000});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,`overflow ${width}`);
 const result=await new AxeBuilder({page}).analyze();await writeFile(`.artifacts/recipe-gallery-axe-${width}.json`,JSON.stringify(result.violations,null,2));assert.deepEqual(result.violations.map(v=>v.id),[],`axe ${width}`);
 await page.screenshot({path:`.artifacts/recipe-gallery-${width}.png`,fullPage:width===390});
}
assert.deepEqual(errors,[]);await browser.close();
const result={charts:manifest.charts.length,newRealData:17,realData:manifest.charts.filter(c=>c.kind==='real').length,images:39,svgPreviews:25,widths:[1440,768,390],consoleErrors:errors,assetHashes:'passed',keyboardSearchFilter:'passed',axeViolations:0};
await writeFile('.artifacts/recipe-gallery-qa.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
