from pathlib import Path
import json,gzip,hashlib,re

p=Path('.artifacts/frame-profile')
out=Path('agent_docs/impl/roadmap9/qualification/frame-appearance-reuse-evidence')
checks={}
for name in ['owning.log','coverage.log','boundaries.log','package-contracts.log','browser.log','docs.log']:
    content=(p/name).read_text();assert '# fail 0' in content,name
    checks[name]=int(re.search(r'# tests (\d+)',content)[1])
assert re.search(r'appearance\.js\s*\|\s*100\.00\s*\|\s*100\.00\s*\|\s*100\.00',(p/'coverage.log').read_text())
archive=json.loads((p/'frozen.json').read_text())
installed=[]
for version in [20,22,24]:
    receipt=json.loads((p/f'installed-{version}.json').read_text())
    assert receipt['status']=='passed' and receipt['sha256']==archive['sha256']
    assert len(receipt['checks'])==6 and all(value['status']=='passed' for value in receipt['checks'])
    assert receipt['types']=='passed' and len(receipt['bundles'])==6
    installed.append(receipt)
    pack=json.loads((p/f'pack{version}.json').read_text())
    assert pack['entryCount']==1251 and pack['unpackedBytes']==8087851 and pack['packedBytes']<=1795700
assert 'checked 186 built documentation pages' in (p/'built.log').read_text()
assert 'verified 1606 selective LLM artifacts' in (p/'built.log').read_text()
allocation=json.loads((p/'same-plan-allocations.json').read_text())
assert allocation['exactFrameEqual'] and allocation['count']==1000
assert allocation['delta']=={'calls':-1000,'allocations':-1000,'ownedAdds':-1000}
assert hashlib.sha256(Path('src/animation/appearance.js').read_bytes()).hexdigest()==json.loads((p/'after-allocations.json').read_text())['sourceSHA256']
files={}
for file in p.iterdir():
    if file.is_file() and file.suffix in ['.log','.json','.stderr','.mjs','.py','.cpuprofile','.txt']:
        raw=file.read_bytes();(out/(file.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
        files[file.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
qualification={
    'status':'empty-appearance-patch-reuse-verified; full-native-performance-pending',
    'base':'a37b82e423b8de17270900aad8f732e5d907ecfe',
    'approval':'../../AUTHORIZATION.json#remainingApproval',
    'scope':'Reuse one deeply owned empty appearance patch only after authentic plan and progress validation; no API/schema/math/guard/SLO change',
    'sourceSHA256':hashlib.sha256(Path('src/animation/appearance.js').read_bytes()).hexdigest(),
    'archive':archive,'checks':checks,'installed':installed,
    'critical':{'animation/appearance.js':{'lines':100,'branches':100,'functions':100,'actualRootRun':True}},
    'built':{'pages':186,'selectiveArtifacts':1606,'status':'passed'},
    'allocationAttribution':allocation,
    'limits':{'entries':1251,'packedBytes':1795700,'unpackedBytes':8087900,'FullGzip':786200,'animationGzip':333800},
    'profile':{'count':1000,'warmup':5,'samples':30,'runtime':'Node22 with temporary CPU profiler','qualification':False,'sourceBase':'a37b82e42','afterWorkingCopySourceSHA256':hashlib.sha256(Path('src/animation/appearance.js').read_bytes()).hexdigest(),'timingComparisonClaimed':False,'reason':'Small attribution runs and concurrent peer functional load do not establish browser P95 or a before/after speedup'},
    'corrections':[
        'Initial unit command named a missing sample.test.js; corrected to existing owning files before29passing checks',
        'Independent program creations yielded different complete frame digests; only the subsequent same-authentic-plan baseline/optimized comparison is exact full-frame evidence',
        'The after raw CPU report source field names the base revision; after working-copy appearance SHA is pinned separately here'
    ],
    'reuse':{'builtBrowser':'Public prose, snippets, CSS and UI unchanged; responsive/accessibility evidence reused; two actual Canvas/SVG animation browser regressions rerun'},
    'pending':['Large100k common frame performance and Canvas playback','Combined native P95/heap/lifecycle qualification','Sequential STEP057-070 and final required suites'],
    'evidenceFiles':files
}
(out/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'checks':checks,'archive':archive['sha256'],'allocationDelta':allocation['delta']}))
