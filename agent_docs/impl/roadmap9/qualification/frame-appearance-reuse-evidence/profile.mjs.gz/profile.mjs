import {Session} from 'node:inspector/promises';
import {writeFile} from 'node:fs/promises';
import {prepareNativeWorkload} from '../../scripts/benchmarks/workloads.browser.js';

const workload=prepareNativeWorkload('points',1000);
const stage=workload.stages.find(stage=>stage.name==='full-frame').prepare();
for(let index=0;index<5;index++)stage.validate(stage.run());
const inspector=new Session(); inspector.connect();
await inspector.post('Profiler.enable');
await inspector.post('Profiler.setSamplingInterval',{interval:250});
await inspector.post('Profiler.start');
const timings=[];let last;
for(let index=0;index<30;index++) {last=stage.run();timings.push(last.metrics.fullFrameSampleMs);}
const {profile}=await inspector.post('Profiler.stop'); inspector.disconnect();
const witness=stage.validate(last);
await writeFile(new URL('./sample-1000.cpuprofile',import.meta.url),JSON.stringify(profile));
const nodes=new Map(profile.nodes.map(node=>[node.id,node]));
const byLocation=new Map();
for(let index=0;index<profile.samples.length;index++){
 const node=nodes.get(profile.samples[index]),frame=node.callFrame;
 const key=JSON.stringify([frame.functionName,frame.url,frame.lineNumber+1]);
 byLocation.set(key,(byLocation.get(key)??0)+(profile.timeDeltas[index]??250));
}
const top=[...byLocation].sort((a,b)=>b[1]-a[1]).slice(0,30).map(([key,microseconds])=>({location:JSON.parse(key),microseconds}));
const report={kind:'small-attribution-diagnostic-not-browser-SLO',source:'a37b82e423b8de17270900aad8f732e5d907ecfe',count:1000,warmup:5,samples:30,timings,witness,top};
await writeFile(new URL('./sample-1000.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({count:1000,timings,top:top.slice(0,15)}));
