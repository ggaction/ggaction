import {registerHooks} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const phase=process.argv[2];
if(!['before','after'].includes(phase))throw Error('Expected before or after');
const immutableUrl=new URL('../../src/core/immutable.js',import.meta.url).href;
const appearanceUrl=new URL('../../src/animation/appearance.js',import.meta.url).href;
const baseline=await readFile(new URL('./appearance-before.js.txt',import.meta.url),'utf8');
registerHooks({load(url,context,next){
 const result=next(url,context);let source=String(result.source);
 if(url===appearanceUrl&&phase==='before')return {...result,source:baseline};
 if(url!==immutableUrl)return result;
 const entry='export function cloneAndFreeze(value, ancestors = new WeakSet(), path = "state") {';
 const allocation='const clone = array ? new Array(input.length) : {};';
 const freeze='Object.freeze(value);';
 for(const marker of [entry,allocation,freeze])if(!source.includes(marker))throw Error('Instrumentation owner changed');
 source=source.replace(entry,entry+'\n  if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.calls++;');
 source=source.replace(allocation,allocation+'\n    if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.allocations++;');
 source=source.replace(freeze,freeze+'\n    if(globalThis.__frameAllocationCounters)globalThis.__frameAllocationCounters.ownedAdds++;');
 return {...result,source};
}});
const {prepareNativeWorkload}=await import('../../scripts/benchmarks/workloads.browser.js');
const workload=prepareNativeWorkload('points',1000),stage=workload.stages.find(value=>value.name==='full-frame').prepare();
globalThis.__frameAllocationCounters={calls:0,allocations:0,ownedAdds:0};
const result=stage.run(),counts=globalThis.__frameAllocationCounters;
delete globalThis.__frameAllocationCounters;
const witness=stage.validate(result);
const frame=result.frame;
const json=JSON.stringify(frame);
const report={kind:'temporary-loader-allocation-attribution-not-performance',phase,count:1000,counts,witness,
 frameSHA256:createHash('sha256').update(json).digest('hex'),
 sourceSHA256:createHash('sha256').update(phase==='before'?baseline:await readFile(new URL('../../src/animation/appearance.js',import.meta.url))).digest('hex')};
await writeFile(new URL(`./${phase}-allocations.json`,import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
