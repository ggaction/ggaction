from pathlib import Path
import json, gzip, hashlib, re

p = Path('.artifacts/inference-validation-merged')
out = Path('agent_docs/impl/roadmap9/qualification/inference-validation-merged-evidence')
out.mkdir(exist_ok=True)
checks = {}
for name in ['focused.log', 'owning-small.log', 'owning-large.log', 'contracts.log', 'package-contracts.log', 'coverage-policy.log', 'docs.log', 'browser.log']:
    content = (p / name).read_text()
    assert '# fail 0' in content, name
    checks[name] = int(re.search(r'# tests (\d+)', content)[1])

archive = json.loads((p / 'frozen.json').read_text())
installed = []
for version in [20, 22, 24]:
    receipt = json.loads((p / f'installed-{version}.json').read_text())
    assert receipt['status'] == 'passed' and receipt['sha256'] == archive['sha256']
    assert len(receipt['checks']) == 5 and all(entry['status'] == 'passed' for entry in receipt['checks'])
    assert receipt['types'] == 'passed' and len(receipt['snippets']) == 2 and len(receipt['bundles']) == 6
    installed.append(receipt)
    packed = json.loads((p / f'pack{version}.json').read_text())
    assert packed['entryCount'] == 1251 and packed['unpackedBytes'] == 8087760

same = json.loads((p / 'source-equality.json').read_text())
assert same['different'] == [] and len(same['files']) == 4
coverage = json.loads((p / 'coverage-reuse.json').read_text())
assert coverage['sourceExact'] and len(coverage['criticalOwners']) == 4
assert 'checked 186 built documentation pages' in (p / 'built.log').read_text()
assert 'verified 1606 selective LLM artifacts' in (p / 'built.log').read_text()

browser = None
for line in (p / 'browser.log').read_text().splitlines():
    if 'functional-single-run-not-P95' in line:
        browser = json.loads(line[line.index('{'):])
assert browser and browser['kind'] == 'functional-single-run-not-P95'
assert [(entry['count'], entry['edges']) for entry in browser['results']] == [(100, 1000), (1000, 10000), (10000, 100000)]

files = {}
for file in p.iterdir():
    if file.is_file() and file.suffix in ['.log', '.json', '.stderr', '.mjs', '.py']:
        raw = file.read_bytes()
        (out / (file.name + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
        files[file.name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

qualification = {
    'status': 'inference-validation-refinements-integrated; final-native-qualification-pending',
    'base': '74bab1363',
    'incoming': 'fa943e864982783ae8ae10bc18a4257ea8f0b2bb',
    'approval': '../../AUTHORIZATION.json#remainingApproval',
    'scope': 'Exact immutable completion/job/model/prepared-resource proofs and allocation-free JSON UTF-8 byte counts; no public API, schema, solver, hash, work, fixture or SLO changes',
    'archive': archive,
    'sourceInputEquality': same,
    'checks': checks,
    'installed': installed,
    'built': {'pages': 186, 'selectiveArtifacts': 1606, 'status': 'passed'},
    'coverage': coverage,
    'limits': {'entries': 1251, 'packedBytes': 1795700, 'unpackedBytes': 8087800, 'FullGzip': 786200, 'graphGzip': 67900},
    'browser': {**browser, 'actualWorker': True, 'allOriginalNodesAndEdges': True, 'qualification': False},
    'firstFailures': {
        'pack20-first.log': 'Packed1795679 exceeds1795000; final minimum hundred ceiling1795700; unpacked8087760 ceiling8087800',
        'contracts-first.log': 'A realistic-suite selector was passed to contracts; corrected to its owning suite before execution'
    },
    'reuse': {'builtBrowser': 'Unchanged public prose, snippets, UI, layouts and CSS reuse prior responsive/accessibility evidence; source docs/build/identity checks actually rerun'},
    'pending': ['Original combined AT82 P95/retained heap/100-cycle qualification', 'Final combined candidate required suites', 'Sequential STEP057-070 completion'],
    'evidenceFiles': files
}
(out / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps({'checks': checks, 'archive': archive['sha256'], 'browser': browser}))
