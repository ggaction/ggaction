from pathlib import Path
import gzip,hashlib,json,re,subprocess
base=Path('.artifacts/consumer-isolation-merged'); out=Path('agent_docs/impl/roadmap9/qualification/consumer-isolation-merged-evidence')
def sha(b):return hashlib.sha256(b).hexdigest()
run=json.loads((base/'full/run.json').read_text()); records=json.loads((base/'full/node-cases.json').read_text())
assert run['status']=='passed' and run['cleaned'] and len(records)==404
checks={}
for name in ['owning-node22.log','canary-node20.log','canary-node24.log','manifest-node22.log','docs-boundaries.log']:
 s=(base/name).read_text();assert re.search(r'(?:#|ℹ) fail 0',s),name;checks[name]=int(re.search(r'(?:#|ℹ) tests (\d+)',s)[1])
fixtures={}
for p in sorted(Path('scripts/consumers/fixtures/node').glob('*.mjs')):
 current=p.read_bytes(); previous=subprocess.check_output(['git','show','ea58615f9:'+str(p)]); assert current==previous;fixtures[str(p)]=sha(current)
assert len(fixtures)==70
changed=subprocess.check_output(['git','diff','HEAD','--','src','types','package.json','package-lock.json'],text=True);assert not changed
inputs={str(p):sha(p.read_bytes()) for p in [Path('scripts/consumers/node-cases.mjs'),Path('scripts/consumers/node.js'),Path('scripts/consumers/fixtures/node/manifest.json'),Path('test/contracts/consumer-isolation.test.js')]}
q={'status':'consumer-isolation-integrated; product-long-lived-stall-and-final-closeout-pending','base':'ea58615f9d0950b27267d9f407f9f002328efe6c','upstream':'31763c9150cdf4d0bc534f45a64ab502f4891b66','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Same installed archive/fixture bytes and order, explicit four-case process lifetime only; no product/API/schema/guard/heap/SLO change.','archive':{k:run[k] for k in ['archive','sha256','integrity','installedIntegrity']},'checks':checks,'consumer':run,'fixtures':fixtures,'executionInputs':inputs,'rootRepair':'Preserve throw null/undefined/string and import-null as failures in both execution modes; importFailed sentinel preserves falsy import rejection and later cases.','performanceClaim':False,'pending':['Long-lived mixed workload WeakSet rehash attribution and actual retained100cycle','Common sample50ms/Canvas performance','Final nine commands and STEP057-077 closeout'],'evidenceFiles':{}}
files=[*base.glob('*.log'),base/'full/run.json',base/'full/node-cases.json',base/'record.py']
for p in files:
 raw=p.read_bytes();name=('full-'+p.name if p.parent.name=='full' else p.name);(out/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][name]={'sha256':sha(raw),'bytes':len(raw)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(checks,run['cases'],run['durationMs'])
