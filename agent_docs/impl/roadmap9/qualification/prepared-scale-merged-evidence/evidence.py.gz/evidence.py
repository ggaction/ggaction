from pathlib import Path
import gzip,hashlib,json,re,subprocess
b=Path('.artifacts/prepared-scale-merged');d=Path('agent_docs/impl/roadmap9/qualification/prepared-scale-merged-evidence');d.mkdir(exist_ok=True)
def sha(v):return hashlib.sha256(v).hexdigest()
checks={}
for name in ['coverage.log','boundaries.log','manifest.log','docs.log','render.log','source-browser.log']:
 s=(b/name).read_text();assert '# fail 0' in s,name;checks[name]=int(re.search(r'# tests (\d+)',s)[1])
critical={}
for file in ['planner.js','positions.js']:
 s=(b/'coverage.log').read_text();m=re.search(r'\b'+re.escape(file)+r'\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)',s);vals=list(map(float,m.groups()));assert vals[0]>=95 and vals[1]>=90 and vals[2]==100;critical[file]=dict(zip(['lines','branches','functions'],vals))
sources={}
for f in ['src/animation/planner.js','src/grammar/animation/positions.js']:
 raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','f689244fc:'+f]);sources[f]=sha(raw)
archive=json.loads((b/'frozen.json').read_text());consumers=[]
for version in [20,22,24]:
 q=json.loads((b/f'installed-{version}.json').read_text());assert q['status']=='passed' and q['artifact']['sha256']==archive['sha256'];consumers.append(q)
compare=json.loads((b/'product-compare.json').read_text());browser=json.loads((b/'browser-installed.json').read_text());assert browser['status']=='passed' and browser['archiveSHA256']==archive['sha256']
assert (b/'browser-installed.json').exists()  # canonical run() throws on failure and intentionally captures stdout
manifest=json.loads(Path('scripts/consumers/fixtures/node/manifest.json').read_text());assert len(manifest)==71 and sum(len(m['cases']) for m in manifest)==406 and sum(len(m['cases']) for m in manifest if m.get('isolation'))==4
q={'status':'prepared-scales-integrated; sample50ms-and-final-closeout-pending','base':'04ce0871f','upstreamSource':'f689244fc4369d3cd949ca2d6c11998480972d55','upstreamPin':'2fb36c76d79d7f5c85cbc931e7413772af2dc858','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Exact two-file prepared scale interning and one-slot sampled scale reuse, max4 normalized scales per assembly; existing value mapping/finite/error/work checks retained.','sourceSHA256':sources,'archive':archive,'checks':checks,'critical':critical,'consumers':consumers,'installedBrowser':browser,'product1000':compare,'packMeasurements':{str(v):json.loads((b/f'pack{v}.json').read_text()) for v in [20,22,24]},'documentation':{'builtPages':186,'llmArtifacts':1607},'manifestIntegration':{'modules':71,'cases':406,'isolatedCases':4,'note':'Retain root Geo cases, isolation flags and corrected AST counts; append two new point-scale public cases.'},'artifactPolicy':{'entries':1258,'packedBytes':1811600,'unpackedBytes':8152200,'animationGzip':340800,'measuredNode20Packed':1811511,'measuredNode20AnimationGzip':340708,'runtimeGuardsChanged':False},'reusedEvidence':[{'path':'../prepared-scale-reuse-evidence/qualification.json','boundary':'Both changed runtime files byte-exact; reuse source-specific original100k scalar/work/full-frame functional proof. Root fresh full757 owning, actual1k before/after and same new archive three-Node small public/type/docs/bundle + production-minified browser verify composition. No same-SHA100k or SLO claim.'},{'path':'../sha256-merged-evidence/qualification.json','boundary':'SHA state and all non-animation owners unchanged; direct scalar/hash proof retained. No new whole-suite or long-lived100cycle claim.'}], 'initialFailuresRetained':['Unknown action-contracts selector rejected before execution; corrected to actual action-catalog owner.','Documented animation bundle ceiling initially stale after measured cap update; corrected canonical architecture table and reran9contracts.', 'Node20 pack1811511 exceeded old1810900; unpacked8152110 measured and new minimum artifact ceilings recorded.','Evidence-only installed script initially resolved wrong relative script path, corrected before successful same-archive runs.'],'pending':['Common sample50ms/Canvas and partition performance','Geo camera v5/native consistency and hit limits','Data responsiveness, route bounded policy/native closure, large solvers','Long-lived mixed workload WeakSet attribution and retained100cycle','Final9commands/independent review/STEP057-077 closeout'],'evidenceFiles':{}}
for p in sorted(b.iterdir()):
 if p.is_file() and p.suffix in ['.log','.json','.mjs','.py']:
  raw=p.read_bytes();(d/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':sha(raw),'bytes':len(raw)}
raw=Path('.artifacts/animation-small-installed.mjs').read_bytes();(d/'animation-small-installed.mjs.gz').write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles']['animation-small-installed.mjs']={'sha256':sha(raw),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(checks,critical,archive['sha256'])
