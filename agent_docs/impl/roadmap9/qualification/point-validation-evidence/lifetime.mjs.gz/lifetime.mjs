import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {chart} from '../../src/index.js';
import {planTransition,sampleTransition} from '../../src/animation.js';
import {animationFrameProvenance} from '../../src/animation/frameProvenance.js';
import {isOwned} from '../../src/core/immutable.js';
assert.equal(typeof global.gc,'function');
const options={durationMs:100,easing:'linear',formatVersion:6};
const from=chart().createCanvas({width:400,height:400,margin:20,plotBorder:false}).createData({id:'rows',keyField:'id',values:Array.from({length:1000},(_,id)=>({id,x:(id+1)/1001,y:(1000-id)/1001}))}).createPointMark({id:'points'}).encodeX({field:'x',scale:{id:'x',domain:[0,1],nice:false}}).encodeY({field:'y',scale:{id:'y',domain:[0,1],nice:false}}),to=from.editScale({id:'x',domain:[0,2],nice:false});
function owned(value,seen=new Set()){if(!value||typeof value!=='object'||seen.has(value))return;seen.add(value);assert.ok(Object.isFrozen(value)&&isOwned(value));for(const child of Object.values(value))owned(child,seen);}
function weak(frame){const entry=frame.scene.entries.find(entry=>entry.kind==='circle-run'),position=animationFrameProvenance(frame).positions.find(entry=>entry.kind==='point-run');return Object.fromEntries(Object.entries({frame,scene:frame.scene,graphic:frame.graphicSpec,entry,properties:entry.properties,x:entry.properties.x,y:entry.properties.y,radius:entry.properties.radius,position,positionValues:position.x.values}).map(([key,value])=>[key,new WeakRef(value)]));}
let plan=planTransition({from,to,options}),current;const previous=[];
for(let cycle=0;cycle<100;cycle++){current=sampleTransition(plan,25+cycle/4);owned(current);if(cycle!==99)previous.push(weak(current));}
const oldPlan=new WeakRef(plan);plan=null;
for(let cycle=0;cycle<5;cycle++){await new Promise(resolve=>setImmediate(resolve));global.gc();}
const alive=previous.flatMap(refs=>Object.entries(refs).filter(([,ref])=>ref.deref()!==undefined).map(([key])=>key));assert.deepEqual(alive,[]);assert.equal(oldPlan.deref(),undefined);
const rebasedRefs=[];function rebases(value){for(let cycle=0;cycle<10;cycle++){const old=value,localPlan=planTransition({from:old,to:cycle%2?to:from,options});assert.equal(sampleTransition(localPlan,0),old);value=sampleTransition(localPlan,50);rebasedRefs.push(weak(old));}return value;}current=rebases(current);
for(let cycle=0;cycle<5;cycle++){await new Promise(resolve=>setImmediate(resolve));global.gc();}
const rebaseAlive=rebasedRefs.flatMap(refs=>Object.entries(refs).filter(([,ref])=>ref.deref()!==undefined).map(([key])=>key));assert.deepEqual(rebaseAlive,[]);owned(current);
const report={node:process.version,rows:1000,sampleCycles:100,rebaseCycles:10,gcPasses:5,oldObjectsAlive:alive,oldPlanAlive:false,rebaseObjectsAlive:rebaseAlive,currentFullyOwned:true,notOriginalHundredThousandRowHeapQualification:true};
await writeFile(new URL('./lifetime.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
