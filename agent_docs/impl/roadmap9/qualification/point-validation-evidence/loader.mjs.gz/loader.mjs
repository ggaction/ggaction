import{readFile}from'node:fs/promises';
export async function load(url,context,next){
 if(process.env.COUNT_OWNED==='yes'&&url.endsWith('/src/core/immutable.js')){let source=await readFile(new URL(url),'utf8');source=source.replace('ownedValues.add(value);','ownedValues.add(value);globalThis.__ownedCount=(globalThis.__ownedCount??0)+1;');return{format:'module',shortCircuit:true,source};}
 if(process.env.BASELINE==='yes'&&url.endsWith('/src/grammar/animation/pointState.js'))return{format:'module',shortCircuit:true,source:await readFile(new URL('./baseline-pointState.js',import.meta.url),'utf8')};
 return next(url,context);
}
