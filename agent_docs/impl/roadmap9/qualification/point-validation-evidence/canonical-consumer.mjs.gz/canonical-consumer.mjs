import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {testOptionalDependencies} from '../../scripts/consumers/optional-peers.js';
import path from 'node:path';
import {run as execute} from '../../scripts/consumers/runtime.js';
async function testNodeConsumer(directory){for(const file of ['animation-point-scales.mjs','animation-batched.mjs'])await writeFile(path.join(directory,file),await readFile('scripts/consumers/fixtures/node/'+file));await writeFile(path.join(directory,'installed-one-k.mjs'),await readFile('.artifacts/point-validation/installed-one-k.mjs'));await writeFile(path.join(directory,'runtime.mjs'),`for(const file of ['animation-point-scales','animation-batched']){const{cases}=await import('./'+file+'.mjs');for(const item of cases)await item.run();}await import('./installed-one-k.mjs');`);execute(process.execPath,['runtime.mjs'],directory);}
import {testTypeScriptConsumer} from '../../scripts/consumers/types.js';
import {testMcpConsumer} from '../../scripts/consumers/mcp.js';
import {testTutorialConsumers} from '../../scripts/tutorial-consumer.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../../scripts/browser-bundle-size.js';
const archive=JSON.parse(await readFile('.artifacts/point-validation/frozen.json','utf8'));
assert.equal(createHash('sha256').update(await readFile(archive.file)).digest('hex'),archive.sha256);
const consumer=await preparePackageConsumer({packageSpec:archive.file}),version=process.versions.node.split('.')[0];
const result=process.env.RECHECK?JSON.parse(await readFile(`.artifacts/point-validation/consumer${version}.json`,'utf8')):{node:process.version,artifact:archive,status:'running',records:[],bundles:{}};
assert.equal(result.artifact.sha256,archive.sha256);if(process.env.RECHECK)result.rechecks=[...(result.rechecks??[]),{ids:process.env.RECHECK,archiveSHA256:archive.sha256}];
async function save(){await writeFile(`.artifacts/point-validation/consumer${version}.json`,JSON.stringify(result,null,2)+'\n');}
try {
 for(const [id,run] of [['peers',()=>testOptionalDependencies(consumer)],['node',()=>testNodeConsumer(consumer.directory)],['types',()=>testTypeScriptConsumer(consumer.directory)],['mcp',()=>testMcpConsumer(consumer.directory)],['docs',()=>testTutorialConsumers(consumer.directory)]]) {
  if(process.env.RECHECK&&!process.env.RECHECK.split(',').includes(id))continue;result.records=result.records.filter(x=>x.id!==id);
  const start=performance.now();try{await run();result.records.push({id,status:'passed',ms:performance.now()-start});}catch(e){result.records.push({id,status:'failed',error:e.stack,stdout:e.stdout?.toString(),stderr:e.stderr?.toString()});}await save();console.log(id,result.records.at(-1).status);
 }
 if(!process.env.RECHECK||process.env.RECHECK.split(',').includes('bundles'))for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)) {try{const value=await measureMinimalBrowserBundle(consumer.directory,{specifier});result.bundles[specifier]={...value,limit:BROWSER_BUNDLE_GZIP_LIMITS[specifier],status:value.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier]?'passed':'failed'};}catch(e){result.bundles[specifier]={status:'failed',error:e.stack,stdout:e.stdout?.toString(),stderr:e.stderr?.toString()};}await save();console.log(specifier,result.bundles[specifier].gzipBytes);}
 result.resolvedPeers=consumer.resolvedPeers??result.resolvedPeers;result.status=result.records.every(x=>x.status==='passed')&&Object.values(result.bundles).every(x=>x.status==='passed')?'passed':'failed';await save();if(result.status!=='passed')process.exitCode=1;
}finally{await consumer.cleanup();}
