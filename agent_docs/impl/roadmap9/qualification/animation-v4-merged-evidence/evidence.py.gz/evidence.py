from pathlib import Path
import json,re,hashlib,gzip
p=Path('.artifacts/animation-v4-merged');out=Path('agent_docs/impl/roadmap9/qualification/animation-v4-merged-evidence')
checks={}
for n in ['owning-coverage.log','contracts-browser-final.log','docs.log','animation-browser.log','browser-installed.log','browser-source.log','render.log']:
 s=(p/n).read_text();assert '# fail 0' in s,n;checks[n]=int(re.search(r'# tests (\d+)',s)[1])
a=json.loads((p/'frozen.json').read_text());consumers=[]
for v in [20,22,24]:
 r=json.loads((p/f'consumer-{v}.json').read_text());assert r['artifact']['sha256']==a['sha256'] and len(r['records'])==3 and all(x['status']=='passed' for x in r['records']);assert len(r['bundles'])==6 and all(x['status']=='passed' for x in r['bundles'].values());consumers.append(r)
 pack=json.loads((p/f'pack{v}.json').read_text());assert pack['entryCount']==1254 and pack['unpackedBytes']==8129912 and pack['packedBytes']<=1805700
large=json.loads((p/'large/qualification.json').read_text());assert large['status']=='passed' and large['archive']==a['sha256'] and large['sourceFree'] and len(large['fixtures'])==2
fixtures={}
for name,count,batch in [('product-100000-phased',100000,'batch50Rejected'),('product-partition-10000-phased',10000,'batch500Rejected')]:
 r=json.loads((p/'large'/f'{name}.json').read_text());assert r['allCoordinatesVerified']==count and r['allRebaseCoordinatesVerified']==count and r[batch] and r['stage']=='all-native-offline-rebase-exact'
 for f,sha in r['sourceSHA256'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==sha,f
 fixtures[name]=r
assert fixtures['product-100000-phased']['phases']['offline']['bytes']==33703073 and fixtures['product-100000-phased']['phases']['rebaseOffline']['bytes']==41204160
assert fixtures['product-partition-10000-phased']['phases']['offline']['bytes']==8753223 and fixtures['product-partition-10000-phased']['phases']['rebaseOffline']['bytes']==9476692
browser=json.loads((p/'browser-installed.json').read_text());assert browser['archive']==a['sha256'] and browser['sourceFree'] and browser['status']=='passed'
assert 'checked 186 built documentation pages' in (p/'built.log').read_text() and 'verified 1606 selective LLM artifacts' in (p/'built.log').read_text()
critical=json.loads((p/'critical.json').read_text());assert len(critical)==11
files={}
for f in p.rglob('*'):
 if f.is_file() and f.suffix in ['.log','.json','.mjs','.py','.txt'] and not any(part.startswith('pack') or part=='prepack' for part in f.relative_to(p).parts[:-1]):
  n=str(f.relative_to(p));raw=f.read_bytes();(out/(n.replace('/','__')+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[n]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
q={'status':'combined-public-version4-native-offline-rebase-verified; native-performance-pending','base':'65e7aa8fc','upstreamSource':'b4585c221eca54ce567a30748aa5fd42a6286bde','upstreamPin':'1064af5923b692db8566290fd0ef9d9fd858c569','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Adopt exact private lossless codec/resource scopes and public explicit node options/version4; preserve v3 omission/strict work/default guards. Root retains verified owned position sampling and empty appearance reuse.','archive':a,'checks':checks,'critical':critical,'consumers':consumers,'largeInstalled':large,'fixtures':fixtures,'browserInstalled':browser,'built':{'pages':186,'selectiveArtifacts':1606},'sourceComparison':json.loads((p/'upstream-source-comparison.json').read_text()),'limits':{'entries':1254,'packedBytes':1805700,'unpackedBytes':8130000,'FullGzip':786300,'BasicGzip':424800,'animationGzip':339400,'searchBytes':1094000},'corrections':['Initial41contracts had only README Basic424700 vs required424800 mismatch. Synchronized README and final48contracts passed.','First strict pack rejected1254entries over1252; combined archive observed maximum1805641packed/8129912unpacked and animation339303gzip over339300. Applied only minimal artifact ceilings, preserving first failures/premeasure.','Initial docs failed only combined search1093920 over1093300; final245passed after minimum1094000 ceiling. Runtime guards/fixtures/SLO unchanged.','First installed browser run was unminified; retained separately. Final source and installed browser use production minification and independently assert package origin/no repository src in metafile.'],'reuse':{'nodeRender':'All52 current animation renderer tests rerun on combined source, along with production browser v3/v4 DPR1/2 and original same-tar100k/10k native/offline/rebase.','docsUI':'Shared UI/CSS/prose placement unchanged; root docs245 and built186/LLM1606 rerun; upstream responsive/Axe evidence reused.'},'pending':['Original100k common sample P95≤50ms; actual2222.98ms diagnostic remains above target','Original partition gesture/kernel P95 and Geo camera/hit admission/performance','Final native heap/lifecycle/9commands/independent review','Sequential STEP057-070 and protected final release delivery'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({'checks':checks,'archive':a['sha256'],'large':len(large['fixtures']),'sampleMs':fixtures['product-100000-phased']['phases']['sample']['ms']}))
