import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {run,root} from '../../scripts/consumers/runtime.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../../scripts/browser-bundle-size.js';
const artifact=JSON.parse(await readFile(process.argv[2],'utf8'));
assert.equal(createHash('sha256').update(await readFile(artifact.file)).digest('hex'),artifact.sha256);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
const receipt={artifact,kind:'same installed archive; actual canonical 1k data load/revise and tagged values; not 100k or SLO',nodes:[],bundles:{}};
try {
 for(const file of ['scripts/benchmarks/workloads.browser.js','scripts/benchmarks/inference.js','test/oracles/inference-grid.js']){
  await mkdir(join(consumer.directory,file,'..'),{recursive:true});await copyFile(join(root,file),join(consumer.directory,file));
 }
 await writeFile(join(consumer.directory,'run.mjs'),`import assert from 'node:assert/strict';
import {chart} from 'ggaction';
import {serializeProgram,deserializeProgram} from 'ggaction/persistence';
import {prepareNativeWorkload} from './scripts/benchmarks/workloads.browser.js';
const w=prepareNativeWorkload('data',1000),stages=[];
for(const stage of w.stages){const result=stage.prepare().run();stages.push({name:stage.name,witness:stage.prepare().validate(result)});}
const row=JSON.parse('{"__proto__":{"safe":true},"constructor":"cell"}');
Object.assign(row,{zero:-0,nan:NaN,plus:Infinity,minus:-Infinity,int:-123n,absent:undefined,array:[null,true,'undefined',['number','NaN'],,undefined]});
const program=chart().createData({values:[row]});
const saved=serializeProgram(program),restored=deserializeProgram(saved);
assert.deepEqual(restored.semanticSpec,program.semanticSpec);assert.equal(serializeProgram(restored),saved);
assert.equal(Object.getPrototypeOf(restored.semanticSpec.datasets[0].values[0]),Object.prototype);
assert.equal({}.safe,undefined);console.log(JSON.stringify({node:process.version,stages,taggedExact:true,snapshotBytesUnchanged:true}));`);
 for(const node of ['/Users/hyeonjeon/.npm/_npx/ebaba8b9e55fd0a9/node_modules/node/bin/node','/opt/homebrew/Cellar/node@22/22.23.1/bin/node','/Users/hyeonjeon/.npm/_npx/387698761821791d/node_modules/node/bin/node']){
  const {execFileSync}=await import('node:child_process');const result=execFileSync(node,['run.mjs'],{cwd:consumer.directory,encoding:'utf8'});receipt.nodes.push(JSON.parse(result));
 }
 for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)){
  const measured=await measureMinimalBrowserBundle(consumer.directory,{specifier});receipt.bundles[specifier]={gzipBytes:measured.gzipBytes,limit:BROWSER_BUNDLE_GZIP_LIMITS[specifier]};assert.ok(measured.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier]);
 }
 receipt.status='passed';
} finally {await writeFile(process.argv[3],JSON.stringify(receipt,null,2)+'\n');await consumer.cleanup();}
console.log(JSON.stringify(receipt));
