export async function load(url, context, nextLoad) {
  const loaded = await nextLoad(url, context);
  if (!url.endsWith('/src/persistence/codec.js')) return loaded;
  const source = String(loaded.source);
  const before = `      Object.defineProperty(result, entry[0], {
        value: decodeValue(entry[1], \`\${path}.\${entry[0]}\`, references ?? []), enumerable: true, writable: true, configurable: true
      });`;
  const after = `      const child = decodeValue(entry[1], \`\${path}.\${entry[0]}\`, references ?? []);
      if (entry[0] in Object.prototype) Object.defineProperty(result, entry[0], {
        value: child, enumerable: true, writable: true, configurable: true
      });
      else result[entry[0]] = child;`;
  if (!source.includes(before)) throw new Error('Exact codec probe target missing');
  return {...loaded, source: source.replace(before, after)};
}
