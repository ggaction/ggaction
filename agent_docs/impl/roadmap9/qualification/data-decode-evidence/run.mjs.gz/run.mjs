import { writeFileSync } from 'node:fs';
import { prepareNativeWorkload, nativeWorkloadInput } from '../../scripts/benchmarks/workloads.browser.js';
const input = nativeWorkloadInput('data', 1000), workload = prepareNativeWorkload('data', 1000, input);
const prepared = workload.stages.find(stage => stage.name === 'editable-load').prepare();
const timings = [];
for (let i = 0; i < 15; i++) {
  global.gc(); const result = prepared.run(); prepared.validate(result);
  if (i >= 5) timings.push(result.metrics.loadMs);
}
const receipt = {kind:'read-only actual 1k load diagnostic; not P95 or SLO',node:process.version,timings};
writeFileSync(process.argv[2],JSON.stringify(receipt,null,2));
console.log(JSON.stringify(receipt));
