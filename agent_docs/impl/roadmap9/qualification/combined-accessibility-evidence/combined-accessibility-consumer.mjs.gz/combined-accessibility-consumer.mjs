import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { preparePackageConsumer } from '../scripts/package-consumer.js';
import { testTypeScriptConsumer } from '../scripts/consumers/types.js';
const artifact=JSON.parse(await readFile(new URL('./combined-accessibility-fixed.json',import.meta.url)));
assert.equal(createHash('sha256').update(await readFile(artifact.file)).digest('hex'),artifact.sha256);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
const report={node:process.version,archive:artifact.sha256,cases:[],types:'pending'};
try {
 await writeFile(consumer.directory+'/accessible-items.mjs',await readFile(new URL('../scripts/consumers/fixtures/node/accessible-items.mjs',import.meta.url)));
 const runner="import assert from 'node:assert/strict';import{cases}from'./accessible-items.mjs';assert.equal(cases.length,3);const passed=[];for(const entry of cases){await entry.run();passed.push(entry.id)}process.stdout.write(JSON.stringify(passed));";
 report.cases=JSON.parse(execFileSync(process.execPath,['--input-type=module','-e',runner],{cwd:consumer.directory,encoding:'utf8',timeout:120000,maxBuffer:1048576}));
 await testTypeScriptConsumer(consumer.directory);
 report.types='passed';
 await writeFile(new URL(`./combined-accessibility-installed-${process.versions.node.split('.')[0]}.json`,import.meta.url),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report));
} finally {await consumer.cleanup();}
