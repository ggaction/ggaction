from pathlib import Path
import json
p=Path('test/native-capabilities.json');m=json.loads(p.read_text())
u=lambda name:'test/unit/'+name+'.test.js'
b=lambda name:'test/browser/'+name+'.browser.js'
contracts=['agent_docs/contract/current/INTERACTION.md','agent_docs/contract/current/MARK_SELECTION.md']
make=lambda tests,extra=[]:{'status':'assigned','contracts':list(dict.fromkeys(contracts+extra)),'tests':list(dict.fromkeys(tests))}
input_tests=[u('interaction-session'),u('interaction-pointer-capture'),u('interaction-keyboard'),u('interaction-region-gesture'),b('interaction-session'),b('interaction-keyboard'),b('interaction-region')]
preview=[u('interaction-region-gesture'),u('interaction-preview-preparation'),u('interaction-direct-controls'),u('interaction-node-move'),u('interaction-annotation-drag'),u('interaction-geo-controls'),u('interaction-edge-presentation'),b('interaction-region')]
history=[u('interaction-history'),u('interaction-selection'),u('interaction-viewport'),b('interaction-keyboard')]
linked=[u('interaction-links'),u('interaction-linked-filter'),u('interaction-direct-controls'),u('interaction-reconciliation'),u('interaction-native-composition'),u('interaction-legend-selection'),b('interaction-session')]
async_tests=[u('interaction-update'),u('interaction-preparation'),u('interaction-preview-preparation'),u('interaction-resize'),u('interaction-pointer-capture')]
restore=[u('interaction-history'),u('interaction-reconciliation'),u('interaction-update'),u('interaction-linked-filter'),'test/contracts/installed-native-families.test.js']
frame=[u('interaction-animation'),u('animation/current-hit'),u('animation/route-session'),u('animation/graph-drag'),u('animation/partition-session'),b('interaction-animation')]
entries={'pointer-keyboard-touch':make(input_tests),'preview-commit-cancel':make(preview),'undo-redo':make(history),'linked':make(linked),'async-dispose':make(async_tests),'restore':make(restore),'current-frame':make(frame,['agent_docs/contract/current/ANIMATION.md'])}
for key,value in entries.items():assert key not in m['interaction']['assignedOwners'];m['interaction']['assignedOwners'][key]=value
groups={'AT-35':make(input_tests),'AT-38':make(linked),'AT-39':make(preview+[u('interaction-history')]),'AT-40':make([u('interaction-session'),u('interaction-history'),u('interaction-update'),u('interaction-region-gesture'),u('interaction-reconciliation')]),'AT-41':make(async_tests),'AT-53':make([u('accessibility/data'),u('accessibility/items'),u('interaction-keyboard'),b('accessible-data'),b('accessible-controls'),b('accessible-tooltip'),b('interaction-keyboard')],['agent_docs/contract/current/ACCESSIBILITY.md'])}
for group in m['groups']:
 if group['id'] in groups:assert group['owner']['status']=='pending';group['owner']=groups[group['id']]
for owner in list(entries.values())+list(groups.values()):
 for file in owner['tests']+owner['contracts']:assert Path(file).is_file(),file
p.write_text(json.dumps(m,indent=2)+'\n')
Path('.artifacts/native-interaction-owners/mapping.json').write_text(json.dumps({'interaction':entries,'groups':groups},indent=2)+'\n')
