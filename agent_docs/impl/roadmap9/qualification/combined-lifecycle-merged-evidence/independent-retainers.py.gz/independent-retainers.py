import json,collections,pathlib
h=json.loads((pathlib.Path(__file__).parent/'heap-12.json').read_text());n=h['nodes'];e=h['edges'];m=h['snapshot']['meta'];s=len(m['node_fields']);es=len(m['edge_fields']);names=h['strings'];types=m['node_types'][0];etypes=m['edge_types'][0]
def desc(i):return f'{i//s}:{types[n[i]]}:{names[n[i+1]]} size={n[i+3]}'
targets={i for i in range(0,len(n),s) if types[n[i]]=='array' and n[i+3]>100000}
print('BIG ARRAY',[(desc(i)) for i in targets]);reverse=collections.defaultdict(list);ei=0
for i in range(0,len(n),s):
 for j in range(n[i+4]):
  k=ei+j*es;to=e[k+2];t=etypes[e[k]];name=e[k+1] if t in ('element','hidden') else names[e[k+1]]
  if t!='weak':reverse[to].append((i,t,name))
 ei+=n[i+4]*es
for target in targets:
 print('\nRET',desc(target));front=[target];seen={target}
 for depth in range(4):
  nxt=[]
  for to in front:
   for frm,typ,name in reverse[to][:15]:
    print(' '*depth,desc(frm),'->',typ,str(name)[:160],desc(to))
    if frm not in seen:seen.add(frm);nxt.append(frm)
  front=nxt
