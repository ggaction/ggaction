import json,collections,pathlib
base=pathlib.Path(__file__).parent
stats=[]
for cyc in [0,4,12]:
 h=json.loads((base/f'heap-{cyc}.json').read_text());n=h['nodes'];m=h['snapshot']['meta'];fields=m['node_fields'];s=len(fields);types=m['node_types'][0];names=h['strings'];c=collections.Counter();counts=collections.Counter()
 for i in range(0,len(n),s):
  key=(types[n[i]],names[n[i+1]]);c[key]+=n[i+3];counts[key]+=1
 stats.append((c,counts));print(cyc,'nodebytes',sum(c.values()),'nodes',sum(counts.values()))
for a,b in [(0,1),(1,2)]:
 print('DIFF',[0,4,12][a],[0,4,12][b]);c1,k1=stats[a];c2,k2=stats[b]
 for key in sorted(c2,key=lambda key:c2[key]-c1[key],reverse=True)[:35]: print(c2[key]-c1[key],k2[key]-k1[key],key)
