import json,collections,pathlib
for cycle in [0,4,12]:
 h=json.loads((pathlib.Path(__file__).parent/f'heap-{cycle}.json').read_text());n=h['nodes'];e=h['edges'];m=h['snapshot']['meta'];s=len(m['node_fields']);es=len(m['edge_fields']);ss=h['strings'];types=m['node_types'][0];etypes=m['edge_types'][0];ei=0;counts=collections.Counter();weakset=[];ctx=[]
 for i in range(0,len(n),s):
  name=ss[n[i+1]];counts[(types[n[i]],name)]+=1
  for j in range(n[i+4]):
   k=ei+j*es;t=etypes[e[k]];en=e[k+1] if t in ('element','hidden') else ss[e[k+1]]
   if en=='ownedValues':
    wi=e[k+2];start=sum(n[v+4] for v in range(0,wi,s))*es
    for a in range(start,start+n[wi+4]*es,es):
     if etypes[e[a]]=='internal' and ss[e[a+1]]=='table':
      table=e[a+2];weakset.append((n[table+3],n[table+4]))
   if en in ['mounted','previewProgram','assetResolver'] and types[n[i]]=='object' and 'Context' in name:ctx.append((en,ss[n[e[k+2]+1]],types[n[e[k+2]]]))
  ei+=n[i+4]*es
 print('\nCYCLE',cycle,'ownedValues tables',weakset,'session-context-slots',ctx)
 for (typ,name),count in counts.items():
  if any(word in name for word in ['HTMLDivElement','HTMLCanvasElement','ImageBitmap','ResizeObserver','AbortController','Worker','PointerEvent','EventListener','DocumentFragment']) and typ in ['native','object']:
   print(typ,name,count)
