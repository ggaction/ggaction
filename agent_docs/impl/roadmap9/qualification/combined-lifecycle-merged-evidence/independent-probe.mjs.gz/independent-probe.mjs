import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {build} from 'esbuild';
import {chromium} from 'playwright';
import {runLifecycleCycle} from './lifecycle.mjs';
const base = new URL('./',import.meta.url).pathname;
const assets=new Map();
for (const [file,route] of [['routes.browser.js','/app.js'],['routes.worker.js','/worker.js']]) {
 const source=execFileSync('git',['show',`2c72d4144:scripts/benchmarks/${file}`],{encoding:'utf8'});
 const built=await build({stdin:{contents:source,resolveDir:base+'consumer',sourcefile:file},bundle:true,minify:false,format:'esm',platform:'browser',target:'es2022',write:false});
 assets.set(route,built.outputFiles[0].text); await writeFile(base+route.slice(1),built.outputFiles[0].text);
}
assets.set('/','<!doctype html><p id="status"></p><canvas></canvas><div id="svg"></div><script type="module" src="app.js"></script>');
const server=createServer((req,res)=>{res.setHeader('Content-Type',req.url==='/'?'text/html':'text/javascript');res.end(assets.get(req.url)||'');});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true,args:['--js-flags=--expose-gc','--enable-precise-memory-info']});
try {
 const page=await browser.newPage({viewport:{width:900,height:600}}); const errors=[];page.on('pageerror',e=>errors.push(e.stack));
 await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>document.querySelector('#status').textContent==='Ready');
 const cdp=await page.context().newCDPSession(page);await cdp.send('HeapProfiler.enable');
 await page.evaluate(()=>nativeBenchmark.resetLifecycle());const samples=[];
 async function snapshot(index){let chunks=[];let handler=event=>chunks.push(event.chunk);cdp.on('HeapProfiler.addHeapSnapshotChunk',handler);await cdp.send('HeapProfiler.takeHeapSnapshot',{reportProgress:false});cdp.off('HeapProfiler.addHeapSnapshotChunk',handler);await writeFile(base+`heap-${index}.json`,chunks.join(''));}
 for(let i=0;i<=12;i++){
  if(i) await runLifecycleCycle(page,i,1);
  await cdp.send('HeapProfiler.collectGarbage');const heap=await cdp.send('Runtime.getHeapUsage');samples.push({cycle:i,...heap});console.log(JSON.stringify(samples.at(-1)));
  if([0,4,12].includes(i)) await snapshot(i);
 }
 await writeFile(base+'result.json',JSON.stringify({samples,errors},null,2));
}finally{await browser.close();server.close();}
