from pathlib import Path
import json,gzip,hashlib,re,subprocess
p=Path('.artifacts/inference-worker-merged');out=Path('agent_docs/impl/roadmap9/qualification/inference-worker-merged-evidence');out.mkdir(exist_ok=True)
checks={}
for f in ['owning.log','contracts.log','coverage-policy.log','docs.log','browser.log','inspection-coverage.log']:
 s=(p/f).read_text();assert '# fail 0' in s,f;checks[f]=int(re.search(r'# tests (\d+)',s)[1])
a=json.loads((p/'frozen.json').read_text());installed=[]
for n in [20,22,24]:
 r=json.loads((p/f'installed-{n}.json').read_text());assert r['status']=='passed' and r['sha256']==a['sha256'];assert len(r['checks'])==5 and all(x['status']=='passed' for x in r['checks']);assert len(r['snippets'])==2;installed.append(r)
for n in [20,22,24]:assert json.loads((p/f'pack{n}.json').read_text())['entryCount']==1251
same=json.loads((p/'source-equality.json').read_text());assert same['different']==[] and len(same['files'])==19
critical=json.loads(Path('agent_docs/impl/roadmap9/qualification/inference-worker-evidence/critical.json').read_text())
reused=[]
for owner in critical['owners']:
 f='src/'+owner['file']
 if owner['file']=='inspectionDescriptors.js':continue
 assert Path(f).read_bytes()==subprocess.check_output(['git','show','cb08d22a8:'+f]),f
 reused.append(owner['file'])
assert len(reused)==18
files={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.stderr','.mjs','.py']:
  raw=f.read_bytes();(out/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[f.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q={'status':'dedicated-inference-worker-integrated; final-native-qualification-pending','base':'9b32fccdc','incoming':'cb08d22a8adf528d105af574786e78573431d4b0','approval':'../../AUTHORIZATION.json#remainingApproval','archive':a,'sourceInputEquality':same,'checks':checks,'installed':installed,'built':{'pages':186,'selectiveArtifacts':1606,'status':'passed'},'coverage':{'reusedCriticalOwners':reused,'source':'../inference-worker-evidence/critical.json','actualRoot':{'inspectionDescriptors.js':{'lines':100,'branches':100,'functions':100}},'wholeCoverageRunClaimed':False},'limits':{'entries':1251,'packedBytes':1795000,'unpackedBytes':8085300,'FullGzip':786000,'graphGzip':67600,'searchBytes':1092700},'browser':{'actualWorker':True,'sizes':[100,1000,10000],'eachAllEdges':True,'singleDiagnosticNotP95':True,'largePrepareMs':22768.10000014305,'largeCommitMs':4614.899999856949,'qualification':False,'log':'browser.log.gz'},'reuse':{'builtBrowser':'Upstream responsive and accessibility evidence reused for unchanged UI/layout. Root source tests/build/check built pages actually rerun; no new whole built browser sweep claimed.'},'corrections':['Merged both existing handles and new worker installed manifests','Used the unambiguous existing snippet marker and added worker executable example','Removed stale no-worker statement from Current GRAPHS'], 'pending':['Worker repeated-validation optimization checkpoint','Original AT82 large performance P95/heap/100-cycle qualification','Final combined candidate required suites'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(checks,a['sha256'])
