from pathlib import Path
import gzip,hashlib,json,re,subprocess,tarfile
b=Path('.artifacts/point-node-merged');d=Path('agent_docs/impl/roadmap9/qualification/point-node-merged-evidence');d.mkdir(exist_ok=True)
def sha(v):return hashlib.sha256(v).hexdigest()
checks={}
for name in ['focused.log','coverage.log','boundaries.log','render.log']:
 s=(b/name).read_text();assert '# fail 0' in s,name;checks[name]=int(re.search(r'# tests (\d+)',s)[1])
s=(b/'coverage.log').read_text();m=re.search(r'\bsample.js\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)',s);vals=list(map(float,m.groups()));assert vals[0]>=95 and vals[1]>=90 and vals[2]==100
f='src/animation/sample.js';source=sha(Path(f).read_bytes());a=json.loads((b/'frozen.json').read_text());consumers=[]
for v in [20,22,24]:
 c=json.loads((b/f'installed-{v}.json').read_text());assert c['artifact']['sha256']==a['sha256'] and all(r['status']=='passed' for r in c['records'])
 if v==20:
  r=json.loads((b/'budget-recheck20.json').read_text());assert r['status']=='passed' and r['sha256']==a['sha256'];c={**c,'finalBudgetRecheck':r}
 else:assert c['status']=='passed'
 consumers.append(c)
browser=json.loads((b/'browser-installed.json').read_text());assert browser['status']=='passed' and browser['archiveSHA256']==a['sha256']
large=json.loads((b/'product-100000-phased.json').read_text());assert large['stage']=='all-native-offline-rebase-exact' and large['allCoordinatesVerified']==100000 and large['allRebaseCoordinatesVerified']==100000 and large['batch50Rejected']
assert large['inputSHA256']=='b68cab72c1abb6094e715d6e5caa84c54aacf18750ad4a22fb63e3b8c5b2c39f'
assert large['phases']['offline']['bytes']==33703073 and large['phases']['rebaseOffline']['bytes']==41202280
with tarfile.open(a['file']) as tar:
 for name,h in large['sourceSHA256'].items():assert sha(Path(name).read_bytes())==h and sha(tar.extractfile('package/'+name).read())==h
assert large['sourceSHA256'][f]==source
q={'status':'point-node-local-freeze-integrated; common50ms-and-final-closeout-pending','base':'d7e7abe0d','review':'c0a3755ba7715db22405edde0fd28f2fd94a9d52','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Validated point properties and node retain core ownership; only fresh frame tuples freeze locally. Complete nodes vector receives ownership only when every node is already owned; raw extra emissions take existing deep-clone fallback. No consumer authority/core/renderer/math/work/schema/API changes.','sourceSHA256':{f:source},'archive':a,'checks':checks,'critical':{'animation/sample.js':dict(zip(['lines','branches','functions'],vals))},'consumers':consumers,'installedBrowser':browser,'product1000':json.loads((b/'product-compare.json').read_text()),'product100000':large,'timingBoundary':'The large sample phase includes independent full-coordinate verification and concurrent small checks; diagnostic only, not pure sampler time, P95 or50ms evidence.','packMeasurements':{str(v):json.loads((b/f'pack{v}.json').read_text()) for v in [20,22,24]},'artifactPolicy':{'entries':1259,'packedBytes':1811900,'unpackedBytes':8153000,'animationGzip':340900,'actualUnpacked':8152972,'actualNode20Packed':1811870,'actualNode20AnimationGzip':340806,'runtimeGuardChanges':0},'recovery':'Subagent usage limit interrupted its uncommitted point-node implementation. Exact source and original failed logs retained; root copied task-owned work, repaired new mixed test margin20→40 so axis setup reaches intended assertions, and ran full owning/functional/package evidence. Original worktree preserved.','initialFailuresRetained':['Upstream new mixed-case fixture rejected initial axis layout at margin20 before sampling; root margin40 retains all families and assertions.','Node20 packed1811870 exceeded1811800; minimum ceiling1811900.','Node20 animation gzip340806 exceeded340800; original receipt retained and new340900 ceiling rechecked without repeating passing runtime.'],'reusedEvidence':[{'path':'../frame-node-review-evidence/qualification.json','boundary':'Read-only source-root audit and unsafe node-unowned/raw-emission counterexamples retained; product coverage and actual original100k are fresh root evidence.'},{'path':'../prepared-scale-merged-evidence/qualification.json','boundary':'Public docs/types and non-sample owners unchanged; reuse246docs/186built pages. Fresh same-tar strictTS/7animationdocs/minified browser and source-pin nine doc contracts verify current surface.'}],'pending':['Shared scalar mapper and captureFrameMeaning cost audit','Common sample50ms/Canvas, partition and Geo camera/hit performance','Route cursor/bounded execution/native closure and original1k10k solvers','Long-lived mixed WeakSet attribution/actual retained100cycle','Final9commands/independent review/STEP057-077 closeout'],'evidenceFiles':{}}
for p in sorted(b.iterdir()):
 if p.is_file() and p.suffix in ['.log','.json','.mjs','.py']:
  raw=p.read_bytes();(d/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':sha(raw),'bytes':len(raw)}
raw=Path('.artifacts/animation-small-installed.mjs').read_bytes();(d/'animation-small-installed.mjs.gz').write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles']['animation-small-installed.mjs']={'sha256':sha(raw),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(checks,vals,a['sha256'])
