// Read-only proposal surface. Production types are untouched.
import type {AnimationProgram,TransitionPlan,TransitionFrame,TransitionOptions,PlaybackOptions,AnimationFrameOptions,AnimationPlayback,AnimationClock,AnimationPlayerState,AnimationSettlement,TransitionDecision,AnimationMarkerEvent} from '../../types/animation.js';
import type {CanvasTransitionNode} from '../../types/scene.js';
import type {GraphicObject,GraphicSpec,GraphicClipPath} from '../../types/program.js';
export type {TransitionPlan,TransitionFrame};
export interface CircleBatch extends Omit<GraphicObject,'type'|'properties'|'items'|'children'> {readonly type:'circle-batch';readonly properties:{readonly x:readonly number[];readonly y:readonly number[];readonly radius:readonly number[];readonly appearance:Readonly<Record<string,unknown>>}}
export interface BatchedTransitionPlan extends Omit<TransitionPlan,'version'> {readonly version:6}
export type AnyTransitionPlan=TransitionPlan|BatchedTransitionPlan;
export type SampleEntry=
 {readonly kind:'single';readonly node:CanvasTransitionNode;readonly decision:TransitionDecision|null}|
 {readonly kind:'circle-run';readonly keys:readonly string[];readonly topology:string;readonly offset:readonly[number,number];readonly clip:readonly[number,number,number,number];readonly clips:readonly(readonly[number,number,number,number]|GraphicClipPath)[];readonly properties:CircleBatch['properties'];readonly decisions:null|{readonly kind:'semantic-kernel';readonly kernel:'cartesian-point';readonly ownerKey:string;readonly role:string;readonly sourceIndices:readonly number[];readonly targetIndices:readonly number[];readonly itemKeys:readonly string[]}};
export interface BatchedTransitionFrame extends Omit<TransitionFrame,'scene'|'decisions'|'graphicSpec'> {
 readonly graphicSpec:Omit<GraphicSpec,'objects'>&{readonly objects:Readonly<Record<string,GraphicObject|CircleBatch>>};
 readonly scene:{readonly version:3;readonly width:number;readonly height:number;readonly entries:readonly SampleEntry[]};
 readonly progress:number;
}
export type AnyTransitionFrame=TransitionFrame|BatchedTransitionFrame;
type Endpoint=AnimationProgram|TransitionFrame;
type AnyEndpoint=Endpoint|BatchedTransitionFrame;
type BaseOptions=Omit<TransitionOptions,'formatVersion'>;
type BatchOptions=BaseOptions&{readonly formatVersion:6};
type DynamicOptions=BaseOptions&{readonly formatVersion?:5|6};
type Request<E,O>={readonly from:E;readonly to:E;readonly options:O};
export declare function planTransition(input:Request<AnyEndpoint,BatchOptions>):BatchedTransitionPlan;
export declare function planTransition(input:Request<Endpoint,BaseOptions&{readonly formatVersion:5}>):TransitionPlan&{readonly version:5};
export declare function planTransition(input:Request<Endpoint,BaseOptions&{readonly formatVersion?:never;readonly maxEndpointNodes?:never;readonly maxOutputNodes?:never}>):TransitionPlan&{readonly version:3};
export declare function planTransition(input:Request<Endpoint,BaseOptions&{readonly formatVersion?:never}&({readonly maxEndpointNodes:number}|{readonly maxOutputNodes:number})>):TransitionPlan&{readonly version:4};
export declare function planTransition(input:Request<Endpoint,DynamicOptions>|Request<AnyEndpoint,BatchOptions>):AnyTransitionPlan;
export declare function sampleTransition(plan:BatchedTransitionPlan,timeMs:number):BatchedTransitionFrame;
export declare function sampleTransition(plan:TransitionPlan,timeMs:number):TransitionFrame;
export declare function sampleTransition(plan:AnyTransitionPlan,timeMs:number):AnyTransitionFrame;
export declare function serializeAnimation(plan:AnyTransitionPlan,playback?:PlaybackOptions):string;
export declare function deserializeAnimation(text:string):{readonly plan:AnyTransitionPlan;readonly playback:AnimationPlayback};
export declare function exportAnimationFrames(plan:BatchedTransitionPlan,options:AnimationFrameOptions):readonly (BatchedTransitionFrame&{readonly timeMs:number})[];
export declare function exportAnimationFrames(plan:TransitionPlan,options:AnimationFrameOptions):readonly (TransitionFrame&{readonly timeMs:number})[];
export declare function exportAnimationFrames(plan:AnyTransitionPlan,options:AnimationFrameOptions):readonly (AnyTransitionFrame&{readonly timeMs:number})[];
export interface Player<F,O,E>{play():Player<F,O,E>;pause():Player<F,O,E>;seek(timeMs:number,options?:{readonly emit?:boolean}):Player<F,O,E>;reverse():Player<F,O,E>;setRate(rate:number):Player<F,O,E>;setRepeat(repeat:number):Player<F,O,E>;cancel():Player<F,O,E>;interrupt(input:PlaybackOptions&{readonly to:E;readonly options:O}):Player<F,O,E>;dispose():void;getState():AnimationPlayerState;getFrame():F|undefined;readonly finished:Promise<AnimationSettlement>}
type PlayerInput<P,F,H>=PlaybackOptions&{readonly plan:P;readonly clock:AnimationClock<H>;readonly render:(frame:F)=>void;readonly commit?:(frame:F)=>void;readonly onMarker?:(event:Omit<AnimationMarkerEvent,'frame'>&{readonly frame:F})=>void};
export declare function createAnimationPlayer<H>(input:PlayerInput<BatchedTransitionPlan,BatchedTransitionFrame,H>):Player<BatchedTransitionFrame,BatchOptions,AnyEndpoint>;
export declare function createAnimationPlayer<H>(input:PlayerInput<TransitionPlan,TransitionFrame,H>):Player<TransitionFrame,TransitionOptions,Endpoint>;
export declare function createAnimationPlayer<H>(input:PlayerInput<AnyTransitionPlan,AnyTransitionFrame,H>):Player<AnyTransitionFrame,DynamicOptions,AnyEndpoint>;
