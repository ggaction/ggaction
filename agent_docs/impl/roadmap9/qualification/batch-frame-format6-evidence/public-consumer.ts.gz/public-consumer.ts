import type {AnimationProgram,AnimationClock} from '../../types/animation.js';
import {planTransition,sampleTransition,deserializeAnimation,exportAnimationFrames,createAnimationPlayer,type TransitionFrame,type BatchedTransitionFrame,type AnyTransitionFrame} from './public-candidate.js';
declare const from:AnimationProgram,to:AnimationProgram,text:string,version:5|6,clock:AnimationClock<number>;
const old=planTransition({from,to,options:{durationMs:100}});const oldVersion:3=old.version;const oldFrame:TransitionFrame=sampleTransition(old,50);
const batch=planTransition({from,to,options:{durationMs:100,formatVersion:6}});const batchVersion:6=batch.version;const batchFrame:BatchedTransitionFrame=sampleTransition(batch,50);
const dynamic=planTransition({from,to,options:{durationMs:100,formatVersion:version}});const either:AnyTransitionFrame=sampleTransition(dynamic,50);
// @ts-expect-error A dynamic format does not promise legacy scene2.
const falseLegacy:TransitionFrame=sampleTransition(dynamic,50);
const restored=deserializeAnimation(text);
if(restored.plan.version===6){const frame:BatchedTransitionFrame=sampleTransition(restored.plan,50);const sceneVersion:3=frame.scene.version;void sceneVersion;}
else{const frame:TransitionFrame=sampleTransition(restored.plan,50);const sceneVersion:2=frame.scene.version;void sceneVersion;}
// @ts-expect-error Deserialization can return a batch; version must be narrowed.
const wrong:TransitionFrame=sampleTransition(restored.plan,50);
// @ts-expect-error No implicit batch endpoint downgrade.
planTransition({from:batchFrame,to,options:{durationMs:100}});
planTransition({from:batchFrame,to,options:{durationMs:100,formatVersion:6}});
const batchFrames:readonly(BatchedTransitionFrame&{readonly timeMs:number})[]=exportAnimationFrames(batch,{timesMs:[0,50,100]});
const player=createAnimationPlayer({plan:batch,clock,render(frame){const v:3=frame.scene.version;void v;}});
player.interrupt({to,options:{durationMs:100,formatVersion:6}});
// @ts-expect-error Existing callback representation cannot change on interruption.
player.interrupt({to,options:{durationMs:100,formatVersion:5}});
// @ts-expect-error Batch plan cannot use a legacy-only render callback.
createAnimationPlayer({plan:batch,clock,render(frame:TransitionFrame){void frame;}});
void [oldVersion,oldFrame,batchVersion,batchFrames,either];
