// Read-only candidate for format6 endpoint projection; no production modules are patched.
import assert from 'node:assert/strict';
import {isDeepStrictEqual} from 'node:util';
import {ownArray,ownRecord} from '../../src/core/ownData.js';
import {cloneAndFreeze} from '../../src/core/immutable.js';
import {packAnimationNumericVector,inspectAnimationNumericVector} from '../../src/animation/numericColumns.js';
import {prepareAnimationColumnsV2,validateAnimationColumnsV2} from '../../src/animation/columnCodec.js';
import {encodeAnimationEnvelope,decodeAnimationEnvelope} from '../../src/animation/envelopeCodec.js';
import {createOfflineResourceScope,animationResourceAccounting,validateAnimationResourceWork,validateAnimationColumnCount} from '../../src/animation/resources.js';
import {animationFrameProvenance} from '../../src/animation/frameProvenance.js';
import {validatePointAnimationPosition} from '../../src/grammar/animation/pointState.js';
import {validateConcreteGraphicProperties} from '../../src/grammar/schemas/concreteGraphic.js';
import {graphicAnimationOwnerKey} from '../../src/grammar/animation/ownerKey.js';
const xyz=['x','y','radius'],label='Format6 review',closed=(v,k)=>{ownRecord(v,label);assert.deepEqual(Object.keys(v).sort(),[...k].sort(),label+' fields');};
export const allocations={numericArrays:0};
const dense=(v,n)=>{ownArray(v,label);assert.equal(v.length,n);};
const exact=frame=>frame.progress===0||frame.progress===1;
export function endpoint(frame){
 const proof=animationFrameProvenance(frame),entries=[],positions=[];
 for(let i=0;i<frame.scene.nodes.length;){
  const node=frame.scene.nodes[i],pos=proof.positions[i],decision=exact(frame)?null:frame.decisions[i];
  if(node.type!=='circle'||!pos||(!exact(frame)&&decision.kernel!=='cartesian-point')){
   entries.push({kind:'single',node,decision});positions.push({kind:'single',value:pos??{reason:proof.endpoint.identities[i]===undefined?'anonymous':'sampled-concrete'}});i++;continue;
  }
  const {properties,key,...placement}=node,appearance=Object.fromEntries(Object.entries(properties).filter(([k])=>!xyz.includes(k))),keys=[],p={x:[],y:[],radius:[],appearance},decisions=decision===null?null:{kind:'semantic-kernel',kernel:'cartesian-point',ownerKey:decision.ownerKey,role:decision.role,sourceIndices:[],targetIndices:[],itemKeys:[]},position={kind:'point-run',x:{values:[],scale:pos.x.scale},y:{values:[],scale:pos.y.scale}};
  let j=i;while(j<frame.scene.nodes.length&&j-i<10000){
   const n=frame.scene.nodes[j],m=proof.positions[j],d=exact(frame)?null:frame.decisions[j],{properties:q,key:k,...f}=n;
   if(n.type!=='circle'||!m||!isDeepStrictEqual(f,placement)||!isDeepStrictEqual(Object.fromEntries(Object.entries(q).filter(([a])=>!xyz.includes(a))),appearance)||!isDeepStrictEqual(m.x.scale,pos.x.scale)||!isDeepStrictEqual(m.y.scale,pos.y.scale)||d!==null&&(d.kernel!=='cartesian-point'||d.ownerKey!==decision.ownerKey||d.role!==decision.role))break;
   keys.push(k);for(const a of xyz)p[a].push(q[a]);for(const a of['x','y'])position[a].values.push(m[a].value);if(d!==null){decisions.sourceIndices.push(d.sourceIndex);decisions.targetIndices.push(d.targetIndex);decisions.itemKeys.push(d.itemKey);}j++;
  }
  assert.ok(j>i);entries.push({kind:'circle-run',keys,topology:node.topology,offset:node.offset,clip:node.clip,clips:node.clips??[],properties:p,decisions});positions.push(position);i=j;
 }
 return cloneAndFreeze({scene:{version:3,width:frame.scene.width,height:frame.scene.height,entries},identities:proof.endpoint.identities,backgrounds:proof.endpoint.backgrounds,positions,view:{progress:frame.progress}});
}
export function expand(side){const nodes=[],decisions=[],positions=[];for(let i=0;i<side.scene.entries.length;i++){
 const e=side.scene.entries[i],p=side.positions[i];if(e.kind==='single'){nodes.push(e.node);if(e.decision!==null)decisions.push(e.decision);positions.push(p.value);continue;}
 for(let r=0;r<e.keys.length;r++){
  nodes.push({key:e.keys[r],type:'circle',topology:e.topology,properties:{...e.properties.appearance,x:e.properties.x[r],y:e.properties.y[r],radius:e.properties.radius[r]},offset:e.offset,clip:e.clip,clips:e.clips});
  if(e.decisions!==null)decisions.push({sourceIndex:e.decisions.sourceIndices[r],targetIndex:e.decisions.targetIndices[r],itemKey:e.decisions.itemKeys[r],role:e.decisions.role,ownerKey:e.decisions.ownerKey,kind:e.decisions.kind,kernel:e.decisions.kernel});
  positions.push({x:{value:p.x.values[r],scale:p.x.scale},y:{value:p.y.values[r],scale:p.y.scale}});
 }
}return{scene:{version:2,width:side.scene.width,height:side.scene.height,nodes},decisions,positions};}
// Exact legacy work rule, applied to conceptual expanded values for this small oracle.
export function logicalWork(value){let work=1;if(typeof value==='string')return work+value.length;if(value&&typeof value==='object')for(const[k,v]of Object.entries(value))work+=k.length+logicalWork(v);return work;}
function vectors(side){const result=[];for(let i=0;i<side.scene.entries.length;i++){const e=side.scene.entries[i],p=side.positions[i];if(e.kind!=='circle-run')continue;for(const k of xyz)result.push([e.properties,k,e.keys.length]);if(e.decisions!==null)for(const k of['sourceIndices','targetIndices'])result.push([e.decisions,k,e.keys.length]);for(const k of['x','y'])result.push([p[k],'values',e.keys.length]);}return result;}
export function validateEndpoint(side,limits){
 closed(side,['scene','identities','backgrounds','positions','view']);closed(side.scene,['version','width','height','entries']);assert.equal(side.scene.version,3);assert.ok(Number.isFinite(side.scene.width)&&side.scene.width>0);assert.ok(Number.isFinite(side.scene.height)&&side.scene.height>0);closed(side.view,['progress']);assert.ok(side.view.progress>=0&&side.view.progress<=1);ownArray(side.scene.entries,label);dense(side.positions,side.scene.entries.length);let count=0;const keys=new Set();
 for(let i=0;i<side.scene.entries.length;i++){
  const e=side.scene.entries[i],p=side.positions[i];ownRecord(e,label);if(e.kind==='single'){closed(e,['kind','node','decision']);closed(p,['kind','value']);assert.equal(p.kind,'single');ownRecord(e.node,label);assert.equal(e.decision===null,side.view.progress===0||side.view.progress===1);assert.equal(keys.has(e.node.key),false);keys.add(e.node.key);validateConcreteGraphicProperties(e.node.type,e.node.properties);count++;continue;}
  closed(e,['kind','keys','topology','offset','clip','clips','properties','decisions']);assert.equal(e.kind,'circle-run');ownArray(e.keys,label);const n=e.keys.length;assert.ok(n>0&&n<=10000);closed(e.properties,['x','y','radius','appearance']);for(const k of xyz)dense(e.properties[k],n);closed(p,['kind','x','y']);assert.equal(p.kind,'point-run');for(const a of['x','y']){closed(p[a],['values','scale']);dense(p[a].values,n);}assert.equal(e.decisions===null,side.view.progress===0||side.view.progress===1);
  if(e.decisions!==null){closed(e.decisions,['kind','kernel','ownerKey','role','sourceIndices','targetIndices','itemKeys']);assert.equal(e.decisions.kind,'semantic-kernel');assert.equal(e.decisions.kernel,'cartesian-point');for(const k of['sourceIndices','targetIndices','itemKeys'])dense(e.decisions[k],n);}
  for(let r=0;r<n;r++){assert.equal(typeof e.keys[r],'string');assert.equal(keys.has(e.keys[r]),false);keys.add(e.keys[r]);const node={type:'circle',properties:{...e.properties.appearance,...Object.fromEntries(xyz.map(k=>[k,e.properties[k][r]]))}},identity=side.identities[count+r];validateConcreteGraphicProperties('circle',node.properties);validatePointAnimationPosition({x:{value:p.x.values[r],scale:p.x.scale},y:{value:p.y.values[r],scale:p.y.scale}},identity,node);
   if(e.decisions!==null){assert.equal(e.decisions.itemKeys[r],identity.key);assert.equal(e.decisions.role,identity.role);assert.equal(e.decisions.ownerKey,graphicAnimationOwnerKey(identity));for(const k of['sourceIndices','targetIndices'])assert.ok(Number.isSafeInteger(e.decisions[k][r])&&e.decisions[k][r]>=0&&e.decisions[k][r]<limits.maxOutputNodes);}
  }count+=n;
 }
 assert.ok(count<=limits.maxOutputNodes);dense(side.identities,count);ownArray(side.backgrounds,label);for(const b of side.backgrounds){closed(b,['index','owner']);assert.ok(Number.isSafeInteger(b.index)&&b.index>=0&&b.index<count);assert.equal(side.identities[b.index],undefined);}return count;
}
export function encodeCandidate(raw,playback={rate:1,repeat:0,reducedMotion:false},mutateProjected=()=>{}){
 const projected=structuredClone(raw),scope=createOfflineResourceScope(raw.limits);for(const side of['from','to']){validateEndpoint(projected[side],raw.limits);for(const[parent,key]of vectors(projected[side]))parent[key]=packAnimationNumericVector(parent[key]);}
 mutateProjected(projected);const prepared=prepareAnimationColumnsV2(projected,scope),nodes=new Map(prepared.compact.root.object),wire={kind:raw.kind,version:raw.version,limits:raw.limits,kernels:raw.kernels,durationMs:raw.durationMs,easing:raw.easing,from:nodes.get('from'),to:nodes.get('to'),vectors:prepared.compact.vectors};return encodeAnimationEnvelope({plan:wire,playback});
}
export function decodeCandidate(text){
 allocations.numericArrays=0;const payload=decodeAnimationEnvelope(text);closed(payload,['plan','playback']);closed(payload.playback,['rate','repeat','reducedMotion']);const wire=payload.plan;closed(wire,['kind','version','limits','kernels','durationMs','easing','from','to','vectors']);assert.equal(wire.kind,'transition-plan');assert.equal(wire.version,6);closed(wire.kernels,['transition','position','appearance','columns','batchFrame']);assert.deepEqual(wire.kernels,{transition:6,position:'semantic-continuous-position@1',appearance:'premultiplied-linear-srgb@1',columns:'animation-columns@2',batchFrame:1});const scope=createOfflineResourceScope(wire.limits);
 const entries=Object.entries(wire).filter(([key])=>!['from','to','vectors'].includes(key)).map(([key,value])=>[key,{literal:value}]);entries.push(['from',wire.from],['to',wire.to]);const proof=validateAnimationColumnsV2({kind:'animation-columns',version:2,root:{object:entries},vectors:wire.vectors},scope),raw=proof.restore(),pending=[];let cells=0,rows=0;
 for(const side of['from','to']){const value=raw[side];closed(value,['scene','identities','backgrounds','positions','view']);ownArray(value.scene.entries,label);dense(value.positions,value.scene.entries.length);let count=0;for(const e of value.scene.entries){ownRecord(e,label);if(e.kind==='circle-run'){ownArray(e.keys,label);assert.ok(e.keys.length>0&&e.keys.length<=10000);}count+=e.kind==='circle-run'?e.keys.length:1;}assert.ok(count<=wire.limits.maxOutputNodes);rows+=count;for(const[parent,key,length]of vectors(value)){const v=inspectAnimationNumericVector(parent[key]);assert.equal(v.length,length);cells+=length;validateAnimationColumnCount(cells,'cells',scope);pending.push({parent,key,proof:v});}}
 assert.ok(rows<=wire.limits.maxEndpointNodes);for(const item of pending)item.proof.validateFinite();
 const numericProofs=new Map(pending.map(item=>[item.parent[item.key],item.proof]));
 const at=(values,index)=>numericProofs.get(values)?.at(index)??values[index];
 for(const side of ['from','to'])validateAnimationResourceWork(streamingWork(raw[side],at),'Animation preparation work',scope);
 // All declared lengths/cells, limits and finite numeric values precede dense numeric allocation.
 for(const {parent,key,proof:p}of pending){allocations.numericArrays++;parent[key]=Array.from({length:p.length},(_,i)=>p.at(i));}
 for(const side of['from','to']){validateEndpoint(raw[side],wire.limits);assert.equal(streamingWork(raw[side],(values,index)=>values[index]),logicalWork(expand(raw[side])));}
 return{raw:cloneAndFreeze(raw),accounting:animationResourceAccounting(scope)};
}

// Small oracle streams conceptual legacy rows to account their exact work before allocating columns.
export function streamingWork(side,at){
 let work=logicalWork({scene:{version:2,width:side.scene.width,height:side.scene.height,nodes:[]},decisions:[],positions:[]}),index=0,decisionIndex=0;
 for(let i=0;i<side.scene.entries.length;i++){const e=side.scene.entries[i],p=side.positions[i];
 if(e.kind==='single'){work+=String(index).length+logicalWork(e.node)+String(index).length+logicalWork(p.value);if(e.decision!==null)work+=String(decisionIndex++).length+logicalWork(e.decision);index++;continue;}
 for(let r=0;r<e.keys.length;r++){
  const node={key:e.keys[r],type:'circle',topology:e.topology,properties:{...e.properties.appearance,x:at(e.properties.x,r),y:at(e.properties.y,r),radius:at(e.properties.radius,r)},offset:e.offset,clip:e.clip,clips:e.clips};
  const position={x:{value:at(p.x.values,r),scale:p.x.scale},y:{value:at(p.y.values,r),scale:p.y.scale}};work+=String(index).length+logicalWork(node)+String(index).length+logicalWork(position);
  if(e.decisions!==null){const d=e.decisions;work+=String(decisionIndex++).length+logicalWork({sourceIndex:at(d.sourceIndices,r),targetIndex:at(d.targetIndices,r),itemKey:d.itemKeys[r],role:d.role,ownerKey:d.ownerKey,kind:d.kind,kernel:d.kernel});}index++;
 }
 }return work;
}
