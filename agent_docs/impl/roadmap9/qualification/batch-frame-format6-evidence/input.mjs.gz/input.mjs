import {chart,hconcat} from '../../src/index.js';
import {planTransition,sampleTransition,serializeAnimation,deserializeAnimation} from '../../src/animation.js';
import {nativeWorkloadInput} from '../../scripts/benchmarks/workloads.browser.js';
import assert from 'node:assert/strict';
export function build(){
 const rows=nativeWorkloadInput('points',1000),from=chart().createCanvas({width:400,height:400,margin:20,plotBorder:false}).createData({id:'rows',keyField:'id',values:rows}).createPointMark({id:'points',maxItems:100000}).encodeX({field:'x',scale:{id:'x',domain:[0,1],nice:false}}).encodeY({field:'y',scale:{id:'y',domain:[0,1],nice:false}}),to=from.editScale({id:'x',domain:[0,2],nice:false});
 const geo=chart().createCanvas({width:300,height:200,margin:0}).createGeometryData({id:'places',format:'geojson',coordinateKind:'planar',featureKey:'id',values:{type:'FeatureCollection',features:[{type:'Feature',id:'a',properties:{name:'Alpha'},geometry:{type:'Point',coordinates:[40,50]}}]}}).createProjection({id:'map',type:'identity'}).createCoordinate({type:'geo'}).createGeoPointMark({id:'places-mark'}).createMarkLabels({field:'name'});
 const compose=(point,g)=>hconcat({id:'mixed',programs:[{id:'point',program:point},{id:'geo',program:g}]}),times=[0,25,37,50,75,100],source={};
 const frames=plan=>{const result=times.map(t=>({frame:sampleTransition(plan,t)})),restored=deserializeAnimation(serializeAnimation(plan)).plan;assert.deepEqual(times.map(t=>({frame:sampleTransition(restored,t)})),result);return result;};
 for(const version of[3,4]){
  const options={durationMs:100,easing:'linear',...(version===4?{maxEndpointNodes:3000,maxOutputNodes:2000}:{})},plan=planTransition({from,to,options}),sampled=sampleTransition(plan,37),decision=sampled.decisions.find(d=>d.kernel==='cartesian-point'),fill=sampled.scene.nodes[decision.targetIndex].properties.fill;
  const timelinePlan=planTransition({from,to,options:{...options,tracks:[{target:{ownerKey:decision.ownerKey},property:'geometry',kernel:'native-progress',keyframes:[{timeMs:0,value:0},{timeMs:50,value:.25},{timeMs:100,value:1}]},{target:{itemKey:decision.itemKey},property:'fill',kernel:'color',keyframes:[{timeMs:0,value:fill},{timeMs:50,value:'red'},{timeMs:100,value:fill}]}]}});
  source[version]={native:frames(plan),mixed:frames(planTransition({from:compose(from,geo),to:compose(to,geo.editProjection({scalePx:2})),options})),timeline:frames(timelinePlan),timelineRebaseFrames:frames(planTransition({from:sampleTransition(timelinePlan,37),to,options})),fallback:frames(planTransition({from,to:to.editPointMark({shape:'square'}),options})),rebased:{frame:sampleTransition(planTransition({from:sampled,to,options}),50)}};
 }
 return{source,rows};
}
