// Pure V8 experiment: long-lived WeakSet members plus short-lived registered objects.
const [live, churn] = process.argv.slice(2).map(Number);
const set = new WeakSet(), keep = [];
let t = performance.now();
for (let i = 0; i < live; i++) { const o = { i }; keep.push(o); set.add(o); }
const fill = performance.now() - t;
t = performance.now(); let last = t, worst = 0;
for (let i = 0; i < churn; i++) {
  set.add({ i });
  if ((i & 0xffff) === 0) { const now = performance.now(); worst = Math.max(worst, now - last); last = now; }
}
console.log(JSON.stringify({ live, churn, fillMs: Math.round(fill), churnMs: Math.round(performance.now() - t), worst64kMs: Math.round(worst), kept: keep.length }));
