// Diagnostic only: sample call stacks that add to the global owned registry
// (core/immutable.js) per phase. Exits after the first offline phase.
import { writeFileSync } from "node:fs";

const out = process.env.WS_DIAG_OUT;
const NativeWeakSet = globalThis.WeakSet, nativeAdd = NativeWeakSet.prototype.add;
const root = new URL("../../", import.meta.url).href;
let registry, adds = 0, phase = "native", stages = [];
const startedAt = Date.now(), byPhase = new Map();

class TrackedWeakSet extends NativeWeakSet {
  constructor(iterable) {
    super();
    if (registry === undefined && /core\/immutable\.js:1:/.test(new Error().stack.split("\n")[2] ?? "")) registry = this;
    if (iterable != null) for (const value of iterable) this.add(value);
  }
  add(value) {
    if (this === registry && ++adds % 997 === 0) {
      const frames = new Error().stack.split("\n").slice(2, 9).map(line => line.trim().replace(/^at /, "").replace(root, ""));
      const key = frames.join(" <- ");
      let phaseCounts = byPhase.get(phase);
      if (phaseCounts === undefined) byPhase.set(phase, phaseCounts = new Map());
      phaseCounts.set(key, (phaseCounts.get(key) ?? 0) + 1);
    }
    return nativeAdd.call(this, value);
  }
}
globalThis.WeakSet = TrackedWeakSet;

function dump() {
  const phases = {};
  for (const [name, counts] of byPhase) {
    phases[name] = [...counts].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([stack, samples]) => ({ samples, stack }));
  }
  writeFileSync(out, JSON.stringify({ elapsedMs: Date.now() - startedAt, registryAdds: adds, sampleEvery: 997, stages, phases }, null, 2) + "\n");
}

const log = console.log;
console.log = (...args) => {
  const text = String(args[0]);
  if (/^[a-z-]+$/.test(text)) {
    stages.push({ stage: text, elapsedMs: Date.now() - startedAt, registryAdds: adds });
    phase = text === "native-plan-released" ? "first-offline" : text === "native-offline-plan-released" ? "done" : phase;
    dump();
    if (phase === "done") process.exit(0);
  }
  return log(...args);
};
