// Diagnostic only: attribute WeakSet.add traffic to the construction site of each set.
// Counts are not a pass/fail signal and this preload is never used for qualification.
import { writeFileSync } from "node:fs";

const out = process.env.WS_DIAG_OUT;
const NativeWeakSet = globalThis.WeakSet, nativeAdd = NativeWeakSet.prototype.add;
const sites = new Map(), stages = [], startedAt = Date.now();
let total = 0, lastDump = Date.now(), dumps = 0;
const siteOf = new WeakMap();

function dump(reason) {
  lastDump = Date.now(); dumps++;
  const top = [...sites.values()].sort((a, b) => b.adds - a.adds).slice(0, 15)
    .map(({ site, instances, adds, addsSinceDump }) => ({ site, instances, adds, addsSinceDump }));
  for (const entry of sites.values()) entry.addsSinceDump = 0;
  writeFileSync(out, JSON.stringify({ reason, elapsedMs: lastDump - startedAt, total, dumps, stages,
    memory: process.memoryUsage(), top }, null, 2) + "\n");
}

class TrackedWeakSet extends NativeWeakSet {
  constructor(iterable) {
    super();
    const site = (new Error().stack.split("\n")[2] ?? "").trim().replace(/^at /, "");
    let entry = sites.get(site);
    if (entry === undefined) sites.set(site, entry = { site, instances: 0, adds: 0, addsSinceDump: 0 });
    entry.instances++;
    siteOf.set(this, entry);
    if (iterable != null) for (const value of iterable) this.add(value);
  }
  add(value) {
    const entry = siteOf.get(this);
    if (entry !== undefined) { entry.adds++; entry.addsSinceDump++; }
    if ((++total & 4095) === 0 && Date.now() - lastDump > 10_000) dump("interval");
    return nativeAdd.call(this, value);
  }
}
globalThis.WeakSet = TrackedWeakSet;

const log = console.log;
console.log = (...args) => {
  const text = String(args[0]);
  if (/^[a-z-]+$/.test(text)) { stages.push({ stage: text, elapsedMs: Date.now() - startedAt, total }); dump("stage"); }
  return log(...args);
};
process.on("exit", () => dump("exit"));
