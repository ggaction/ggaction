// Diagnostic only: sample 1/1000 owned-registry additions, attribute each to its
// caller, and count how many of those sampled objects are collected per phase.
import { writeFileSync } from "node:fs";

const out = process.env.WS_DIAG_OUT;
const NativeWeakSet = globalThis.WeakSet, nativeAdd = NativeWeakSet.prototype.add;
const root = new URL("../../", import.meta.url).href;
let registry, adds = 0, phase = "native";
const startedAt = Date.now(), stages = [], sites = new Map();
const finalizer = new FinalizationRegistry(key => { const site = sites.get(key); site.collected++; site.collectedIn[phase] = (site.collectedIn[phase] ?? 0) + 1; });

class TrackedWeakSet extends NativeWeakSet {
  constructor(iterable) {
    super();
    if (registry === undefined && /core\/immutable\.js:1:/.test(new Error().stack.split("\n")[2] ?? "")) registry = this;
    if (iterable != null) for (const value of iterable) this.add(value);
  }
  add(value) {
    if (this === registry && ++adds % 1000 === 0) {
      // Skip immutable.js frames so the key is the first product caller.
      const frames = new Error().stack.split("\n").slice(2).map(line => line.trim().replace(/^at /, "").replace(root, ""));
      const key = frames.filter(frame => !frame.includes("core/immutable.js")).slice(0, 3).join(" <- ");
      let site = sites.get(key);
      if (site === undefined) sites.set(key, site = { key, sampled: 0, sampledIn: {}, collected: 0, collectedIn: {} });
      site.sampled++; site.sampledIn[phase] = (site.sampledIn[phase] ?? 0) + 1;
      finalizer.register(value, key);
    }
    return nativeAdd.call(this, value);
  }
}
globalThis.WeakSet = TrackedWeakSet;

function dump() {
  const top = [...sites.values()].sort((a, b) => b.sampled - a.sampled).slice(0, 25);
  writeFileSync(out, JSON.stringify({ elapsedMs: Date.now() - startedAt, registryAdds: adds, sampleEvery: 1000, stages, top }, null, 2) + "\n");
}
const log = console.log;
console.log = (...args) => {
  const text = String(args[0]);
  if (/^[a-z-]+$/.test(text)) {
    stages.push({ stage: text, elapsedMs: Date.now() - startedAt, registryAdds: adds });
    phase = text === "native-plan-released" ? "first-offline" : text === "native-offline-plan-released" ? "done" : phase;
    // Let finalizers observe the explicit GC the phased script already performed.
    setTimeout(() => {}, 0);
    dump();
    if (phase === "done") { global.gc(); setTimeout(() => { dump(); process.exit(0); }, 200); return log(...args); }
  }
  return log(...args);
};
