from pathlib import Path
import json,gzip,hashlib,shutil
b=Path('.artifacts/geo-a3-merged');d=Path('agent_docs/impl/roadmap9/qualification/geo-a3-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
q={'schemaVersion':1,'status':'verified-geo-hit-and-projection-integration','upstream':'ccd1b2336','archive':a,'checks':{'owningTests':443,'docsAndBoundaries':279,'sameArchiveNodeVersions':[20,22,24],'installedRuntimeAndStrictTypes':True,'documentationExample':True,'browserDPR':[1,2],'bundles':6},'sourceHashes':{},'evidenceFiles':{},'remaining':['original100k sequential and fresh rebase WeakSet rehash','large offline roundtrip','canonical original P95','100cycle large retained lifetime','final combined qualification']}
for path in ['geo-hit-a3-evidence','geo-raw-projection-evidence']:
 src=json.loads(Path('agent_docs/impl/roadmap9/qualification',path,'verification.json').read_text());q['sourceHashes'].update(src['sourceSHA256'])
for f,h in q['sourceHashes'].items(): assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
r=json.loads(Path('.artifacts/geo-hit-a3/installed.json').read_text());assert r['archiveSHA256']==a['sha256'] and len(r['records'])==13 and all(x['status']=='passed' for x in r['records']);shutil.copyfile('.artifacts/geo-hit-a3/installed.json',b/'installed.json')
caps={'ggaction':792700,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/interaction':140172,'ggaction/graph':74500,'ggaction/animation':343663}
for n in [20,22,24]:
 for row in r['bundles'+str(n)]:assert row['gzipBytes']<=caps[row['specifier']],row
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/geo-a3-merged.md').write_text('''# Geo path hit index와 raw projection 합산

Route v2/compiler/decoder 통합 위에 Geo A3 source dd1837f39/pin37d5fcfe4와 raw projection83b487740/pinccd1b2336를 통합했다. 명시 pathGeometry의 Morton index와 모든 indexed shape/clip/query 과금, exact scalar oracle, 원본순서 nearest를 유지한다. Bounds로 안전함을 증명할 수 없는 shape는 기존 full scan을 사용한다. 사전 index allocation guard도 그대로다. Projection의 단일 수학은 그대로 두고 stream에서 즉시 소비하는 중간 결과만 raw로 읽는다. 공개 반환과 최종 projected geometry는 기존 immutable owned 경계를 유지한다.

[합산 기록](geo-a3-merged-evidence/qualification.json): owning443개와 문서·경계279개 통과. 동일 canonical archive를 Node20/22/24에 설치해 실제 runtime/strict types/문서예제/6entry bundle과 Chromium DPR1·2를 확인했다. 원 owning source hash를 비교해 upstream 증거와 연결했다. Node20/24의 animation343,663/interaction140,172 gzip bytes만 실측 cap으로 반영했다.1268entries, unpacked8,223,452, Node22packed1,825,835/Node24packed1,829,581bytes로 archive cap을 동기화했다. 실행 budget과 workload는 그대로다.

Upstream 원100k native/current의 모든 좌표·scalar hit는 통과했지만 sequential 및 fresh rebase plan은 global ownedValues WeakSet rehash에서 멈췄다. 종료된 실행의 partial 결과와 stack은 원 증거에 남는다. 이 합산은 그 실패를 고쳤다는 증거가 아니다. 원100k rebase/offline·P95·100cycle 및 STEP057–070/077의 전체 완료 의무는 열린다. 후속 raw query 변경은 별도 checkpoint다.
''')
p=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=p.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'명시 Geo path hit index와 projection 중간 객체 개선을 합산했다([443 owning·동일 archive3Node/browser](qualification/geo-a3-merged.md)). 원100k native/current 통과와 재시작 plan의 WeakSet rehash 실패를 구분하며 rebase/offline/P95/100cycle은 열린다.\n\n'+s[i:];p.write_text(s)
print(len(q['sourceHashes']),a['sha256'])
