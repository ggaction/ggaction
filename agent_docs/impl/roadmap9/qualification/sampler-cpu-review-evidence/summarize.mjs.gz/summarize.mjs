import {readFile,writeFile} from 'node:fs/promises';
const p=JSON.parse(await readFile('.artifacts/sampler-cpu-review/sample.cpuprofile','utf8')),nodes=new Map(p.nodes.map(n=>[n.id,n])),parents=new Map(),self=new Map(),inclusive=new Map();
for(const n of p.nodes)for(const id of n.children??[])parents.set(id,n.id);
let sampleMs=0,postMs=0;
for(let i=0;i<p.samples.length;i++){const id=p.samples[i],dt=p.timeDeltas[i]/1000;let sample=false;for(let cur=id;cur!==undefined;cur=parents.get(cur)){if(nodes.get(cur).callFrame.functionName==='sampleTransitionWithBudget')sample=true;}
 if(!sample){postMs+=dt;continue;}sampleMs+=dt;self.set(id,(self.get(id)??0)+dt);for(let cur=id;cur!==undefined;cur=parents.get(cur))inclusive.set(cur,(inclusive.get(cur)??0)+dt);}
const functions=p.nodes.map(n=>({name:n.callFrame.functionName,file:n.callFrame.url.split('/ggactionnewbrand/')[1]??n.callFrame.url,line:n.callFrame.lineNumber+1,selfMs:self.get(n.id)??0,inclusiveMs:inclusive.get(n.id)??0,ticks:n.positionTicks})).filter(n=>n.file.startsWith('src/')&&n.inclusiveMs>0).sort((a,b)=>b.selfMs-a.selfMs);
const report={sampleMs,nonSampleProfileMs:postMs,profileTotalMs:(p.endTime-p.startTime)/1000,samplingIntervalUs:1000,functions};await writeFile('.artifacts/sampler-cpu-review/summary.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({sampleMs,nonSampleProfileMs:postMs,functions:functions.slice(0,25)},null,2));
