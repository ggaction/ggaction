from pathlib import Path
import gzip,hashlib,json,re,subprocess
b=Path('.artifacts/position-state-merged');d=Path('agent_docs/impl/roadmap9/qualification/position-state-merged-evidence');d.mkdir(exist_ok=True)
def sha(v):return hashlib.sha256(v).hexdigest()
checks={}
for name in ['coverage.log','boundaries.log','render.log']:
 s=(b/name).read_text();assert '# fail 0' in s,name;checks[name]=int(re.search(r'# tests (\d+)',s)[1])
s=(b/'coverage.log').read_text();m=re.search(r'\bsample.js\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)',s);vals=list(map(float,m.groups()));assert vals[0]>=95 and vals[1]>=90 and vals[2]==100
f='src/animation/sample.js';raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','425d76230:'+f])
a=json.loads((b/'frozen.json').read_text());consumers=[]
for v in [20,22,24]:
 c=json.loads((b/f'installed-{v}.json').read_text());assert c['status']=='passed' and c['artifact']['sha256']==a['sha256'];consumers.append(c)
browser=json.loads((b/'browser-installed.json').read_text());assert browser['status']=='passed' and browser['archiveSHA256']==a['sha256']
q={'status':'point-position-vector-integrated; sample50ms-and-final-closeout-pending','base':'1b4371af8','upstreamSource':subprocess.check_output(['git','rev-parse','425d76230'],text=True).strip(),'upstreamPin':'094386bfb5cc96d19cb07de6afea5c53772b19bd','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Only newly constructed point row/x/y local records bottom-up Object.freeze, then existing freezeOwned on complete positions vector after all branches. No node/provenance/renderer/core/API/schema/guard changes.','sourceSHA256':{f:sha(raw)},'archive':a,'checks':checks,'critical':{'animation/sample.js':dict(zip(['lines','branches','functions'],vals))},'consumers':consumers,'installedBrowser':browser,'product1000':json.loads((b/'product-compare.json').read_text()),'packMeasurements':{str(v):json.loads((b/f'pack{v}.json').read_text()) for v in [20,22,24]},'artifactPolicy':{'entries':1258,'packedBytes':1811600,'unpackedBytes':8152300,'animationGzip':340800,'actualUnpacked':8152265,'runtimeGuardChanges':0},'reusedEvidence':[{'path':'../position-frame-state-evidence/qualification.json','boundary':'One runtime file byte-exact, reuse source-specific original100k native/offline/rebase/full-coordinate/work proof. Fresh root1k old/new,759owning,37contracts,52render and same new archive3Node+minified browser verify composition; no same-SHA100k/SLO claim.'},{'path':'../prepared-scale-merged-evidence/qualification.json','boundary':'Public docs/type/current contracts and non-sample owners unchanged. Reuse246docs/186built pages and prior two-file coverage; fresh installed strict TS/7docs/peers/6bundles cover changed sampler. Source pin regenerates provenance and nine doc contracts.'}],'pending':['Node/frame local freeze and shared scalar mapper still proposals','Common sample50ms/Canvas and partition performance','Geo v5/native camera and hit limits','Data/route responsiveness and numeric bounded policy/native closure/large solvers','Long-lived mixed WeakSet attribution and retained100cycle','Final9commands/independent review/STEP057-077 closeout'],'evidenceFiles':{}}
for p in sorted(b.iterdir()):
 if p.is_file() and p.suffix in ['.log','.json','.mjs','.py']:
  raw=p.read_bytes();(d/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':sha(raw),'bytes':len(raw)}
raw=Path('.artifacts/animation-small-installed.mjs').read_bytes();(d/'animation-small-installed.mjs.gz').write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles']['animation-small-installed.mjs']={'sha256':sha(raw),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(checks,vals,a['sha256'])
