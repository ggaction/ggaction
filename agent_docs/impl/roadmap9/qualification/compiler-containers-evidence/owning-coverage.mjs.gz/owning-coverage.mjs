import {collectTestFiles} from '../../scripts/run-tests.js';
import {spawn} from 'node:child_process';
const files=collectTestFiles('all',undefined,['capability:animation','capability:hit-testing','unit/renderers/','unit/canvas-scene.test.js','unit/scene.test.js']);
const owners=['renderers/canvasScene.js'];
const child=spawn(process.execPath,['--test','--test-concurrency=4','--experimental-test-coverage',...owners.map(file=>'--test-coverage-include=src/'+file),...files],{stdio:'inherit'});child.on('exit',code=>process.exitCode=code);
