import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {BROWSER_BUNDLE_GZIP_LIMITS,measureMinimalBrowserBundle} from '../../scripts/browser-bundle-size.js';
const frozen=JSON.parse(await readFile(process.argv[2],'utf8'));
assert.equal(createHash('sha256').update(await readFile(frozen.file)).digest('hex'),frozen.sha256);
const consumer=await preparePackageConsumer({packageSpec:frozen.file});
const receipt={node:process.version,archive:frozen.sha256,bundles:[]};
try {
 await copyFile('scripts/benchmarks/workloads.browser.js',path.join(consumer.directory,'workloads.mjs'));
 await writeFile(path.join(consumer.directory,'run.mjs'),`import assert from 'node:assert/strict';import{nativeWorkloadInput,prepareNativeWorkload}from'./workloads.mjs';const input=nativeWorkloadInput('points',10000),fixture=prepareNativeWorkload('points',10000,input),stage=fixture.stages.find(s=>s.name==='css-hit');assert.ok(stage);const prepared=stage.prepare();try{for(let i=0;i<9;i++){const result=prepared.run();const witness=prepared.validate(result);assert.equal(witness.queries,3);assert.equal(witness.owner,'points');}}finally{prepared.dispose();}fixture.assertImmutable();console.log('10000 points / 9 exact CSS queries passed');`);
 receipt.runtime=execFileSync(process.execPath,['run.mjs'],{cwd:consumer.directory,encoding:'utf8',timeout:180000}).trim();
 for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)){
  const b=await measureMinimalBrowserBundle(consumer.directory,{specifier});assert.ok(b.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier],JSON.stringify(b));receipt.bundles.push(b);
 }
 await writeFile(process.argv[3],JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
}finally{await consumer.cleanup();}
