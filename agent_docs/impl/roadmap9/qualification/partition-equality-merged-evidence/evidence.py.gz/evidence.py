from pathlib import Path
import json,gzip,hashlib,re,subprocess
p=Path('.artifacts/partition-equality-merged'); out=Path('agent_docs/impl/roadmap9/qualification/partition-equality-merged-evidence');out.mkdir(exist_ok=True)
checks={}
for f in ['focused.log','owning.log','contracts.log','docs.log']:
 s=(p/f).read_text();assert '# fail 0' in s,f;checks[f]=int(re.search(r'# tests (\d+)',s)[1])
a=json.loads((p/'frozen.json').read_text());installed=[]
for n in [20,22,24]:
 r=json.loads((p/f'installed-{n}.json').read_text());assert r['status']=='passed' and r['sha256']==a['sha256'];installed.append(r)
r=json.loads((p/'exact-consumer.json').read_text());assert r['archiveSHA256']==a['sha256'];assert r['consumer']['verified']==4000 and r['consumer']['rebaseVerified']==9000
files={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.stderr','.mjs','.py']:
  raw=f.read_bytes();(out/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[f.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q={'status':'private-partition-equality-integrated; final-native-qualification-pending','base':'165448b50','incoming':'4e399b325','approval':'../../AUTHORIZATION.json#remainingApproval','archive':a,'checks':checks,'installed':installed,'exactConsumer':r,'coverageReuse':{'sourceIdenticalTo':'4e399b325','lines':100,'branches':93.94,'functions':100,'newCoverageRunClaimed':False},'limits':{'entries':1244,'packedBytes':1788900,'unpackedBytes':8053800},'pending':['Original 10000 partition endpoint/work guard support','Large animation lossless transport, complete timing/heap/P95/100-cycle qualification','Final combined candidate required suites'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
(out/'README.md').write_text('''# Partition 그룹 비교 통합 검증\n\n기존 전체 승인 범위에서 exact owned 그룹 쌍의 동일성 비교만 재사용한다. 공개 API, transport, 수학 kernel, 기본/전역 work 한도와 charge는 변경하지 않았다. 호출자 객체·shallow freeze·그룹 교체는 재검증한다.\n\n같은 고정 archive를 Node20/22/24에 실제 설치하고 각 partition 소비자3개·strict 타입·문서 예제·optional peers·6개 browser entry를 검증했다. 별도1000개 전체 cell의4시점과9개 rebase 시점13000개 검증 및 offline 일치를 확인했다. animation 소유712개와 focused44개는 중복 범위로 합산하지 않는다. 원10000개 기본 guard는 여전히 거부하며 이전 단발 속도 관측은 P95/SLO 자격이 아니다.\n\nSource는 incoming4e399와 byte-identical이므로 변경 없는 owner의 기존100/93.94/100 coverage 증거를 재사용한다. 전체 coverage를 새로 실행했다고 주장하지 않는다. Node20/24 최초 packed1,788,824 거부 로그를 보존하고 최소1,788,900 ceiling, 실제 unpacked8,053,787에 최소8,053,800 ceiling을 적용하고 다른 guard는 유지한다. 최종 세부 결과와 raw bytes/hash는 qualification.json 및 gzip evidence가 소유한다.\n''')
print(checks,a['sha256'])
