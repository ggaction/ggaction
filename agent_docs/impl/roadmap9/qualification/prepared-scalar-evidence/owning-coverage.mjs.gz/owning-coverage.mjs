import {collectTestFiles} from '../../scripts/run-tests.js';
import {spawn} from 'node:child_process';
const files=collectTestFiles('unit',undefined,['capability:animation','unit/grammar/scales','unit/actions/scales','unit/grammar/resource-safety.test.js','unit/grammar/measured-radius.test.js','unit/brush-scale-inversion.test.js']);
const owners=['grammar/animation/positions.js','grammar/scales/continuous.js','grammar/scales/transformed.js','grammar/scales/mapping.js'];
const args=['--test','--test-concurrency=4','--experimental-test-coverage',...owners.map(file=>'--test-coverage-include=src/'+file),...files];
const child=spawn(process.execPath,args,{stdio:'inherit'});child.on('exit',code=>process.exitCode=code);
