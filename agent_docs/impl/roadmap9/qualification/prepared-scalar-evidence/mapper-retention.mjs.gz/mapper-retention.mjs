import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {prepareContinuousScaleScalar, mapPreparedContinuousScaleValue} from '../../src/grammar/scales/mapping.js';
import {prepareTransformedScalar} from '../../src/grammar/scales/transformed.js';
assert.equal(typeof global.gc,'function');
function borrowed(type){const input={type,domain:[1,10],range:[0,100]},refs=[new WeakRef(input),new WeakRef(input.domain),new WeakRef(input.range)],token=prepareContinuousScaleScalar(input);return{refs,run:()=>mapPreparedContinuousScaleValue(token,5)};}
function transformed(){const options={type:'pow',exponent:2},domain=[0,10],range=[0,100],refs=[new WeakRef(options),new WeakRef(domain),new WeakRef(range)],scalar=prepareTransformedScalar(domain,range,options);return{refs,run:()=>scalar(5)};}
const cases=['linear','time','log','pow','sqrt','symlog'].map(borrowed);cases.push(transformed());
for(let i=0;i<5;i++){await new Promise(resolve=>setImmediate(resolve));global.gc();}
const alive=cases.flatMap(entry=>entry.refs).filter(ref=>ref.deref()!==undefined).length;
assert.equal(alive,0);for(const entry of cases)assert.ok(Number.isFinite(entry.run()));
const report={node:process.version,cycles:5,liveMappers:cases.length,borrowedReferences:21,retainedBorrowedReferences:alive,scope:'Small explicit-GC reachability proof only, not retained-heap 100-cycle qualification'};
await writeFile(new URL('./mapper-retention.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
