// Same workload as ws-churn.mjs, but exact-object ownership stored as a private field.
class Target { constructor(o) { return o; } }
class Stamp extends Target { #owned; static has(o) { return #owned in o; } }
const own = o => { if (!Stamp.has(o)) { new Stamp(o); } return Object.freeze(o); };
const [live, churn] = process.argv.slice(2).map(Number);
const keep = []; let t = performance.now();
for (let i = 0; i < live; i++) keep.push(own({ i }));
const fill = performance.now() - t; t = performance.now(); let last = t, worst = 0;
for (let i = 0; i < churn; i++) { own({ i }); if ((i & 0xffff) === 0) { const n = performance.now(); worst = Math.max(worst, n - last); last = n; } }
// Semantics probes
const frozenCaller = Object.freeze({ a: 1 });
let frozenStamp; try { const f = Object.freeze({}); new Stamp(f); frozenStamp = Stamp.has(f) ? 'allowed' : 'not-stamped'; } catch (e) { frozenStamp = e.constructor.name; }
const p = new Proxy({}, {}), target = {}; new Stamp(p);
console.log(JSON.stringify({ node: process.version, live, churn, fillMs: Math.round(fill), churnMs: Math.round(performance.now() - t), worst64kMs: Math.round(worst),
  ownedChecks: { kept: Stamp.has(keep[0]), fresh: Stamp.has({}), frozenCaller: Stamp.has(frozenCaller), structuredClone: Stamp.has(structuredClone(keep[0])), spread: Stamp.has({ ...keep[0] }), symbols: Object.getOwnPropertySymbols(keep[0]).length, keys: Object.keys(keep[0]), proxyTargetOwned: Stamp.has(target), proxyOwned: Stamp.has(p) },
  stampOnFrozen: frozenStamp }));
