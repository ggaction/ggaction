import json,pathlib
q=pathlib.Path('agent_docs/impl/roadmap9/qualification/native-acceptance-owner-evidence');q.mkdir(exist_ok=True)
rows=[
 ('AT-04',['CORE','MARKS','GEOMETRY'],['unit/resources/data-update-preparation','unit/resources/prepared-data-public','unit/resources/image-preparation','unit/resources/font-preparation','unit/geo/geometry-data','unit/animation/offline-assets'], '명시 원본 hash/typed 값, 실제 font/image bytes, pre-abort·late load/dispose 및 새 network 차단 프로세스를 각각 검사한다.'),
 ('AT-10',['CORE'],['unit/persistence/program','unit/persistence/codec','contracts/installed-native-families'], '전체 action corpus의 canonical codec·graphics·reset action stack과 새 설치 프로세스의 domain 편집/revision을 실행한다.'),
 ('AT-20',['CORE','COMPOSITION'],['unit/grammar/frame-policy','unit/frame-state','unit/single-y-admission','unit/single-y-aggregate-admission','unit/actions/canvas/responsive-lifecycle','contracts/composition-family-matrix'], '동일 domain이라도 다른 Y identity를 원자 거절하고 range/conditional/independent child panel 및 responsive occupied layout을 검증한다.'),
 ('AT-26',['CORE','COMPOSITION'],['contracts/installed-native-families','contracts/composition-family-matrix','unit/resources/resource-composition'], '정상 발견 suite가 실제 설치한 단일 package의30종 family별 실행 receipt를 요구하며 분석 sibling 조합의 scope와 native sibling 보존을 검증한다.'),
 ('AT-33',['INTERACTION'],['unit/grammar/hit-coordinates','unit/grammar/hit-shapes','unit/grammar/hit-stroke','unit/grammar/hit-index','unit/hit-program','unit/hit-guides','unit/hit-frame'], '독립 literal CSS 역변환, primitive fill/stroke·holes·nested clip·z-order와 native guide/raw key, 실제 DPR1/2/3 painted frame을 결합한다.'),
 ('AT-42',['ANIMATION'],['unit/animation/values','unit/animation/matching','unit/animation/timing','unit/animation/planner','unit/animation/cartesian-values','unit/animation/polar-kernel','unit/animation/partition-transition','unit/animation/graph-tracks','unit/animation/geo-lifecycle'], '독립 수치·state expected와 정확 endpoints, enter/exit/primitive role 및 native Cartesian/polar/partition/graph/Geo 샘플을 검사한다. 동적 축 라벨의 후행 합산 의무는 별도다.'),
 ('AT-43',['ANIMATION','INTERACTION'],['unit/animation/player','unit/animation/rebase','unit/animation/timeline-public','unit/interaction-animation','unit/animation/route-session'], '주입 clock의 play/pause/seek/reverse/rate/repeat, authentic current frame 양방향 rebase와 stale callback/once-only 종료를 검사한다.'),
 ('AT-44',['ANIMATION','GEOMETRY'],['unit/animation/cartesian-fallbacks','unit/animation/cartesian-values','unit/animation/polar-lifecycle','unit/animation/partition-transition','unit/animation/graph-tracks','unit/animation/geo-lifecycle','unit/animation/resource-layout-fallbacks'], 'log semantic 공간·polar seam·native camera를 따르며 호환되지 않는 topology/layout/edited geometry는 명시 fallback으로 유지한다.'),
 ('AT-54',['CORE','ANIMATION'],['contracts/installed-native-families','unit/animation/offline-assets','unit/animation/geo-text-assets'], '설치 suite는 interacted-native-offline-four-formats 및 native-endpoints-animation-replay receipt를 명시 요구한다. 네 출력과 embedded asset frame의 실제 decoded 결과를 확인한다.'),
 ('AT-55',['CORE','ANIMATION','INTERACTION'],['contracts/installed-native-families','unit/geo/interaction','unit/animation/offline-assets','unit/animation/geo-lifecycle','unit/animation/offline'], 'network 차단 fresh process가 저장한 선택/viewport/resources를 복원하고 native endpoints 재계획을 비교한다. Offline plan 단독에 native editing 권한을 꾸며 넣지 않는다.'),
 ('AT-59',['CORE'],['contracts/native-capability-completion','contracts/verification-evidence'], '원래30requirement/79group/577cell을 고정하고 실행 commit·manifest·archive·input/call/expected/actual/diff hash와 nine command receipt를 검증한다. Owner 배정 자체는 completion이 아니다.'),
 ('AT-89',['CORE'],['contracts/installed-native-families','unit/persistence/program','unit/persistence/image-resources'], '실제 bare-package runtime의 domain별 fresh-process edit/revise와 type/schema·resource refs·lineage·codec를 검증한다. 최종 배포 artifact 동일성은 AT61에 남긴다.'),
 ('AT-90',['CORE'],['docs/documentation-coverage','docs/executable-programs','docs/documentation','contracts/documentation-truth'], '공개 defaults/signatures·Current/generated provenance·모든 등록 snippet 실행·negative boundary와 public package 문서 정합을 실제 검증한다.'),
 ('AT-91',['CORE'],['contracts/native-capability-completion','contracts/verification-evidence','contracts/installed-native-families'], '동일 candidate receipt와 발견된 실제 설치 실행을 검증하는 owner를 연결한다. 후보 미제공/누락/실패를 pending/오류로 남기며 최종 CI/registry 증거를 대체하지 않는다.')]
x=json.load(open('test/native-capabilities.json'));groups={r['id']:r for r in x['groups']};audit=[]
for id,contracts,tests,note in rows:
 paths=['test/'+s+'.test.js' for s in tests]
 assert all(pathlib.Path(s).is_file() for s in paths),[s for s in paths if not pathlib.Path(s).is_file()]
 assert groups[id]['owner']['status']=='pending',groups[id]
 groups[id]['owner']={'status':'assigned','contracts':['agent_docs/contract/current/'+c+'.md' for c in contracts],'tests':paths}
 audit.append({'id':id,'tests':paths,'rationale':note})
pathlib.Path('test/native-capabilities.json').write_text(json.dumps(x,indent=2)+'\n')
(q/'audit.json').write_text(json.dumps({'status':'owner-assignment-only; all-candidate-results-pending','groups':audit,'unassigned':['AT-56','AT-60','AT-61','AT-82']},ensure_ascii=False,indent=2)+'\n')
# Installed and documentation evidence run separately; no duplicate full installed sweep.
paths=sorted({p for row in audit for p in row['tests'] if not p.startswith('test/docs/') and p!='test/contracts/installed-native-families.test.js' and p!='test/contracts/documentation-truth.test.js'})
pathlib.Path('.artifacts/native-acceptance-owners/normal-files.json').write_text(json.dumps(paths))
print(len(audit),'group owners;',len(paths),'focused normal files')
