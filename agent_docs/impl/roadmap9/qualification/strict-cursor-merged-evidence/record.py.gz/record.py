from pathlib import Path
import gzip, hashlib, json, re, tarfile

root = Path.cwd()
a = root / '.artifacts/strict-cursor-merged'
out = root / 'agent_docs/impl/roadmap9/qualification/strict-cursor-merged-evidence'
out.mkdir(exist_ok=True)
read = lambda name: json.loads((a / name).read_text())
frozen = read('frozen.json')
assert hashlib.sha256(Path(frozen['file']).read_bytes()).hexdigest() == frozen['sha256']
upstream = json.loads((root / 'agent_docs/impl/roadmap9/chart/strict-value-cursor-evidence/qualification.json').read_text())
sources = [s for s in upstream['sources'] if s['path'].startswith('src/')]
assert len(sources) == 3
with tarfile.open(frozen['file']) as tar:
    for source in sources:
        raw = (root / source['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == source['sha256']
        assert tar.extractfile('package/' + source['path']).read() == raw
tests = {}
for name, count in [('owning', 14), ('related', 18), ('contracts', 37), ('doc-ceiling-recheck', 3)]:
    log = (a / (name + '.log')).read_text()
    assert re.search(r'# tests ' + str(count) + r'\b', log) and '# fail 0' in log
    tests[name] = count
assert re.search(r'all files\s+\|\s*100\.00\s+\|\s*100\.00\s+\|\s*100\.00', (a / 'owning.log').read_text())
installed = {}
for version in [20, 22, 24]:
    r = read('installed-' + str(version) + '.json')
    assert r['sha256'] == frozen['sha256']
    assert len(r['checks']) == 12 and all(c['status'] == 'passed' for c in r['checks'])
    assert r['privateCursor']['tests'] == 14 and r['privateCursor']['status'] == 'passed'
    assert r['types'] == 'passed' and r['snippet']['status'] == 'passed' and len(r['bundles']) == 6
    if version != 22:
        assert r['status'] == 'bundle-limit-failed'
        b = read('budget-recheck' + str(version) + '.json')
        assert b['archiveSHA256'] == frozen['sha256'] and b['status'] == 'passed'
        assert all(c['passed'] and c['actual'] <= c['limit'] for c in b['checks'].values())
    else:
        assert r['status'] == 'passed'
    installed[str(version)] = {'runtime': 12, 'private': 14, 'types': 'passed', 'docs': 1, 'bundles': 6, 'policyRecheckOnly': version != 22}
browser = read('browser.json')
assert browser['sha256'] == frozen['sha256'] and browser['bytesEqual'] and browser['hash'] == browser['oracle']
assert len(browser['aborts']) == 3 and all(x['publications'] == 0 and x['terminals'] == 1 and x['timerRuns'] == 1 and x['cleared'] for x in browser['aborts'])
packs = [read('pack22.json'), read('pack20-final.json'), read('pack24-final.json')]
assert max(x['entryCount'] for x in packs) == 1260
assert max(x['packedBytes'] for x in packs) == 1814595
assert max(x['unpackedBytes'] for x in packs) == 8161542
q = {'status': 'verified-private-cursor-merged-checkpoint', 'basis': 'c6f5db456',
     'upstream': '207e18ac7e87aab25ff2c56f8e3eeacf10186d81',
     'authorization': '../AUTHORIZATION.json#remainingApproval', 'archive': frozen,
     'sources': sources, 'checks': tests, 'coreCoverage': {'line': 100, 'branch': 100, 'function': 100},
     'installed': installed, 'browser': {'bytes': 'passed', 'sha256Oracle': 'passed', 'timerAborts': 3},
     'packSizes': packs, 'artifactCeilings': [1260, 1814600, 8161600],
     'reusedEvidence': {'upstreamCompatibility': 56, 'upstreamInference': 13, 'nativeBodyResult': 'upstream Node20/22/24; exact runtime sources; not a new suite run'},
     'limitations': ['No public route v2 connection', 'No full preparation 100ms qualification', 'No final full suite/P95/100cycle qualification'],
     'evidenceFiles': {}}
for file in sorted(a.iterdir()):
    if file.is_file():
        raw = file.read_bytes()
        (out / (file.name + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
        q['evidenceFiles'][file.name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
(out / 'qualification.json').write_text(json.dumps(q, indent=2) + '\n')
print(json.dumps({'status': q['status'], 'checks': tests, 'archive': frozen['sha256']}))
