from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,re
b=Path('.artifacts/geo-owned-merged');d=Path('agent_docs/impl/roadmap9/qualification/geo-owned-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
f='src/grammar/geo/input.js';raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','542a3b931:'+f])
u=json.loads(Path('agent_docs/impl/roadmap9/qualification/geo-owned-snapshot-evidence/verification.json').read_text());assert hashlib.sha256(raw).hexdigest()==u['sourceSHA256']
q={'schemaVersion':1,'status':'verified-owned-Geo-snapshot-integration','base':'d5715ca1d','upstream':'542a3b931','archive':a,'sourceHashes':{f:hashlib.sha256(raw).hexdigest()},'evidenceFiles':{},'checks':{'inputCoverage':{'lines':100,'branches':100,'functions':100},'sameArchiveNodeVersions':[20,22,24],'strictTypes':True,'browserDPR':[1,2],'browserBundles':6},'upstreamOriginal100k':{'archiveSHA256':u['archiveSHA256'],'result':u['original100k'],'sameOwnedSnapshotSource':True,'scope':'Upstream installed archive. This merged checkpoint does not claim a new original100k run.'},'remaining':['original workloads on final combined archive','exclusive canonical 5+30 performance','original canonical 100cycle lifetime','final roadmap qualification']}
r=json.loads((b/'installed.json').read_text());assert r['archiveSHA256']==a['sha256'] and len(r['records'])==13 and all(x['status']=='passed' for x in r['records'])
caps={'ggaction':793173,'ggaction/basic':426400,'ggaction/svg':26000,'ggaction/interaction':140172,'ggaction/graph':74500,'ggaction/animation':343701}
for n in [20,22,24]:
 for row in r['bundles'+str(n)]:assert row['gzipBytes']<=caps[row['specifier']],row
for label in ['owning','boundaries','cap-docs']:
 s=(b/(label+'.log')).read_text();assert '# fail 0' in s;q['checks'][label]=int(re.search(r'# tests (\d+)',s)[1])
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/geo-owned-merged.md').write_text('''# Geo owned snapshot 합산 검증

Geo JSON의 원 descriptor·cycle·depth·work 검산과 scratch tree 생성 순서를 모두 유지한다. 전체 subtree가 exact owned ordinary tree이고 alias가 없을 때에만 최종 추가 cloneAndFreeze를 생략한다. Caller 입력, 얕게 owned 처리한 mutable child, null prototype, 반복 alias는 기존 복사 경로를 유지한다. Global owned registry나 기본/명시 quota는 바꾸지 않았다.

[합산 증거](geo-owned-merged-evidence/qualification.json)는 owning427개, input100/100/100, source/package/discovery 및 문서 검증을 보존한다. 동일 canonical archive의 Node20/22/24 runtime·strict types·문서·6bundle과 실제 Chromium DPR1/2를 확인했다. Package1268entries/unpacked8,227,795bytes, Node22packed1,826,860·Node24packed1,830,520bytes다. Full793,173 및 animation343,701gzipbytes를 현재 ceiling에 정합했다.

Upstream의 동일 snapshot source가 설치 archive4fbdf2a66fe9a8396b43dcbc6fde2aba2ca0c5e39275a9fe37ef17115db52fa9에서 원100k native/current/rebase/offline 전체 검증을 통과했다. 각199999commands와339849native parts, 전체 scalar4queries 및 current/rebase CSS queries를 유지했다. 이전 rebase 정체는 이 실행에서 재현되지 않았다. 이 결과는 upstream archive의 증거이며 합산 archive에서 새 원100k를 실행했다고 주장하지 않는다.

최종 합산 archive의 원 workload, 장비를 단독 사용하는 canonical5+30 성능, 원 canonical100cycle lifetime은 후속 검증이다. Small100cycle과 Geo100k 기능 검사를 원 lifetime 자격으로 대체하지 않는다. STEP057–070/077은 아직 미완료다.
''')
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'Geo owned snapshot의 최종 중복 복사를 제거했다([427회귀·합산3Node/browser 및 upstream 원100k rebase/offline 통과](qualification/geo-owned-merged.md)). 원 검증·work·registry 경계는 유지하며 최종 합산 성능/lifetime 자격은 남는다.\n\n'+s[i:];f.write_text(s)
print(q['checks'],a['sha256'])
