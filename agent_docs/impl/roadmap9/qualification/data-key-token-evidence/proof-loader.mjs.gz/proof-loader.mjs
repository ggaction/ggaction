import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const manifest = JSON.parse(await readFile(new URL('./source-hashes.json', import.meta.url), 'utf8'));
export async function load(url, context, nextLoad) {
  if (url.split('?')[0] !== manifest.sourceURL) return nextLoad(url, context);
  const control = url.includes('?control') || process.env.IDENTITY_PROOF_VARIANT === 'control';
  const source = await readFile(control ? new URL('./control-itemIdentity.js', import.meta.url) : new URL(manifest.sourceURL), 'utf8');
  const expected = control ? manifest.controlSHA256 : manifest.candidateSHA256;
  if (createHash('sha256').update(source).digest('hex') !== expected) throw new Error('Identity proof source hash differs.');
  return { format: 'module', source, shortCircuit: true };
}
