from pathlib import Path
import subprocess, os
base=Path('.artifacts/data-key-token')
node='/opt/homebrew/Cellar/node@22/22.23.1/bin/node'
env=dict(os.environ,npm_execpath='/opt/homebrew/Cellar/node@22/22.23.1/lib/node_modules/npm/bin/npm-cli.js')
def run(label,args):
 print('START',label,flush=True)
 with (base/(label+'.log')).open('wb') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
 print('PASS',label,flush=True)
files=['test/unit/core/'+name+'.test.js' for name in ['item-identity','identity-comparison','resource-graphic-identity','data-resource-revision','data-source-resource-state']]
files += ['test/unit/actions/data/'+name+'.test.js' for name in ['row-identity','raw-row-keys','row-lineage','source-revision','create-data']]
files += [str(p) for p in Path('test/unit/persistence').glob('*.test.js')]
run('owning',[node,'--experimental-test-coverage','--test','--test-concurrency=1',*files])
run('boundaries',[node,'scripts/run-tests.js','all',*[f'test/contracts/{name}.test.js' for name in ['package-boundaries','test-discovery','documentation-truth','row-identity-types','source-data-types']]])
print('READY_FOR_PACK',flush=True)
