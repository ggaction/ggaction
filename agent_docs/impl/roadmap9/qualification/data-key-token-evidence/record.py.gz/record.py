from pathlib import Path
import gzip,hashlib,json,re,shutil
b=Path('.artifacts/data-key-token');proofbase=Path('.artifacts/data-bottleneck-audit')
d=Path('agent_docs/impl/roadmap9/qualification/data-key-token-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());dest=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],dest);a['file']=str(dest.resolve())
proof=json.loads((proofbase/'proof.json').read_text());assert len(proof['cases'])==88 and proof['savedParseCalls']==128
installed=json.loads((b/'installed.json').read_text());assert installed['status']=='passed' and installed['artifact']['sha256']==a['sha256']
q={'schemaVersion':1,'status':'verified-internal-typed-key-checkpoint','base':'a4a756f0a7a1a4d86016acd668288d7a10cc6c2d','archive':a,'sourceHashes':{},'evidenceFiles':{},'checks':{'exactBehaviorCases':88,'publicReviseRows':32,'typedParseCallsBefore':256,'typedParseCallsAfter':128,'sameArchiveNodes':[x['node'] for x in installed['nodes']],'installedOriginalDataRows':1000,'browserBundles':installed['bundles']},'remaining':['original100k data load/revise and blocking50ms','final combined archive canonical performance and lifetime','remaining roadmap implementation and full qualification']}
for label in ['owning','boundaries','package-final']:
 s=(b/(label+'.log')).read_text();assert '# fail 0' in s;q['checks'][label]=int(re.search(r'# tests (\d+)',s)[1])
q['checks']['itemIdentityCoverage']=json.loads((b/'coverage.json').read_text())
for f in ['src/core/itemIdentity.js','test/unit/core/item-identity.test.js','scripts/package-artifact.js','scripts/browser-bundle-size.js']:
 q['sourceHashes'][f]=hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert q['sourceHashes']['src/core/itemIdentity.js']==proof['source']['candidateSHA256']
for base,prefix in [(b,''),(proofbase,'proof-')]:
 for f in base.iterdir():
  if f.is_file() and f.suffix in ['.json','.log','.stderr','.py','.mjs','.diff']:
   raw=f.read_bytes();name=prefix+f.name;(d/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
f=Path('agent_docs/impl/roadmap9/qualification/data-key-token.md');s=f.read_text();s=s.replace('검증 범위와 정확한 source/archive 기록은 이 checkpoint의 qualification 증거에 고정한다.',f"[검증 기록](data-key-token-evidence/qualification.json)은 관련 {q['checks']['owning']}개 및 경계 {q['checks']['boundaries']}개 검사와 실제 source coverage를 보존한다. 동일 canonical archive를 Node20/22/24에 설치해 원1k data load/revise, 특수값·저장 bytes와6개 entry bundle을 검산했다. 공개 API·선언·Current 계약에는 변경이 없다.")
f.write_text(s)
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'행 ID 문자열의 중복 파싱을 제거했다([동등성·원1k3Node 설치 검증](qualification/data-key-token.md)). 오류·coercion·trace·저장 bytes를 유지하며 원100k 전체 성능 의무는 남는다.\n\n'+s[i:];f.write_text(s)
print(q['checks'],a['sha256'])
