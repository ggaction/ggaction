import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const manifest = JSON.parse(await readFile(new URL('./source-hashes.json', import.meta.url), 'utf8'));
const control = await import(`${manifest.sourceURL}?control`), candidate = await import(manifest.sourceURL);
const { getErrorDetails } = await import(new URL('../../src/diagnostics.js', import.meta.url));
const cases = [];
const stored = (token, keySpec = { mode: 'explicit' }, values = [{}]) => ({
  logicalId: 'logical', allocationId: 'allocation', revision: 0, nextGeneratedKey: 0,
  keySpec, values, rowKeys: [token]
});
const add = (name, factory) => cases.push({ name, factory });
for (const key of [false, true, -0, -3, 1e21, 0n, -12n, '', '__proto__', '\ud800',
  new Date(-1), new Date(8640000000000000), [false, 'x', 12n, new Date(0)]]) {
  const token = control.encodeRowKey(key);
  add(`canonical ${token}`, () => ({ value: stored(token) }));
  add(`standalone ${token}`, () => ({ value: token, standalone: true }));
}
for (const token of ['malformed', '["scalar",[,]]', 'null', '{}', '[]', 'true', '0',
  '["scalar",[]]', '["tuple",[]]', '["scalar",[["number",-0]]]',
  '["scalar",[["number",1.0]]]', '["scalar",[["number",1e0]]]',
  '["scalar",[["number",1e999]]]', '["scalar",[["bigint","01"]]]',
  '["scalar",[["date",8640000000000001]]]', '["scalar",[["unknown",1]]]',
  '["scalar",[null]]', '["tuple",[null]]', '["scalar",[["number",1],["number",2]]]']) {
  add(`invalid source ${token}`, () => ({ value: stored(token) }));
  add(`invalid standalone ${token}`, () => ({ value: token, standalone: true }));
}
for (const key of [undefined, null, false, 0, 1n, Symbol('key')]) {
  add(`nonstring ${String(key)}`, () => ({ value: stored(key) }));
}
for (const failAt of [0, 1, 2]) for (const standalone of [false, true]) {
  add(`coercion failure ${failAt} standalone ${standalone}`, events => {
    let calls = 0;
    const key = { get toString() { events.push('get toString'); return () => {
      events.push('call toString'); if (++calls === failAt) throw new Error('coercion failed');
      return control.encodeRowKey(0);
    }; } };
    return { value: standalone ? key : stored(key), standalone };
  });
}
add('coercion changes between parses', events => {
  let calls = 0;
  return { value: stored({ toString() { events.push('toString'); return ++calls === 1 ? control.encodeRowKey(0) : 'malformed'; } }) };
});
add('row key hole', () => ({ value: { ...stored(''), rowKeys: Array(1) } }));
add('row key nonarray', () => ({ value: { ...stored(''), rowKeys: {} } }));
add('row key accessor', events => ({ value: { ...stored(''), rowKeys: Object.defineProperty([''], '0', {
  get() { events.push('row getter'); return control.encodeRowKey(0); }
}) } }));
add('key field accessor', events => ({ value: stored(control.encodeRowKey(0), { mode: 'field', field: 'id' },
  [Object.defineProperty({}, 'id', { enumerable: true, get() { events.push('field getter'); return 0; } })]) }));
add('key field missing', () => ({ value: stored(control.encodeRowKey(0), { mode: 'field', field: 'id' }) }));
add('key field mismatch', () => ({ value: stored(control.encodeRowKey(0), { mode: 'field', field: 'id' }, [{ id: 1 }]) }));
add('duplicate key', () => ({ value: { ...stored(''), values: [{}, {}], rowKeys: [control.encodeRowKey(0), control.encodeRowKey(0)] } }));
add('invalid field schema', () => ({ value: stored(control.encodeRowKey(0), { mode: 'fields', fields: ['id', 'id'] }) }));
add('generated key', () => ({ value: { ...stored('["generated","allocation",0]', { mode: 'generated' }), nextGeneratedKey: 1 } }));
add('invalid generated key', () => ({ value: { ...stored('["generated","allocation",1]', { mode: 'generated' }), nextGeneratedKey: 1 } }));
add('dataset getter order', events => {
  const base = stored(control.encodeRowKey(0));
  return { value: Object.defineProperties({}, Object.fromEntries(
    Object.entries(base).map(([key, value]) => [key, { enumerable: true, get() { events.push(key); return value; } }])
  )) };
});
const results = [];
for (const entry of cases) {
  const outcomes = [control, candidate].map(api => {
    const events = [], input = entry.factory(events);
    try {
      const result = input.standalone ? api.validateTypedRowKeyToken(input.value) : api.validateSourceIdentity(input.value);
      return { status: 'accepted', exactReference: result === input.value, events };
    } catch (error) { return { status: 'rejected', name: error.name, message: error.message, details: getErrorDetails(error), events }; }
  });
  assert.deepEqual(outcomes[1], outcomes[0], entry.name);
  results.push({ name: entry.name, outcome: outcomes[0] });
}
const loader = fileURLToPath(new URL('./loader.mjs', import.meta.url));
const publicFile = fileURLToPath(new URL('./public-proof.mjs', import.meta.url));
const publicRuns = Object.fromEntries(['control', 'candidate'].map(variant => [variant,
  JSON.parse(execFileSync(process.execPath, ['--no-warnings', '--experimental-loader', loader, publicFile], {
    encoding: 'utf8', env: { ...process.env, IDENTITY_PROOF_VARIANT: variant }, timeout: 30000
  }))]));
assert.deepEqual(publicRuns.control.output, publicRuns.candidate.output);
assert.equal(publicRuns.control.keyParseCalls - publicRuns.candidate.keyParseCalls, 4 * publicRuns.control.rows);
const report = { kind: 'small exact behavior and parse-count proof; no timing or P95 claim', source: manifest,
  cases: results, publicRuns, savedParseCalls: publicRuns.control.keyParseCalls - publicRuns.candidate.keyParseCalls };
await writeFile(new URL('./proof.json', import.meta.url), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ cases: cases.length, rows: publicRuns.control.rows, controlParses: publicRuns.control.keyParseCalls,
  candidateParses: publicRuns.candidate.keyParseCalls, savedParseCalls: report.savedParseCalls }));
