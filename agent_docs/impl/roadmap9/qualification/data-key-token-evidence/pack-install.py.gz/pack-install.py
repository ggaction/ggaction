import subprocess,os
from pathlib import Path
b=Path('.artifacts/data-key-token');node='/opt/homebrew/Cellar/node@22/22.23.1/bin/node'
env=dict(os.environ,npm_execpath='/opt/homebrew/Cellar/node@22/22.23.1/lib/node_modules/npm/bin/npm-cli.js')
with (b/'pack.json').open('wb') as out,(b/'pack.stderr').open('wb') as err:
 subprocess.run([node,'agent_docs/impl/roadmap9/integration/geographic-route-merged-evidence/pack.mjs',str((b/'pack').resolve())],env=env,stdout=out,stderr=err,check=True)
print('PACK_PASS',flush=True)
with (b/'installed.log').open('wb') as out:
 subprocess.run([node,str(b/'installed.mjs'),str(b/'pack.json'),str(b/'installed.json')],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
print('INSTALLED_PASS',flush=True)
