import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { chart } from '../../src/index.js';
import { encodeRowKey } from '../../src/core/itemIdentity.js';
import { serializeProgram } from '../../src/persistence.js';
let nextId = 0;
Object.defineProperty(globalThis.crypto, 'randomUUID', { value: () => `proof-${nextId++}`, configurable: true });
const values = Array.from({ length: 32 }, (_, id) => ({ id, x: id / 32, y: (32 - id) / 32 }));
const base = chart().createCanvas({ width: 400, height: 400, margin: 20, plotBorder: false })
  .createData({ id: 'rows', keyField: 'id', values }).createPointMark({ id: 'points', maxItems: 100000 })
  .encodeX({ field: 'x', scale: { id: 'x', domain: [0, 1], nice: false } })
  .encodeY({ field: 'y', scale: { id: 'y', domain: [0, 1], nice: false } });
const original = serializeProgram(base), revised = values.map(row => ({ ...row, x: row.x / 2 }));
const keys = new Set(values.map(row => encodeRowKey(row.id))), parse = JSON.parse;
let keyParseCalls = 0, after;
try {
  JSON.parse = function(value, ...rest) { if (keys.has(value)) keyParseCalls++; return Reflect.apply(parse, this, [value, ...rest]); };
  after = base.reviseData({ source: 'rows', id: 'revision', values: revised });
} finally { JSON.parse = parse; }
assert.equal(serializeProgram(base), original);
assert.deepEqual(revised, values.map(row => ({ ...row, x: row.x / 2 })));
const digest = value => createHash('sha256').update(typeof value === 'string' ? value : JSON.stringify(value)).digest('hex');
const items = after.graphicSpec.objects.points.items;
assert.equal(items.length, values.length);
items.forEach((item, index) => {
  assert.ok(Math.abs(item.properties.x - (20 + 360 * revised[index].x)) < 1e-9);
  assert.ok(Math.abs(item.properties.y - (380 - 360 * revised[index].y)) < 1e-9);
});
console.log(JSON.stringify({ rows: values.length, keyParseCalls, output: {
  editable: digest(serializeProgram(after)), semantic: digest(after.semanticSpec), graphic: digest(after.graphicSpec),
  trace: digest(after.trace), values: digest(revised), input: digest(original)
} }));
