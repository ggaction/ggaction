import {readFile,writeFile,copyFile} from 'node:fs/promises';import path from 'node:path';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';import {testOptionalDependencies}from'../../scripts/consumers/optional-peers.js';import{run}from'../../scripts/consumers/runtime.js';
const archive=JSON.parse(await readFile('.artifacts/format6/frozen.json','utf8'));const c=await preparePackageConsumer({packageSpec:archive.file});
try{await testOptionalDependencies(c);for(const file of['flows','stream-baselines'])await copyFile(`scripts/consumers/fixtures/node/${file}.mjs`,path.join(c.directory,file+'.mjs'));
await writeFile(path.join(c.directory,'fresh.mjs'),`for(const file of ['flows','stream-baselines']){const {cases}=await import('./'+file+'.mjs');const c=cases.find(x=>x.id.includes('fresh-process'));const s=performance.now();try{await c.run();console.log(c.id,'passed',performance.now()-s)}catch(e){console.error(e,e.stdout?.toString(),e.stderr?.toString());process.exitCode=1;}}`);
try{run(process.execPath,['fresh.mjs'],c.directory,{stdio:'inherit'});}catch(e){process.exitCode=1;}}finally{await c.cleanup();}
