import {readFile} from 'node:fs/promises';
export async function load(url,context,next){
 if(url.endsWith('/scripts/package-artifact.js'))return{format:'module',shortCircuit:true,source:(await readFile(new URL(url),'utf8'))+'\nexport {runPack as measurePack};\n'};
 return next(url,context);
}
