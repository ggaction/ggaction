import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {run,root} from '../../scripts/consumers/runtime.js';
const artifact=JSON.parse(await readFile('.artifacts/format6/frozen.json','utf8'));
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
try {run(process.execPath,['scripts/run-tests.js','browser','test/browser/animation-batched.browser.js','test/browser/circle-batch.browser.js'],root,{env:{...process.env,GGACTION_BATCH_PACKAGE_ROOT:path.join(consumer.directory,'node_modules','ggaction')}});await writeFile('.artifacts/format6/browser-installed.json',JSON.stringify({archiveSHA256:artifact.sha256,sourceRuntimeInputs:0,dpr:[1,2],sceneVersion:3,formatVersion:6,paints:6,status:'passed'},null,2)+'\n');}finally{await consumer.cleanup();}
