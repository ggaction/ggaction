import assert from 'node:assert/strict';
import {writeFile,mkdir,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {chart} from '../../src/index.js';
import {transitionResources,transitionColumnMetrics} from '../../src/animation/planner.js';
import {planTransition,sampleTransition,exportAnimationFrames,serializeAnimation,deserializeAnimation} from '../../src/animation.js';
import {decodeAnimationEnvelope,inspectAnimationEnvelopeValue} from '../../src/animation/envelopeCodec.js';
import {animationResourceAccounting} from '../../src/animation/resources.js';

// Full original fixture and every phase/oracle; at most one prepared plan lives
// across a phase. Explicit GC observes reference lifetime, not retained-heap SLO.
assert.equal(typeof global.gc,'function');
const n=100000,side=Math.ceil(Math.sqrt(n));
const rows=Array.from({length:n},(_,id)=>({id,x:(id%side+1)/(side+1),y:(Math.floor(id/side)+1)/(side+1)}));
const folder='.artifacts/format6';await mkdir(folder,{recursive:true});
const hash=x=>createHash('sha256').update(x).digest('hex');
const result={kind:'Public version6 actual API path, phased plan lifetimes; no instrumentation; not SLO/P95',node:process.version,pid:process.pid,execArgv:process.execArgv,n,inputSHA256:hash(JSON.stringify(rows)),phases:{},lifetime:[]};
console.log(JSON.stringify({pid:process.pid,execArgv:process.execArgv}));
async function stage(name){global.gc();result.stage=name;result.lifetime.push({stage:name,memory:process.memoryUsage()});await writeFile(folder+'/product-100000-phased-partial.json',JSON.stringify(result,null,2)+'\n');console.log(name);}
const from=chart().createCanvas({width:400,height:400,margin:20,plotBorder:false}).createData({id:'rows',keyField:'id',values:rows}).createPointMark({id:'points',maxItems:100000}).encodeX({field:'x',scale:{id:'x',domain:[0,1],nice:false}}).encodeY({field:'y',scale:{id:'y',domain:[0,1],nice:false}});
const to=from.editScale({id:'x',domain:[0,2],nice:false}),limits={maxEndpointNodes:200002,maxOutputNodes:100001},options={durationMs:100,easing:'linear',formatVersion:6};
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7*Math.max(1,Math.abs(b)));
function verify(frame,domain){let count=0;for(const entry of frame.scene.entries){if(entry.kind==='single'){assert.equal(entry.node.type,'rect');continue;}assert.equal(entry.decisions.kernel,'cartesian-point');for(let row=0;row<entry.keys.length;row++){close(entry.properties.x[row],20+360*rows[count].x/domain);close(entry.properties.y[row],380-360*rows[count].y);assert.equal(entry.decisions.targetIndices[row],count+1);count++;}}assert.equal(count,n);}
function nativePhase(){let start=performance.now();const plan=planTransition({from,to,options:{...options,...limits}});assert.equal(plan.version,6);result.phases.prepare={ms:performance.now()-start,accounting:animationResourceAccounting(transitionResources(plan)),columns:transitionColumnMetrics(plan)};global.gc();start=performance.now();const frame=sampleTransition(plan,50);result.phases.sample={ms:performance.now()-start,timing:'pure sample after explicit post-prepare GC; not P95/SLO'};const verifyStart=performance.now();verify(frame,1.5);result.phases.sample.coordinateOracleMs=performance.now()-verifyStart;result.allCoordinatesVerified=n;assert.throws(()=>exportAnimationFrames(plan,{timesMs:Array.from({length:50},(_,i)=>i)}),/Animation frame export work/);result.batch50Rejected=true;const text=serializeAnimation(plan);return{frame,text};}
function offlinePhase(text,expected,domain){const start=performance.now(),restored=deserializeAnimation(text),plan=restored.plan,frame=sampleTransition(plan,50);verify(frame,domain);assert.deepEqual(frame,expected);assert.equal(plan.version,6);assert.equal(serializeAnimation(plan,restored.playback),text);const elapsed=performance.now()-start,payload=decodeAnimationEnvelope(text);const receipt={ms:elapsed,bytes:Buffer.byteLength(text),sha256:hash(text),accounting:animationResourceAccounting(transitionResources(plan)),decodedPayload:inspectAnimationEnvelopeValue(payload,false,true),encodedEnvelope:inspectAnimationEnvelopeValue(JSON.parse(text),true)};assert.equal(receipt.accounting.native,false);return receipt;}
function rebasePhase(frame){const start=performance.now(),plan=planTransition({from:frame,to,options:{...options,...limits}});assert.equal(plan.version,6);assert.equal(sampleTransition(plan,0),frame);const next=sampleTransition(plan,50);verify(next,1.75);result.allRebaseCoordinatesVerified=n;result.phases.rebase={ms:performance.now()-start,accounting:animationResourceAccounting(transitionResources(plan)),columns:transitionColumnMetrics(plan)};const text=serializeAnimation(plan);return{frame:next,text};}
let native=nativePhase();await stage('native-plan-released');
result.phases.offline=offlinePhase(native.text,native.frame,1.5);native.text=undefined;await stage('native-offline-plan-released');
let rebase=rebasePhase(native.frame);native=undefined;await stage('rebase-plan-and-source-frame-released');
result.phases.rebaseOffline=offlinePhase(rebase.text,rebase.frame,1.75);rebase=undefined;await stage('all-native-offline-rebase-exact');
result.sourceSHA256={};for(const file of['src/animation/batchSample.js','src/animation/batchScene.js','src/animation/batchCodec.js','src/grammar/schemas/circleBatch.js','src/animation/columnCodec.js','src/animation/resources.js','src/animation/planner.js','src/animation/envelopeCodec.js','src/animation/sample.js','src/animation/frameEndpoint.js','src/animation/partitionTracks.js','src/materialization/animation/point.js','src/materialization/animation/guides.js','src/core/validation.js','src/selectors/graphicCapacity.js','src/grammar/animation/positions.js','src/grammar/scales/continuous.js','src/grammar/scales/transformed.js','src/grammar/scales/mapping.js','src/animation/appearance.js','src/renderers/canvasScene.js','src/animation/endpoints.js','types/animation.d.ts'])result.sourceSHA256[file]=hash(await readFile(file));
await writeFile(folder+'/product-100000-phased.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
