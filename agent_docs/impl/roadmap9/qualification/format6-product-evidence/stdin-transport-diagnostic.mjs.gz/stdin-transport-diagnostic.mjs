import {readFileSync,openSync,closeSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const input=readFileSync(new URL('./keyboard-stdin.json',import.meta.url));
const code="import fs from 'node:fs';await new Promise(r=>setTimeout(r,0));process.stdout.write(fs.readFileSync(0));";
const result={node:process.version,bytes:input.length,sha256:createHash('sha256').update(input).digest('hex'),ggactionImports:0,timeout:30000};
for(const transport of ['pipe','file']){const fd=transport==='file'?openSync(new URL('./keyboard-stdin.json',import.meta.url),'r'):undefined,start=performance.now();try{const output=execFileSync(process.execPath,['--input-type=module','-e',code],{timeout:30000,...(transport==='pipe'?{input}:{stdio:[fd,'pipe','pipe']})});result[transport]={status:'passed',equal:input.equals(output),ms:performance.now()-start};}catch(error){result[transport]={status:'failed',code:error.code,ms:performance.now()-start};}finally{if(fd!==undefined)closeSync(fd);}}
console.log(JSON.stringify(result,null,2));
