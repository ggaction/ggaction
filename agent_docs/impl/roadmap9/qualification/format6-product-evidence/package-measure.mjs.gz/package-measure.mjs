import {measurePack}from'../../scripts/package-artifact.js';
const m=measurePack(['--dry-run']);console.log(JSON.stringify({node:process.version,name:m.name,version:m.version,entryCount:m.entryCount,packedBytes:m.size,unpackedBytes:m.unpackedSize},null,2));
