import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile}from'node:fs/promises';import path from'node:path';import{createHash}from'node:crypto';
import{preparePackageConsumer}from'../../scripts/package-consumer.js';import{testOptionalDependencies}from'../../scripts/consumers/optional-peers.js';import{run}from'../../scripts/consumers/runtime.js';
const archive=JSON.parse(await readFile('.artifacts/format6/frozen.json','utf8'));assert.equal(createHash('sha256').update(await readFile(archive.file)).digest('hex'),archive.sha256);
const node=process.versions.node.split('.')[0],file=node==='20'?'hit-preparation':'static-delivery',id=node==='20'?'hit-preparation/all-100000-native-points':'static-delivery/native-endpoints-animation-replay';
const consumer=await preparePackageConsumer({packageSpec:archive.file}),record={node:process.version,archiveSHA256:archive.sha256,case:id,fixtureUnchanged:true,configuredTimeoutUnchanged:true,instrumented:false,status:'running',doesNotResolveIntermittentFailure:true};
try{await testOptionalDependencies(consumer);for(const f of[file,'fonts'])await copyFile(`scripts/consumers/fixtures/node/${f}.mjs`,path.join(consumer.directory,f+'.mjs'));
const fixture=await readFile(`scripts/consumers/fixtures/node/${file}.mjs`);record.fixtureSHA256=createHash('sha256').update(fixture).digest('hex');
await writeFile(path.join(consumer.directory,'retry-case.mjs'),`import {cases} from './${file}.mjs';import {writeFile}from'node:fs/promises';console.log(JSON.stringify({childPid:process.pid,case:${JSON.stringify(id)}}));const before=performance.now();await cases.find(c=>c.id===${JSON.stringify(id)}).run();await writeFile('retry-result.json',JSON.stringify({status:'passed',ms:performance.now()-before}));`);
try{run(process.execPath,['retry-case.mjs'],consumer.directory,{stdio:'inherit'});Object.assign(record,JSON.parse(await readFile(path.join(consumer.directory,'retry-result.json'),'utf8')));}catch(error){record.status='failed';record.error=error.stack;process.exitCode=1;}
}finally{await writeFile(`.artifacts/format6/retry${node}.json`,JSON.stringify(record,null,2)+'\n');await consumer.cleanup();}
