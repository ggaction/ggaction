import {readFile} from 'node:fs/promises';
export async function load(url,context,next){
 if(url.endsWith('/src/core/immutable.js')){
  let source=await readFile(new URL(url),'utf8');
  const header=`import {appendFileSync as probeAppend} from 'node:fs';
const probeFile=process.env.GGACTION_REGISTRY_PROBE_OUTPUT;
const probeState={ownedAttempt:0,ownedComplete:0,ancestorAttempt:0,ancestorComplete:0,cloneCalls:0,ownershipChecks:0,phase:'startup'};
const probeRefs=[];
function registryProbe(kind,value,force=false){
 const count=kind==='owned'?++probeState.ownedAttempt:kind==='ancestor'?++probeState.ancestorAttempt:0;
 if(kind==='owned'&&count%4096===0)probeRefs.push(new WeakRef(value));
 if(!force&&count%(kind==='owned'?1024:65536)!==0)return;
 const data={at:Date.now(),kind,...probeState,memory:process.memoryUsage(),stack:new Error().stack,
 ...(value===undefined?{}:{value:Array.isArray(value)?{arrayLength:value.length}:{keys:Object.keys(value).slice(0,8)}})};
 if(kind==='gc-after')data.sampledRegistrations={every:4096,total:probeRefs.length,alive:probeRefs.filter(ref=>ref.deref()!==undefined).length};
 probeAppend(probeFile,JSON.stringify(data)+'\\n');
}
globalThis.__format6RegistryPhase=phase=>{probeState.phase=phase;registryProbe('phase',undefined,true);};
globalThis.__format6RegistryGC=()=>{registryProbe('gc-before',undefined,true);global.gc();registryProbe('gc-after',undefined,true);};
`;
  for(const [before,after]of[
   ['ownedValues.add(value);',"registryProbe('owned',value);ownedValues.add(value);probeState.ownedComplete++;"],
   ['ancestors.add(input);',"registryProbe('ancestor',input);ancestors.add(input);probeState.ancestorComplete++;"],
   ['export function isOwned(value) {','export function isOwned(value) { probeState.ownershipChecks++;'],
   ['export function cloneAndFreeze(value, ancestors = new WeakSet(), path = "state") {','export function cloneAndFreeze(value, ancestors = new WeakSet(), path = "state") { probeState.cloneCalls++;']
  ]){if(!source.includes(before))throw Error('probe anchor missing');source=source.replace(before,after);}
  return{format:'module',shortCircuit:true,source:header+source};
 }
 if(url.endsWith('/.artifacts/format6/product-100000-phased.mjs')){
  let source=await readFile(new URL(url),'utf8');
  source=source.replaceAll('global.gc();','globalThis.__format6RegistryGC();');
  for(const name of['nativePhase','offlinePhase','rebasePhase'])source=source.replace(new RegExp('(function '+name+'\\([^)]*\\)\\{)'),`$1globalThis.__format6RegistryPhase('${name}');`);
  return{format:'module',shortCircuit:true,source};
 }
 return next(url,context);
}
