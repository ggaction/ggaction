import assert from 'node:assert/strict';
import {isDeepStrictEqual} from 'node:util';
import { writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const output=[];
for (const root of ['./baseline/', '../../']) {
 let sequence=0;Object.defineProperty(globalThis.crypto,'randomUUID',{configurable:true,value:()=>`00000000-0000-4000-8000-${String(++sequence).padStart(12,'0')}`});
 const {chart}=await import(new URL(root+'src/index.js',import.meta.url));
 const {planTransition,sampleTransition,serializeAnimation,deserializeAnimation}=await import(new URL(root+'src/animation.js',import.meta.url));
 const from=chart().createCanvas({width:400,height:400,margin:20,plotBorder:false}).createData({id:'rows',keyField:'id',values:Array.from({length:1000},(_,id)=>({id,x:(id+1)/1001,y:(1000-id)/1001}))}).createPointMark({id:'points'}).encodeX({field:'x',scale:{id:'x',domain:[0,1],nice:false}}).encodeY({field:'y',scale:{id:'y',domain:[0,1],nice:false}}),to=from.editScale({id:'x',domain:[0,2],nice:false});
 const result=[];
 for(const extra of[{}, {maxEndpointNodes:200002,maxOutputNodes:100001}, {formatVersion:5}]){
  const options={durationMs:100,easing:'linear',...extra},plan=planTransition({from,to,options}),wire=serializeAnimation(plan),frames=[0,37,100].map(time=>sampleTransition(plan,time)),rebase=planTransition({from:frames[1],to,options}),rebased=serializeAnimation(rebase);
  assert.equal(serializeAnimation(deserializeAnimation(wire).plan),wire);
  const errors=[];for(const mutate of[value=>value.from=structuredClone(frames[1]),value=>value.options.maxOutputNodes=1,value=>value.options.easing='invalid']){const input={from,to,options:{...options}};mutate(input);try{planTransition(input);assert.fail('accepted');}catch(error){errors.push([error.name,error.message]);}}
  result.push({version:plan.version,wire,frames,rebased,rebaseFrame:sampleTransition(rebase,50),errors});
 }
 output.push(result); await writeFile(new URL(`./legacy-${output.length}.json`,import.meta.url),JSON.stringify(result));
}
for(let i=0;i<output[0].length;i++)for(const key of Object.keys(output[0][i]))assert.ok(isDeepStrictEqual(output[1][i][key],output[0][i][key]),`version ${output[0][i].version} ${key} differs`);
const report=output[0].map(({version,wire,rebased,errors})=>({version,wireBytes:Buffer.byteLength(wire),wireSHA256:createHash('sha256').update(wire).digest('hex'),rebaseBytes:Buffer.byteLength(rebased),rebaseSHA256:createHash('sha256').update(rebased).digest('hex'),errors}));
await writeFile(new URL('./legacy-compare.json',import.meta.url),JSON.stringify({baseline:'edb67604f5252982d457588388faec8876778292',node:process.version,fullFramesAndWireExact:true,report},null,2)+'\n');console.log(JSON.stringify(report));
