import {readFile} from 'node:fs/promises';
export async function load(url,context,next){
 if(url.endsWith('/src/animation/columnCodec.js')){
  const original=await readFile(new URL(url),'utf8');
  const needle='return version===1||scalar(values[0]) ? {constant:values[0]} : {node:{array:values.map(lower)}};';
  if(!original.includes(needle))throw Error('Exact prototype source anchor missing');
  return {format:'module',shortCircuit:true,source:original.replace(needle,'return {constant:values[0]};')};
 }
 return next(url,context);
}
