import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import path from 'node:path';import {createHash}from'node:crypto';
import {preparePackageConsumer}from'../../scripts/package-consumer.js';
import {testOptionalDependencies}from'../../scripts/consumers/optional-peers.js';
import {run}from'../../scripts/consumers/runtime.js';
const archive=JSON.parse(await readFile('.artifacts/format6/frozen.json','utf8'));assert.equal(createHash('sha256').update(await readFile(archive.file)).digest('hex'),archive.sha256);
const cases=[['conditional-encoding','conditional-encoding/position-text-lifecycle'],['keyboard-focus','keyboard-focus/nested-native-selection-and-offline-restore'],['geographic-routes','geographic-routes/offline-restored-edit']];
const consumer=await preparePackageConsumer({packageSpec:archive.file}),result={node:process.version,archiveSHA256:archive.sha256,fixtureUnchanged:true,configuredTimeoutUnchanged:true,doesNotResolveIntermittentFailure:true,records:[]};
try{await testOptionalDependencies(consumer);for(const [file,id]of cases){const data=await readFile(`scripts/consumers/fixtures/node/${file}.mjs`);await writeFile(path.join(consumer.directory,file+'.mjs'),data);
 await writeFile(path.join(consumer.directory,'retry.mjs'),`import{cases}from'./${file}.mjs';import{writeFile}from'node:fs/promises';const before=performance.now();await cases.find(c=>c.id===${JSON.stringify(id)}).run();await writeFile('retry-result.json',JSON.stringify({status:'passed',ms:performance.now()-before}));`);
 let record={id,fixtureSHA256:createHash('sha256').update(data).digest('hex')};try{run(process.execPath,['retry.mjs'],consumer.directory,{stdio:'inherit'});Object.assign(record,JSON.parse(await readFile(path.join(consumer.directory,'retry-result.json'),'utf8')));}catch(e){record.status='failed';record.error=e.stack;process.exitCode=1;}result.records.push(record);console.log(id,record.status);}
}finally{await writeFile('.artifacts/format6/repaired-fresh20-retries.json',JSON.stringify(result,null,2)+'\n');await consumer.cleanup();}
