import assert from 'node:assert/strict';
import {chart} from '../../src/index.js';
import {renderToSVG} from '../../src/renderers/svg.js';
import {planTransition,sampleTransition,serializeAnimation,deserializeAnimation} from '../../src/animation.js';
import {animationFrameProvenance} from '../../src/animation/frameProvenance.js';
import {projectBatchSceneRows} from '../../src/animation/batchScene.js';
const a=chart().createCanvas({width:200,height:200,margin:10}).createData({id:'d',keyField:'id',values:Array.from({length:100},(_,i)=>({id:i,x:i/100,y:i/100}))}).createPointMark({id:'p'}).encodeX({field:'x',scale:{id:'x',domain:[0,1],nice:false}}).encodeY({field:'y',scale:{id:'y',domain:[0,1],nice:false}});
const b=a.editScale({id:'x',domain:[0,2],nice:false}),options={durationMs:100,easing:'linear'};
const legacy=planTransition({from:a,to:b,options}),plan=planTransition({from:a,to:b,options:{...options,formatVersion:6}});
for(const t of[0,25,50,100]){
 const f=sampleTransition(plan,t),l=sampleTransition(legacy,t),rows=projectBatchSceneRows(f.scene,animationFrameProvenance(f).positions);
 assert.deepEqual(rows.scene,l.scene);assert.deepEqual(rows.decisions,l.decisions);console.log(t,f.scene.entries.length,renderToSVG(f).length);
}
const restored=deserializeAnimation(serializeAnimation(plan)).plan;assert.equal(restored.version,6);assert.deepEqual(sampleTransition(restored,50),sampleTransition(plan,50));
const start=sampleTransition(plan,37),rebase=planTransition({from:start,to:b,options:{...options,formatVersion:6}});assert.equal(sampleTransition(rebase,0),start);
const wire=serializeAnimation(rebase),offline=deserializeAnimation(wire).plan;assert.equal(serializeAnimation(offline),wire);assert.deepEqual(sampleTransition(offline,50),sampleTransition(rebase,50));console.log('pass',wire.length);
