from pathlib import Path
import json,hashlib,gzip,re,subprocess
p=Path('.artifacts/route-storage-merged');out=Path('agent_docs/impl/roadmap9/qualification/route-storage-merged-evidence');out.mkdir(exist_ok=True)
load=lambda n:json.loads((p/n).read_text())
archive=load('frozen.json');checks={}
for name,count in [('owning.log',83),('coverage.log',92),('contracts-final.log',48),('docs.log',245)]:
 s=(p/name).read_text(); assert '# fail 0' in s; assert int(re.search(r'# tests (\d+)',s)[1])==count;checks[name]=count
assert 'checked 186' in (p/'built-final.log').read_text() and 'verified 1606' in (p/'built-final.log').read_text()
source=load('upstream-source.json')
for f,h in source.items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
 assert hashlib.sha256(subprocess.check_output(['git','show','90ae731513ec85a8eb5bd378a82d5904d1be6da4:'+f])).hexdigest()==h
consumers=[load(f'installed-{n}.json') for n in [20,22,24]]
for c in consumers:
 assert c['status']=='passed' and c['sha256']==archive['sha256'] and c['types']=='passed' and c['snippet']['status']=='passed'
 assert len(c['checks'])==5 and all(x['status']=='passed' for x in c['checks']) and len(c['bundles'])==6
q={'status':'private-route-storage-integrated; large-admission-and-native-performance-pending','base':'f2b28364b7555b9af823d9270dea1c2c09e8d9e9','upstreamSource':'90ae731513ec85a8eb5bd378a82d5904d1be6da4','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Private ordered typed FDEB neighbors and packed density weight/angle/offsets only; same math, scalar order, original charges, guards, diagnostics, result hash, public APIs and schemas.','archive':archive,'checks':checks,'builtDocumentation':{'pages':186,'llmArtifacts':1606},'critical':load('critical.json'),'sourceSHA256':source,'consumers':consumers,'packMeasurements':{str(n):load(f'pack{n}.json') for n in [20,22,24]},'reusedEvidence':[{'path':'../../chart/density-storage-evidence/qualification.json','boundary':'All five runtime owners byte-exact upstream; reuse same-engine old/new whole kernels on Node20/22/24 and original100/1000/10000 default-guard failures from Node22. Root does not claim a new large solver run.'},{'path':'../animation-v4-merged-evidence/qualification.json','boundary':'Animation runtime/type inputs unchanged and installed animation gzip identical; earlier point100k/partition10k whole-output and browser evidence remains source-specific, not a new route-tar execution.'}],'artifactPolicy':{'caps':{'entries':1256,'packedBytes':1808000,'unpackedBytes':8137500,'fullGzip':787400,'graphGzip':68900},'runtimePolicyChanged':False,'initialFailuresRetained':['owning-first.log: invalid guessed test selector, corrected actual graph-presentation owner','pack20-first.log: entry1256 exceeded previous1254 cap; observed tar retained','premeasure20.json: Full787369 and graph68878 exceeded previous artifact caps','docs-first.log: stale generated provenance/LLM; regenerated then245 pass']},'pending':['Explicit bounded-route policy/native worker update union and original large solver completion','Common animation sample50ms/partition gesture and kernel SLO','Geo camera/hit/animation integration','Dedicated P95, retained heap/100cycle, final9commands, independent review and STEP057-077 closeout'],'evidenceFiles':{}}
for f in p.iterdir():
 if f.is_file():
  raw=f.read_bytes();(out/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
