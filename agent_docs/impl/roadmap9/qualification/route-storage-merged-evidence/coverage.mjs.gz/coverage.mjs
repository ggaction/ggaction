import {spawnSync} from 'node:child_process';
import {collectTestFiles,testRunnerArguments} from '../../scripts/run-tests.js';
const files=collectTestFiles('unit',undefined,['unit/grammar/graph/routes','unit/graph-presentation.test.js']);
const args=testRunnerArguments('unit',files);args.splice(2,0,'--experimental-test-coverage','--test-coverage-include=src/grammar/graph/routes/*.js');
console.log(JSON.stringify({files}));const child=spawnSync(process.execPath,args,{stdio:'inherit'});process.exitCode=child.status??1;
