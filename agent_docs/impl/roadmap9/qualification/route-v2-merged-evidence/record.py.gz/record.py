from pathlib import Path
import json,gzip,hashlib,shutil
b=Path('.artifacts/route-v2-merged');dest=Path('agent_docs/impl/roadmap9/qualification/route-v2-merged-evidence');dest.mkdir(exist_ok=True)
p=json.loads((b/'pack.json').read_text());a=Path('.artifacts/integration-archives')/('ggaction-'+p['sha256']+'.tgz');shutil.copyfile(p['file'],a);p['file']=str(a.resolve())
q={'schemaVersion':1,'status':'verified-native-route-v2-integration','base':'edb67604f','upstream':'b86503b56','archive':p,'sourceHashes':{},'evidenceFiles':{},'checks':{'owningTests':181,'docsInitial':{'pass':246,'fail':1,'cause':'search measured size equals strict less-than cap'},'correctedFocusedDocsAndBoundaries':31,'installedSameArchiveNodeVersions':[20,22,24],'publicCasesPerNode':8,'types':True,'browserBundles':6,'realBrowserMinifiedWorker':True,'browserDocs':2},'remaining':['full dependent native continuation B','original density 1k/10k capacity','whole pipeline 100ms and canonical P95','100cycle retained lifetime','final combined qualification']}
up=json.loads(Path('agent_docs/impl/roadmap9/chart/route-v2-native-evidence/qualification.json').read_text())
for row in up['packedSources']:
 f=row['path'];h=row['sha256'];actual=hashlib.sha256(Path(f).read_bytes()).hexdigest();assert actual==h,(f,actual,h);q['sourceHashes'][f]=actual
caps={'ggaction':792700,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/graph':74500,'ggaction/animation':343607,'ggaction/interaction':137700}
for n in [20,22,24]:
 f=Path(f'.artifacts/route-v2-native/installed-{n}.json');r=json.loads(f.read_text());assert r['sha256']==p['sha256'] and r['status']=='passed' and r['types']=='passed';rt=r['runtime'];assert len(rt['records'])==8 and rt['workers']==rt['terminated']==16 and rt['listeners']==0
 for c in rt['records']:assert c['nativeGeometryHash']==c['geometryHash']
 for c in r['bundles']:assert c['gzipBytes']<=caps[c['specifier']],c
 shutil.copyfile(f,b/f.name)
f=Path('.artifacts/route-v2-native/browser.json');r=json.loads(f.read_text());assert r['sha256']==p['sha256'] and r['workers']==r['terminated']==7 and r['listeners']==0;shutil.copyfile(f,b/f.name)
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(dest/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(dest/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/route-v2-merged.md').write_text('''# Bounded native route v2 합산 검증

기존 compiler·format5·decoder 개선 위에 source a29ec070e/pin b86503b56의 명시 bounded-route@1을 통합했다. 37개 packed source hash가 upstream과 일치한다. 기존 v1 기본 동작과 sync/hash/guard는 유지한다. 공개 create/edit가 실제 worker completion을 private native plan으로 검증·물질화하며 입력 전체와 취소·deadline·최종 apply까지 기존 소유자를 유지한다.

[증거](route-v2-merged-evidence/qualification.json)는 owning181개, 최초 docs246통과/1실패 및 strict search cap 교정 뒤31개 통과를 보존한다. Search1,097,221bytes와 strict `<` 정책 때문에 cap을1,097,222로 맞췄다. 동일 canonical archive를 Node20/22/24에 설치해 각8개 실제 public case, strict types,6개 bundle을 확인했다. 각16worker가 전부 종료되고 listener0이었다. 동일 engine의 기존 v1과 v2 geometry hash는 모두 정확히 같다. Density의 Node24 차이는 upstream 숫자 비교 기록대로 보존하며 engine 사이의 bit 동일성을 주장하지 않는다.

실제 Chromium minified worker로 create/edit·Canvas/SVG·abort/deadline과 문서2블록을 실행했다.7worker가 모두 종료되고 listener0, 취소된 작업의 publication0이다. Full792,657/graph74,445/animation343,607 gzip bytes(Node20/24)를 확인했고 animation cap만 기존343,600에서 실측343,607로 갱신했다. Package는1267entries/unpacked8,208,038bytes, Node22packed1,822,674·Node24packed1,826,547bytes다. 실행 quota나 원 workload는 줄이지 않았다.

이는 route v2의 첫 native create/edit 통합 checkpoint다. 후행 route/source/screen/guide/fit/composition continuation, 다중 policy와 held sample, 원 density1k/10k, 전체100ms/P95 및100cycle retained lifetime은 미완료다. STEP057–070/077 전체 완료로 세지 않는다.
''')
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text().replace('공개 route v2는 [구체안 채택](chart/route-v2-adoption.md) 뒤 제품 구현 중이며 기존 v1의 sync/hash/guard를 유지한다.','공개 route v2의 native create/edit를 통합했다([합산3Node·실제 worker 검증](qualification/route-v2-merged.md)). 기존 v1의 sync/hash/guard를 유지하며 후행 native continuation과 전체100ms/P95는 열린다.');f.write_text(s)
print('Verified',len(q['sourceHashes']),'source hashes; installed lifecycle and bundles passed')
