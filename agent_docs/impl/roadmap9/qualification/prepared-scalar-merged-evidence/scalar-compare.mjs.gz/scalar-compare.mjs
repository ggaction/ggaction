import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {writeFile,readFile} from 'node:fs/promises';
import {serialize,deserialize} from 'node:v8';
import './product-observer.mjs';
const outcome=fn=>{try{return{value:fn()};}catch(error){return{error:{name:error.name,message:error.message}};}};
if(process.argv[2]==='child'){
 const m=await import('../../src/grammar/scales/mapping.js'),values=[-Number.MAX_VALUE,-1e308,-1e100,-100,-10,-1,-Number.MIN_VALUE,-0,0,Number.MIN_VALUE,1,10,100,1e100,1e308,Number.MAX_VALUE,NaN,Infinity,-Infinity,null,undefined,'1',{},1n],domains=[[-10,10],[10,-10],[0,1],[1,0],[-0,0],[1,1],[-Number.MAX_VALUE,Number.MAX_VALUE],[-Number.MIN_VALUE,Number.MIN_VALUE],[Number.MIN_VALUE,1],[1,Number.MAX_VALUE],[-1,-100],[100,1],[1,1+Number.EPSILON]],ranges=[[-0,0],[0,-0],[0,100],[100,0],[-Number.MAX_VALUE,Number.MAX_VALUE],[Number.MIN_VALUE,1],[-1e308,-1e307]],params={linear:[{}],time:[{}],log:[{},{base:2},{base:.5},{base:1+Number.EPSILON},{base:Number.MIN_VALUE},{base:1},{base:0}],pow:[{},{exponent:.5},{exponent:2},{exponent:Number.MIN_VALUE},{exponent:Number.MAX_VALUE},{exponent:0}],sqrt:[{}],symlog:[{},{constant:.1},{constant:Number.MIN_VALUE},{constant:Number.MAX_VALUE},{constant:0}]},results=[];
 for(const type of Object.keys(params))for(const param of params[type])for(const domain of domains)for(const range of ranges)for(const clamp of [false,true]){
  const scale={type,domain,range,clamp,...param},prepared=process.env.PRODUCT_BEFORE==='1'?undefined:outcome(()=>m.prepareContinuousScaleScalar(scale));
  for(const value of values){const result=outcome(()=>m.mapContinuousScaleValues([value],scale)[0]);if(prepared!==undefined)assert.deepEqual(prepared.error?prepared:outcome(()=>m.mapPreparedContinuousScaleValue(prepared.value,value)),result);results.push(result);}
 }
 for(const type of Object.keys(params))for(const unknown of [undefined,null,0,'missing'])for(const value of [undefined,null,NaN,Infinity])results.push(outcome(()=>m.mapContinuousScaleValues([value],{type,domain:[1,100],range:[0,100],unknown})[0]));
 await writeFile(new URL('./scalar-'+process.argv[3]+'.v8',import.meta.url),serialize(results));
}else{
 for(const phase of['before','after']){const r=spawnSync(process.execPath,[new URL(import.meta.url).pathname,'child',phase],{env:{...process.env,PRODUCT_BEFORE:phase==='before'?'1':'0'},encoding:'utf8'});assert.equal(r.status,0,r.stderr);}
 const before=deserialize(await readFile(new URL('./scalar-before.v8',import.meta.url))),after=deserialize(await readFile(new URL('./scalar-after.v8',import.meta.url)));assert.deepEqual(after,before);
 const report={node:process.version,baseline:'b3da444d7',comparisons:before.length,exactValueSignedZeroAndErrorClassMessage:true,newVectorAndPreparedScalarEqual:true,originalVectorAndProductEqual:true};await writeFile(new URL('./scalar-compare.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}
