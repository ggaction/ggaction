from pathlib import Path
import gzip, hashlib, json, re, tarfile
a=Path('.artifacts/prepared-scalar-merged'); out=Path('agent_docs/impl/roadmap9/qualification/prepared-scalar-merged-evidence');out.mkdir(exist_ok=True)
read=lambda name:json.loads((a/name).read_text())
f=read('frozen.json');assert hashlib.sha256(Path(f['file']).read_bytes()).hexdigest()==f['sha256']
up=json.loads(Path('agent_docs/impl/roadmap9/qualification/prepared-scalar-evidence/qualification.json').read_text())
sources={}
with tarfile.open(f['file']) as tar:
 for path,digest in up['sourceSHA256'].items():
  assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
  packed=hashlib.sha256(tar.extractfile('package/'+path).read()).hexdigest()
  assert packed==up['archiveSources'][path]['packageSHA256']
  sources[path]={'sourceSHA256':digest,'packageSHA256':packed,'matchesUpstream':True}
checks={}
for name,count in [('owning',1100),('contracts',37),('doc-ceiling-recheck',3)]:
 log=(a/(name+'.log')).read_text();assert re.search(r'# tests '+str(count)+r'\b',log) and '# fail 0' in log;checks[name]=count
limits={'ggaction':788900,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/graph':69600,'ggaction/animation':341600,'ggaction/interaction':137600}
installed={}
for v in [20,22,24]:
 r=read('installed-'+str(v)+'.json');assert r['artifact']['sha256']==f['sha256']
 assert len(r['records'])==10 and all(x['status']=='passed' for x in r['records'])
 assert len(r['bundles'])==6 and all(x['gzipBytes']<=limits[k] for k,x in r['bundles'].items())
 if v!=22:
  assert r['status']=='bundle-limit-failed'
  b={'status':'passed','runtimeReexecuted':False,'archiveSHA256':f['sha256'],'originalReceipt':'installed-'+str(v)+'.json','checks':{k:{'actual':x['gzipBytes'],'limit':limits[k],'passed':True}for k,x in r['bundles'].items()}}
  (a/('budget-recheck'+str(v)+'.json')).write_text(json.dumps(b,indent=2)+'\n')
 else:assert r['status']=='passed'
 installed[str(v)]={'runtime':'animation + point scales','types':'passed','docs':7,'bundles':6,'sameArchive':True,'policyRecheckOnly':v!=22}
b=read('browser-installed.json');assert b['archiveSHA256']==f['sha256'] and b['status']=='passed' and b['sourceRootInputs']==0
comparison=read('product-compare-product-linear.json')
for c in comparison['comparisons'].values():
 assert c['nativeSHA256'][0]==c['nativeSHA256'][1] and c['rebaseSHA256'][0]==c['rebaseSHA256'][1]
 assert all(c[k] for k in ['mixedGeoFullFrameAndMeaningEqual','fullNativeOfflineMeaningBatchRebaseEqual','timelineAndTimelineRebaseFullMeaningEqual','fallbackFullMeaningEqual','restoreReserializeExact'])
packs=[read('pack22.json'),read('pack20-final.json'),read('pack24-final.json')]
assert max(x['packedBytes']for x in packs)==1815492 and max(x['unpackedBytes']for x in packs)==8165281
q={'status':'verified-prepared-scalar-merged-checkpoint','basis':'f2a5c81ff','upstream':'e1a4b7517d59ff1fb39a90e5eae167e026a3734c','authorization':'../AUTHORIZATION.json#remainingApproval','archive':f,'sources':sources,'checks':checks,'installed':installed,'browser':b,'mergedProductComparison':comparison,'packSizes':packs,'artifactCeilings':[1260,1815500,8165300],'bundleCeilings':limits,'reusedEvidence':{'sixScaleTypesAnd91824ScalarOutcomes':'upstream exact 4 runtime sources','original100k':'upstream source-specific all-coordinate/native/offline/rebase, not reexecuted on combined root','callerLifetime':'upstream 21 weak refs, not 100cycle'},'limitations':['50ms and P95 not qualified','100cycle retained heap not qualified','Final full suite not complete'],'evidenceFiles':{}}
for p in sorted(a.iterdir()):
 if p.is_file() and p.suffix in ['.py','.mjs','.log','.json']:
  raw=p.read_bytes();(out/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],f['sha256'])
