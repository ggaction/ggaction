import {registerHooks} from 'node:module';
import {execFileSync} from 'node:child_process';
const source=new URL('../../src/',import.meta.url).href;
const owners=new Set(['grammar/animation/positions.js','grammar/scales/continuous.js','grammar/scales/transformed.js','grammar/scales/mapping.js']);
registerHooks({load(url,context,next){const result=next(url,context);if(!url.startsWith(source))return result;const file=url.slice(source.length);let content=String(result.source);
if(owners.has(file)&&process.env.PRODUCT_BEFORE==='1')content=execFileSync('git',['show','f2a5c81ff:src/'+file],{encoding:'utf8'});
if(file==='core/immutable.js'){
content=content.replace('const clone = array ? new Array(input.length) : {};','const clone = array ? new Array(input.length) : {};if(globalThis.__counts)globalThis.__counts.clones++;');
content=content.replace('ownedValues.add(value);','ownedValues.add(value);if(globalThis.__counts)globalThis.__counts.ownedAdds++;');}
if(file==='animation/resources.js')content=content.replace('export function validateAnimationResourceWork(value,label,scope) {','export function validateAnimationResourceWork(value,label,scope) {if(globalThis.__work)globalThis.__work[label]=Math.max(globalThis.__work[label]??0,value);');
return {...result,source:content};}});
