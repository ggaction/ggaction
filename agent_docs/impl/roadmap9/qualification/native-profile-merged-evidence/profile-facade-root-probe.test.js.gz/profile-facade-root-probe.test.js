import assert from "node:assert/strict";
import test from "node:test";
import { chart, hconcat } from "../src/index.js";
import { getMarkItems } from "../src/inspection.js";
import { exportAccessibleData } from "../src/accessibility.js";
import { createInteractionSession } from "../src/interaction.js";
import { serializeProgram, deserializeProgram } from "../src/persistence.js";
import { planTransition, sampleTransition, serializeAnimation, deserializeAnimation } from "../src/animation.js";

const rows = Object.freeze([
  { id: "a0", series: "A", x: 0, value: 1 }, { id: "a1", series: "A", x: 1, value: 3 }, { id: "a2", series: "A", x: 2, value: 2 },
  { id: "b0", series: "B", x: 0, value: 2 }, { id: "b1", series: "B", x: 1, value: 4 }, { id: "b2", series: "B", x: 2, value: 3 }
].map(Object.freeze));
const base = () => chart().createCanvas({ width: 400, height: 300, margin: 50 })
  .createData({ id: "data", keyField: "id", values: rows });
const families = {
  rose: { build: p => p.createRosePlot({ id: "m", category: "series", value: "value", aggregate: "sum", guides: false }), point: { x: 200, y: 110 }, appearance: "fill" },
  radar: { build: p => p.createRadarPlot({ id: "m", category: { field: "x", fieldType: "ordinal" }, value: { field: "value", scale: { domain: [0, 4], nice: false } }, groupBy: "series", color: "series", guides: false }), point: { x: 200, y: 225 }, appearance: "stroke" },
  streamgraph: { build: p => p.createAreaPlot({ id: "m", x: "x", y: { field: "value", scale: { nice: false } }, groupBy: "series", layout: "wiggle", guides: false }), point: { x: 200, y: 200 }, appearance: "fill" },
  violin: { build: p => p.createViolinPlot({ id: "m", x: "series", y: { field: "value", scale: { domain: [0, 5], nice: false } }, density: { bandwidth: 1, extent: [0, 5], steps: 10 }, guides: false }), point: { x: 125, y: 170 }, appearance: "fill" }
};
const items = p => getMarkItems(p, { target: "m" });
const accessible = p => exportAccessibleData(p, { format: "items" });
const revise = p => p.reviseData({ source: "data", id: "revised", values: rows.map(row => ({ ...row, value: row.value + (row.series === "A" ? .5 : 0) })) });

for (const [family, { build, point, appearance }] of Object.entries(families)) {
  test(`${family} exposes two logical profiles with original rows, exact hit and accessible selection through revision`, () => {
    const p = build(base()), before = serializeProgram(p), original = items(p);
    assert.deepEqual(original.map(item => item.fields.series), ["A", "B"]);
    assert.deepEqual(original.map(item => item.rows.filter(row => row.data === "data").map(row => row.index)), [[0, 1, 2], [3, 4, 5]]);
    if (family === "rose") assert.deepEqual(original.map(item => item.channels.radius), [6, 9]);
    if (family === "violin") assert.deepEqual(original.map(item => item.rows.filter(row => row.data === "mDensityData").length), [10, 10]);
    // Independent coordinates: upper half-disk; Radar's 180-degree value-3 vertex;
    // the middle wiggle column's A band; and category A's center at measurement 2.
    const session = createInteractionSession({ program: p });
    try {
      session.dispatch({ type: "inspect", point });
      assert.equal(session.getState().hit.target.itemKey, original[0].key);
      assert.equal(session.getState().hit.target.ownerId, "m");
    } finally { session.destroy(); }
    const selected = p.selectMarks({ id: "picked", target: "m", field: "series", op: "eq", value: "A" })
      .highlightMarks({ selection: "picked", [appearance]: "#ff0000", bringToFront: false });
    const next = revise(selected), nextItems = items(next);
    assert.deepEqual(nextItems.map(item => item.key), original.map(item => item.key));
    assert.deepEqual(nextItems.map(item => item.rows.filter(row => row.data === "revised").map(row => [row.index, row.revision])), [[[0, 1], [1, 1], [2, 1]], [[3, 1], [4, 1], [5, 1]]]);
    assert.equal(next.graphicSpec.objects.m.items[0].properties[appearance], "#ff0000");
    if (family === "rose") assert.deepEqual(nextItems.map(item => item.channels.radius), [7.5, 9]);
    const exported = accessible(next);
    assert.deepEqual(exported.views[0].items.map(item => [item.fields.series, item.selectedBy, item.visible]), [["A", ["picked"], true], ["B", [], true]]);
    assert.deepEqual(exported.views[0].items.map(item => item.key), nextItems.map(item => item.key));
    const restored = deserializeProgram(serializeProgram(next));
    assert.deepEqual(restored.graphicSpec, next.graphicSpec);
    assert.deepEqual(items(restored), nextItems);
    assert.deepEqual(accessible(restored), exported);
    assert.equal(serializeProgram(p), before);
    const joined = hconcat({ id: "outer", programs: [{ id: "left", program: next }, { id: "right", program: p }] });
    const views = accessible(joined).views;
    assert.deepEqual(views.map(view => view.childPath), [["left"], ["right"]]);
    assert.deepEqual(views.map(view => view.items.map(item => item.selectedBy)), [[["picked"], []], [[], []]]);
    assert.equal(new Set(views.flatMap(view => view.items.map(item => item.key))).size, 4);
    for (const view of views) assert.deepEqual(view.items.map(item => item.key), getMarkItems(joined, { target: { id: "m", childPath: view.childPath } }).map(item => item.key));
    assert.deepEqual(accessible(deserializeProgram(serializeProgram(joined))), accessible(joined));
  });

  test(`${family} facade transition and rebased frame preserve explicit animation policy through offline restore`, () => {
    const from = build(base()), to = revise(from);
    const plan = planTransition({ from, to, options: { durationMs: 100, easing: "linear" } });
    const frame = sampleTransition(plan, 40);
    const restored = deserializeAnimation(serializeAnimation(plan)).plan;
    for (const time of [0, 40, 100]) assert.deepEqual(sampleTransition(restored, time), sampleTransition(plan, time));
    const rebased = planTransition({ from: frame, to: from, options: { durationMs: 60, easing: "linear" } });
    assert.equal(sampleTransition(rebased, 0), frame);
    assert.deepEqual(sampleTransition(deserializeAnimation(serializeAnimation(rebased)).plan, 30), sampleTransition(rebased, 30));
    // The policy assertion below is set from the supported native family contract,
    // separately from renderer-only persistence and endpoint equality.
    assert.ok(plan.tracks.length > 0);
  });
}
