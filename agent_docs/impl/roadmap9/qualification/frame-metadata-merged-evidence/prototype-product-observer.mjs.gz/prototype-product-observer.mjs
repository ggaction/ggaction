import {registerHooks} from 'node:module';
import {readFileSync} from 'node:fs';
const source=new URL('../../src/',import.meta.url).href;
registerHooks({load(url,context,next){const result=next(url,context);if(!url.startsWith(source))return result;const file=url.slice(source.length);let content=String(result.source);
if(['animation/endpoints.js','animation/frameEndpoint.js'].includes(file)&&process.env.POINT_NODE_BEFORE!=='1')content=readFileSync(new URL('./'+file.split('/').at(-1).replace('.js','.mjs'),import.meta.url),'utf8');
if(file==='core/immutable.js'){
content=content.replace('const clone = array ? new Array(input.length) : {};','const clone = array ? new Array(input.length) : {};if(globalThis.__counts)globalThis.__counts.clones++;');
content=content.replace('ownedValues.add(value);','ownedValues.add(value);if(globalThis.__counts)globalThis.__counts.ownedAdds++;');}
if(file==='animation/resources.js')content=content.replace('export function validateAnimationResourceWork(value,label,scope) {','export function validateAnimationResourceWork(value,label,scope) {if(globalThis.__work)globalThis.__work[label]=Math.max(globalThis.__work[label]??0,value);');
return {...result,source:content};}});
