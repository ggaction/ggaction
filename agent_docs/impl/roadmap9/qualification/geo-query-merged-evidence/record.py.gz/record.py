from pathlib import Path
import json,gzip,hashlib,shutil
b=Path('.artifacts/geo-query-merged');d=Path('agent_docs/impl/roadmap9/qualification/geo-query-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
u=json.loads(Path('agent_docs/impl/roadmap9/qualification/geo-raw-path-query-evidence/verification.json').read_text())
q={'schemaVersion':1,'status':'verified-path-query-integration','upstream':'76c02ff06','archive':a,'checks':{'owningTests':53,'sameArchiveNodeVersions':[20,22,24],'installedRuntimeAndStrictTypes':True,'browserDPR':[1,2],'bundles':6},'sourceHashes':{},'evidenceFiles':{},'remaining':['original100k rebase and offline blocked by owned registry rehash','isolated canonical P95','100cycle retained lifetime','final combined qualification']}
f='src/grammar/pathGeometry.js';q['sourceHashes'][f]=hashlib.sha256(Path(f).read_bytes()).hexdigest()
r=json.loads(Path('.artifacts/geo-hit-a3/installed.json').read_text());assert r['archiveSHA256']==a['sha256'] and len(r['records'])==13 and all(x['status']=='passed' for x in r['records']);shutil.copyfile('.artifacts/geo-hit-a3/installed.json',b/'installed.json')
caps={'ggaction':792700,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/interaction':140172,'ggaction/graph':74500,'ggaction/animation':343663}
for n in [20,22,24]:
 for row in r['bundles'+str(n)]:assert row['gzipBytes']<=caps[row['specifier']],row
import re
log=(b/'boundaries.log').read_text();assert '# fail 0' in log;q['checks']['boundaries']=int(re.search(r'# tests (\d+)',log)[1])
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/geo-query-merged.md').write_text('''# Path query 중간 geometry 복사 제거 합산

Hit 판정에서 boolean/number로 즉시 소비하는 flattened geometry는 기존 calculateFlattenedPathCommands 결과를 동기적으로 읽는다. 공개 flatten 반환과 subdivision 오류 diagnostics는 기존 owned 경계를 유지한다. 수학·기본/명시 정책·query 방문과금·최종 shape/좌표·오류 순서는 바뀌지 않는다.

[합산 증거](geo-query-merged-evidence/qualification.json)는 path/shape/stroke/index/stream53회귀 및 package/source 경계, 동일 canonical archive의 Node20/22/24 runtime/types/문서/6bundle과 실제 Chromium DPR1·2를 보존한다. 이전합산 대비unpacked33bytes와Node24packed7bytes만실측cap에반영했다. 원 workload/guard/SLO는 그대로다.

Upstream의 원100k native/current 검산과 실패한 rebaseplan은 별도 기록이다. 재시작을 막는 global owned registry rehash,100cycle·전체P95와 최종 통합 의무는 미완료다. 동시에 다른 source검사가 실행된 중간 canonical 결과는 최종 장비성능 자격으로 세지 않는다.
''')
p=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=p.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'Path hit 판정의 임시 geometry 복사를 줄였다([53회귀·동일 archive3Node/browser](qualification/geo-query-merged.md)). 공개 flatten과 오류 diagnostics의 owned 경계는 유지하며 재시작/P95/100cycle 의무는 열린다.\n\n'+s[i:];p.write_text(s)
print(q['checks'],a['sha256'])
