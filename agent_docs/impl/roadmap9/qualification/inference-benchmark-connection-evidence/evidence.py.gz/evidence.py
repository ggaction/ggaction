from pathlib import Path
import json,hashlib,gzip,re,subprocess
p=Path('.artifacts/inference-benchmark-connection');out=Path('agent_docs/impl/roadmap9/qualification/inference-benchmark-connection-evidence');out.mkdir(exist_ok=True)
r=json.loads((p/'diagnostic/report.json').read_text());assert r['status']=='diagnostic-completed-not-qualification';assert len(r['workloads'])==6
assert r['profile']['warmups']==0 and r['profile']['measured']==1
for c in r['workloads']:
 assert c['networkRequests']==0 and c['status']=='measured'
 assert all(s['status']=='measured' and s['successSLO']=='not-qualified-diagnostic' for s in c['stages'])
 if c['count']==10000:
  assert c['stages'][0]['outputHash']==c['stages'][1]['outputHash']
  assert c['stages'][1]['thresholds']=={'workerMs':10000}
pack=json.loads((p/'package-reassert.json').read_text());assert pack['sha256']==r['archive']['sha256']
s=(p/'contracts-final.log').read_text();assert '# fail 0' in s;passed=int(re.search(r'# tests (\d+)',s)[1])
assert subprocess.check_output(['git','diff','--name-only','HEAD','--','src','types','knowledge','README.md','CHANGELOG.md','package.json'],text=True)==''
files={}
for f in [*p.glob('*.log'),*p.glob('*.json'),*p.glob('*.stderr'),p/'evidence.py',*list((p/'diagnostic').glob('*'))]:
 if f.is_file():
  name=str(f.relative_to(p)).replace('/','--');raw=f.read_bytes();(out/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));files[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q={'status':'original-inference-benchmark-connected-to-public-worker; final-performance-qualification-pending','base':'2e654b817','approval':'../../AUTHORIZATION.json#remainingApproval','runtimeArchiveSHA256':r['archive']['sha256'],'runtimeInputsChanged':False,'archiveReassertedByteIdentical':True,'contracts':passed,'fixtures':json.loads((p/'fixtures.json').read_text()),'diagnostic':{'source':'diagnostic--report.json.gz','cases':6,'stages':8,'DPR':[1,2],'warmups':0,'measured':1,'allOriginalNodesAnd100000EdgesValidated':True,'sameCompleteResourceHashForSyncAndWorker':True,'zeroPostBootstrapRequests':True,'qualification':False,'largeWorkerMs':[c['stages'][1]['samples'][0]['workerMs']for c in r['workloads'] if c['count']==10000]},'timing':'Worker metric includes startup/copy/compute/main validation. Compute-only and apply are separate diagnostics. No changed sizes, seed, full-output oracle, math or SLO. Explicit existing inference capacity/execution policy is selected; default support is not inferred.','pending':['Final combined candidate P95/retained heap/100 cycles','Large inference worker remains above original 10000ms goal','Other native family qualification and original final required suites'],'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(passed,q['diagnostic']['largeWorkerMs'],r['archive']['sha256'])
