import {collectTestFiles} from '../../scripts/run-tests.js';
import {spawn} from 'node:child_process';
const files=collectTestFiles('unit',undefined,['capability:animation']);
const owners=['animation/planner.js','animation/geoTracks.js','grammar/animation/geoState.js','materialization/animation/geoPresentation.js'];
const args=['--test','--test-concurrency=4','--experimental-test-coverage',...owners.map(file=>'--test-coverage-include=src/'+file),...files];
const child=spawn(process.execPath,args,{stdio:'inherit'});child.on('exit',code=>process.exitCode=code);
