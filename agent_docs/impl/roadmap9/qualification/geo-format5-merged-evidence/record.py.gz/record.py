from pathlib import Path
import gzip,hashlib,json,re,tarfile
a=Path('.artifacts/geo-format5-merged');out=Path('agent_docs/impl/roadmap9/qualification/geo-format5-merged-evidence');out.mkdir(exist_ok=True)
read=lambda name:json.loads((a/name).read_text())
f=read('frozen.json');assert hashlib.sha256(Path(f['file']).read_bytes()).hexdigest()==f['sha256']
up=json.loads(Path('agent_docs/impl/roadmap9/qualification/geo-format5-evidence/qualification.json').read_text())
with tarfile.open(f['file']) as tar:
 for path,digest in up['sourceInputs'].items():
  raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest,path
  assert tar.extractfile('package/'+path).read()==raw,path
checks={}
for name,count in [('owning',818),('contracts',37),('docs-freshness-recheck',18),('doc-ceiling-recheck',3)]:
 s=(a/(name+'.log')).read_text();assert '# fail 0' in s and re.search(r'# tests '+str(count)+r'\b',s);checks[name]=count
s=(a/'docs.log').read_text();assert '# tests 247' in s and '# pass 246' in s and '# fail 1' in s and 'docs/_data/provenance.json is stale.' in s
limits={'ggaction':788900,'ggaction/basic':426300,'ggaction/svg':26000,'ggaction/graph':69600,'ggaction/animation':343500,'ggaction/interaction':137600}
installed={}
for v in [20,22,24]:
 r=read('installed-'+str(v)+'.json');assert r['artifact']['sha256']==f['sha256']
 assert len(r['records'])==11 and all(x['status']=='passed' for x in r['records'])
 assert len(r['bundles'])==6 and all(x['gzipBytes']<=limits[k] for k,x in r['bundles'].items())
 if v!=22:
  assert r['status']=='bundle-limit-failed'
  b={'status':'passed','runtimeReexecuted':False,'archiveSHA256':f['sha256'],'originalReceipt':'installed-'+str(v)+'.json','checks':{k:{'actual':x['gzipBytes'],'limit':limits[k],'passed':True}for k,x in r['bundles'].items()}}
  (a/('budget-recheck'+str(v)+'.json')).write_text(json.dumps(b,indent=2)+'\n')
 else:assert r['status']=='passed'
 installed[str(v)]={'runtime':'animation + point scales + geographic animation including installed 4-renderer numeric path','types':'passed','docs':8,'bundles':6,'sameArchive':True,'policyRecheckOnly':v!=22}
b=read('browser-installed.json');assert b['archiveSHA256']==f['sha256'] and b['status']=='passed' and b['sourceRootInputs']==0 and b['versions']==[3,4,5]
small=read('original-1000.json');assert small['archive']['sha256']==f['sha256'] and len(small['cases'])==1 and small['cases'][0]['count']==1000 and small['cases'][0]['status']=='passed'
packs=[read('pack22.json'),read('pack20-final.json'),read('pack24-final.json')]
assert max(x['packedBytes']for x in packs)==1818357 and max(x['unpackedBytes']for x in packs)==8175416
q={'status':'verified-format5-geographic-merged-checkpoint','basis':'af936021b','upstream':'45d086ecec9cc7b2d81f21625ebc79272612c439','authorization':'../AUTHORIZATION.json#remainingApproval','archive':f,'sourceInputs':up['sourceInputs'],'exactUpstreamAndArchiveSources':True,'checks':checks,'documentation':{'firstRun':{'tests':247,'passed':246,'failed':1,'failure':'stale generated provenance'},'repair':'regenerated provenance/machine/llms; entire owning freshness file18 passed','fullDocsSuiteRerun':False},'critical':up['critical'],'installed':installed,'browser':b,'original1000':small,'packSizes':packs,'artifactCeilings':[1261,1818400,8175500],'bundleCeilings':limits,'reusedEvidence':{'privateColumnsCritical':'exact upstream source: columnCodec100/98.33/100 numericColumns100/100/100; included functional regressions in merged animation suite','original100k':'upstream source-specific all-coordinate/native/offline/rebase; batch4pass/5reject; exact13inputs, not repeated combined-root large run','familyClosure':'upstream28family; merged owning818 includes all current animation tests'},'limitations':['Canvas common sampler50ms/P95 not qualified','Geo hit/query capacity separate A3','100cycle retained heap not qualified','Final full suite not complete'],'evidenceFiles':{}}
for p in sorted(a.iterdir()):
 if p.is_file() and p.suffix in ['.py','.mjs','.log','.json']:
  raw=p.read_bytes();(out/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],f['sha256'])
