import { Session } from 'node:inspector';
const repo = process.argv[2], count = Number(process.argv[3]);
const { prepareNativeWorkload } = await import(repo + '/scripts/benchmarks/workloads.browser.js');
const w = prepareNativeWorkload('geo', count), p = w.stages.find(s => s.name === 'camera-preview').prepare();
for (let i = 0; i < 5; i++) p.run();
const s = new Session(); s.connect(); const post = (m, a = {}) => new Promise((r, j) => s.post(m, a, (e, v) => e ? j(e) : r(v)));
await post('Profiler.enable'); await post('Profiler.setSamplingInterval', { interval: 200 }); await post('Profiler.start');
for (let i = 0; i < 5; i++) p.run();
const { profile } = await post('Profiler.stop');
const byId = new Map(profile.nodes.map(x => [x.id, x])), parent = new Map();
for (const n of profile.nodes) for (const c of n.children || []) parent.set(c, n.id);
const self = new Map(); profile.samples.forEach((id, i) => self.set(id, (self.get(id) || 0) + (profile.timeDeltas[i] || 0) / 1000 / 5));
const fname = id => byId.get(id).callFrame.functionName;
const inclusive = new Map();
for (const [id, v] of self) { const seen = new Set(); let c = id; while (c) { const f = fname(c) + ' ' + byId.get(c).callFrame.url.split('/').slice(-1)[0]; if (!seen.has(f)) { inclusive.set(f, (inclusive.get(f) || 0) + v); seen.add(f); } c = parent.get(c); } }
const want = /sampleTransition|sampleGeoTracks|admitGeoAnimationPresentation|resolveSampledGeoPresentation|materializeGeoAnimationPresentation|projectGeometry|normalizeAnimationGeoGroup|snapshotGeometryJSON|normalizeGeometry|lineCoordinates|canvasSceneProgram|validateConcreteGraphicProperties|materializeFillItemsInPlot|geoMarkGeometry|cloneAndFreeze|sampleGeoInterpolation|finish|registerAnimationFrame|validateGeoMarkGeometry|projectSampled|canonicalJSON/;
console.log([...inclusive].filter(([k]) => want.test(k)).sort((a, b) => b[1] - a[1]).slice(0, 26).map(([k, v]) => v.toFixed(1) + 'ms ' + k).join('\n'));
