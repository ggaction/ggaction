# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,gzip,tarfile,subprocess,re
prefix=Path('.artifacts/format5-resume');target=Path('agent_docs/impl/roadmap9/qualification/geo-format5-evidence');target.mkdir(exist_ok=True)
read=lambda name:json.loads((prefix/name).read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest()
a=read('archive.json');assert sha(Path(a['file']).read_bytes())==a['sha256']
large=read('large.json');assert large['archive']['sha256']==a['sha256'];assert [x['count'] for x in large['cases']]==[1000,10000,100000];assert all(x['status']=='passed' for x in large['cases']);assert large['cases'][-1]['phases'][-1]['id']=='batch-five-original-limit'
files=['src/animation/planner.js','src/animation/geoTracks.js','src/grammar/animation/geoState.js','src/materialization/animation/geoPresentation.js','src/animation/columnCodec.js','src/animation/numericColumns.js','src/animation/resources.js','src/animation/frames.js','src/animation/sample.js','src/grammar/geo/stream.js','src/grammar/geo/capacity.js','src/grammar/geo/markGeometry.js','types/animation.d.ts']
with tarfile.open(a['file']) as tar:
 hashes={}
 for file in files:
  raw=Path(file).read_bytes();assert tar.extractfile('package/'+file).read()==raw;hashes[file]=sha(raw)
installed={v:read('installed'+v+'.json') for v in ['20','22','24']}
for receipt in installed.values():
 assert receipt['artifact']['sha256']==a['sha256'];assert receipt['status']=='passed';assert all(x['status']=='passed' for x in receipt['records']);assert receipt['bundles']['ggaction/animation']['gzipBytes']<=342700
browser=read('browser-installed.json');assert browser['archiveSHA256']==a['sha256'] and browser['versions']==[3,4,5] and browser['status']=='passed'
checks={'owning-final.log':810,'multiple-groups.log':1,'contracts-first.log':37,'artifact-contracts.log':10,'manifest-final.log':1,'docs-fixed.log':247,'render.log':52,'docs-final-contracts.log':9,'budget-documentation.log':3}
for name,count in checks.items():
 s=(prefix/name).read_text();assert '# fail 0' in s,(name,s[-500:]);assert int(re.search(r'# tests (\d+)',s)[1])==count,(name,count)
q={'kind':'explicit animation format5 and native geographic capacity functional qualification','sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceState':'verified worktree; source pin follows code commit','archive':a,'sourceInputs':hashes,'originalFixtures':large,'installed':{v:{'node':r['node'],'status':r['status'],'records':r['records'],'bundles':r['bundles']} for v,r in installed.items()},'browser':browser,'checks':checks,'critical':{'planner.js':[100,94.47,100],'geoTracks.js':[100,100,100],'geoState.js':[100,97.96,100],'geoPresentation.js':[100,95.29,100]},'package':{v:read('pack'+v+'.json') for v in ['20','24']},'caps':{'entries':1260,'packedBytes':1814800,'unpackedBytes':8163200,'animationGzip':342700,'searchBytes':1096500},'remaining':['Common sampler Canvas 50ms/P95 and retained 100-cycle final qualification','Geo hit/query capacity remains separate','Final roadmap integration and protected release are not closed'],'evidenceFiles':{}}
for f in prefix.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.mjs','.py']:
  raw=f.read_bytes();(target/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':sha(raw),'bytes':len(raw)}
for f in (prefix/'first-pass').iterdir():
 if f.suffix in ['.json','.log']:
  raw=f.read_bytes();(target/('first-pass-'+f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles']['first-pass/'+f.name]={'sha256':sha(raw),'bytes':len(raw)}
for f in [Path('.artifacts/format5-installed.mjs'),Path('.artifacts/format5-followup-installed.mjs')]:
 raw=f.read_bytes();(target/f.name).write_bytes(raw);q['evidenceFiles'][f.name]={'sha256':sha(raw),'bytes':len(raw)}
(target/'large.mjs').write_bytes((prefix/'large.mjs').read_bytes());(target/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(a['sha256'],large['cases'][-1]['nativeBytes'],large['cases'][-1]['rebaseBytes'])
