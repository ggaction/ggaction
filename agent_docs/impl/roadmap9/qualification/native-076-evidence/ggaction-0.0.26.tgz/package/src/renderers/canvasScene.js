import { validateConcreteGraphicProperties } from "../grammar/schemas/concreteGraphic.js";
import { translateFillPaint } from "../grammar/paint.js";
import { validateGraphicClip, translateGraphicClip } from "../grammar/schemas/graphicClip.js";
import { isOwned, cloneAndFreeze, freezeOwned } from "../core/immutable.js";
import { ownArray, ownRecord } from "../core/ownData.js";
import { contentDigest } from "../core/contentDigest.js";
import { translateWeightedBlendSources } from "../grammar/schemas/weightedBlend.js";
import { batchGraphicRowCount, isBatchGraphicType } from "../grammar/schemas/batchGraphic.js";

const compiled = new WeakMap();
// Translate only concrete position properties. Path/text child coordinates keep
// their authored relationship; gradients retain their local bounding-box units.
function position(properties, dx, dy) {
  if (!dx && !dy) return properties;
  const result = { ...properties };
  if (properties.sources) result.sources = translateWeightedBlendSources(properties.sources, dx, dy);
  if (properties.fill !== undefined) result.fill = translateFillPaint(properties.fill, dx, dy);
  if (properties.fillBounds) result.fillBounds = { left: properties.fillBounds.left + dx, right: properties.fillBounds.right + dx,
    top: properties.fillBounds.top + dy, bottom: properties.fillBounds.bottom + dy };
  for (const key of ['x', 'x1', 'x2']) if (key in result) result[key] += dx;
  for (const key of ['y', 'y1', 'y2']) if (key in result) result[key] += dy;
  if (result.commands) result.commands = result.commands.map(command => position(command, dx, dy));
  return result;
}
// An owned array is a frozen exact value, so one full structure check stays valid
// for every later frame that reuses it. Caller arrays are checked every time.
const checkedOwnedRunKeys = new WeakSet();
// The exact key tuple of a fully checked owned scene, one slot per anchor run.
// A later scene skips only the cross-entry uniqueness pass when every entry is
// owned and its whole tuple matches exactly; any miss runs every check again.
const uniqueKeyTuples = new WeakMap();
function ownedKeyTuple(entries) {
  if (!isOwned(entries)) return undefined;
  const tuple = [];
  for (const entry of entries) {
    if (!isOwned(entry)) return undefined;
    if (entry.kind === "single" && isOwned(entry.node)) tuple.push(entry.node.key);
    else if ((entry.kind === "circle-run" || entry.kind === "path-run") && checkedOwnedRunKeys.has(entry.keys)) tuple.push(entry.keys);
    else return undefined;
  }
  return tuple.some(part => typeof part === "object") ? tuple : undefined;
}
function* concreteEntries(scene) {
  if (scene.version === 2) { for (const node of scene.nodes) yield { node }; return; }
  const tuple = ownedKeyTuple(scene.entries), anchor = tuple?.find(part => typeof part === "object");
  const known = tuple !== undefined && uniqueKeyTuples.get(anchor), unique = known !== undefined && known !== false &&
    known.length === tuple.length && known.every((part, index) => part === tuple[index]);
  const logicalKeys = new Set();
  for (let entryIndex = 0; entryIndex < scene.entries.length; entryIndex++) {
    const entry = scene.entries[entryIndex];
    let node, keys;
    if (entry.kind === "single") { node = entry.node; keys = [node.key]; }
    else if (entry.kind === "circle-run" || entry.kind === "path-run") {
      const type = entry.kind === "circle-run" ? "circle-batch" : "path-batch", label = entry.kind === "circle-run" ? "Circle" : "Path";
      validateConcreteGraphicProperties(type, entry.properties);
      if (!checkedOwnedRunKeys.has(entry.keys)) {
        ownArray(entry.keys, `${label} run keys`);
        if (isOwned(entry.keys)) checkedOwnedRunKeys.add(entry.keys);
      }
      if (entry.keys.length !== batchGraphicRowCount(type, entry.properties)) throw new TypeError(`${label} run keys must follow every coordinate row.`);
      node = { key: `animation/node/${entryIndex}`, type, properties: entry.properties,
        offset: entry.offset, clip: entry.clip, clips: entry.clips }; keys = entry.keys;
    } else throw new TypeError("Unknown Canvas scene entry kind.");
    if (!unique) for (const key of keys) {
      if (typeof key !== "string" || logicalKeys.has(key)) throw new TypeError("Canvas scene nodes require unique keys.");
      logicalKeys.add(key);
    }
    yield { node, graphicId: `animation/node/${entryIndex}`, batch: entry.kind !== "single" };
  }
  if (tuple !== undefined && !unique) uniqueKeyTuples.set(anchor, tuple);
}
function positionBatch(properties, dx, dy) {
  if (!dx && !dy) return properties;
  return { ...properties, x: properties.x.map(value => value + dx), y: properties.y.map(value => value + dy),
    appearance: position(properties.appearance, dx, dy) };
}
function compile(scene) {
  if (![2, 3].includes(scene?.version) || ![scene.width, scene.height].every(n => Number.isFinite(n) && n > 0) ||
      !Array.isArray(scene.version === 3 ? scene.entries : scene.nodes)) {
    throw new TypeError('renderTransitionScene requires a version 2 or 3 Canvas scene.');
  }
  const objects = { canvas: { type: 'canvas', properties: { width: scene.width, height: scene.height }, children: [] } };
  // Only locally created groups and wrappers still requiring a snapshot.
  const pending = [['canvas',objects.canvas]];
  const keys = new Set();
  let index = 0, activeClips = [];
  const groups = [objects.canvas], origins = [[0, 0]];
  const validClip = clip => Array.isArray(clip) && clip.length === 4 &&
    clip.every(Number.isFinite) && clip[2] >= 0 && clip[3] >= 0;
  const validFrame = clip => {
    if (Array.isArray(clip)) return validClip(clip);
    if (clip?.type !== "path") return false;
    validateGraphicClip(clip, "collection");
    return true;
  };
  const sameClip = (a, b) => a === b || JSON.stringify(a) === JSON.stringify(b);
  for (const { node, graphicId, batch } of concreteEntries(scene)) {
    const clips = node.clips ?? [node.clip];
    if (typeof node.key !== 'string' || keys.has(graphicId ?? node.key) ||
        !(batch ? isBatchGraphicType(node.type) : ['circle','rect','line','path','text','image','weighted-blend'].includes(node.type)) ||
        node.offset?.length !== 2 || !node.offset.every(Number.isFinite) || !validClip(node.clip) ||
        !Array.isArray(clips) || !clips.every(validFrame) || !node.properties || typeof node.properties !== 'object') {
      throw new TypeError('Canvas scene nodes require unique keys, concrete properties, offsets and clips.');
    }
    keys.add(graphicId ?? node.key);
    if (batch) validateConcreteGraphicProperties(node.type, node.properties);
    let common = 0;
    while (common < Math.min(clips.length, activeClips.length) &&
        sameClip(clips[common], activeClips[common])) common++;
    groups.length = common + 1; origins.length = common + 1;
    // Retain shared concrete clip ancestors across adjacent nodes. Rebuilding
    // a fractional ancestor between its children can change raster coverage.
    for (let i = common; i < clips.length; i++) {
      const clip = clips[i], origin = origins.at(-1), parent = groups.at(-1);
      const id = `clip-${index++}`;
      const pathClip = clip.type === "path";
      const nested = objects[id] = pathClip ? { type: "collection", items: [],
        clip: translateGraphicClip(clip, -origin[0], -origin[1]), children: [] }
        : { type: 'canvas', properties: {
          x: clip[0] - origin[0], y: clip[1] - origin[1], width: clip[2], height: clip[3]
        }, children: [] };
      pending.push([id,nested]);
      parent.children.push(id); groups.push(nested); origins.push(pathClip ? origin : [clip[0], clip[1]]);
    }
    activeClips = clips;
    const group = groups.at(-1), origin = origins.at(-1);
    const id = graphicId ?? `node-${index++}`;
    const object = { type: node.type, properties: (batch ? positionBatch : position)(node.properties,
      node.offset[0] - origin[0], node.offset[1] - origin[1]) };
    if(isOwned(object.properties))objects[id]=freezeOwned(object);
    else {objects[id]=object;pending.push([id,object]);}
    group.children.push(id);
  }
  // Preserve insertion/error order after every node has passed validation.
  for(const [id,object] of pending){
    if(Object.hasOwn(object,'children'))freezeOwned(object.children);
    objects[id]=cloneAndFreeze(object,undefined,'state.graphicSpec.objects.'+id);
  }
  return freezeOwned({graphicSpec:freezeOwned({objects:freezeOwned(objects),order:freezeOwned(['canvas'])})});
}

function snapshotSignature(scene) {
  const pending = [scene], seen = new WeakSet();
  while (pending.length) {
    const value = pending.pop();
    if (value === null || typeof value !== "object") continue;
    if (seen.has(value)) continue;
    seen.add(value);
    if (Array.isArray(value)) ownArray(value, "Canvas scene"); else ownRecord(value, "Canvas scene");
    pending.push(...Object.values(value));
  }
  return contentDigest(JSON.stringify(scene));
}

// One concrete compiler is shared by scene preparation and scene drawing.
// Caller-owned mutable frames reuse a prepared instance only while their exact
// content remains unchanged; changing any field creates a distinct graphicSpec.
export function canvasSceneProgram(scene) {
  const signature = isOwned(scene) ? undefined : snapshotSignature(scene);
  const previous = compiled.get(scene);
  if (previous !== undefined && previous.signature === signature) return previous.program;
  const program = cloneAndFreeze(compile(scene));
  compiled.set(scene, { signature, program });
  return program;
}
