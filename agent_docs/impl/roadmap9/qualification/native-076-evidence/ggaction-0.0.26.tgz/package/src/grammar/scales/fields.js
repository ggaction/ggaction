import { cloneAndFreeze, isOwned } from "../../core/immutable.js";

export function isNominalValue(value) {
  return (
    typeof value === "string" ||
    typeof value === "boolean" ||
    (typeof value === "number" && Number.isFinite(value))
  );
}

export function validateFieldType(fieldType) {
  if (!["quantitative", "ordinal", "temporal"].includes(fieldType)) {
    throw new Error(`Unsupported field type "${fieldType}".`);
  }
  return fieldType;
}

export function validateNominalFieldType(fieldType) {
  if (fieldType !== "nominal") {
    throw new Error(`Unsupported color field type "${fieldType}".`);
  }
  return fieldType;
}

export function validateCategoricalFieldType(fieldType) {
  if (!["nominal", "ordinal"].includes(fieldType)) {
    throw new Error(`Unsupported categorical field type "${fieldType}".`);
  }
  return fieldType;
}

export function validateSemanticFieldType(fieldType) {
  if (!["quantitative", "nominal", "ordinal", "temporal"].includes(fieldType)) {
    throw new Error(`Unsupported semantic field type "${fieldType}".`);
  }
  return fieldType;
}

function validateField(field) {
  if (typeof field !== "string" || field.length === 0) {
    throw new TypeError("Encoding field must be a non-empty string.");
  }
}

// An owned row array and its owned rows never change, so a completed column
// read is kept on the array itself and returned for the same field again.
class ColumnTarget { constructor(value) { return value; } }
class QuantitativeColumns extends ColumnTarget {
  #columns = new Map();
  static get(rows, field) { return #columns in rows ? rows.#columns.get(field) : undefined; }
  static set(rows, field, column) {
    if (!(#columns in rows)) { try { new QuantitativeColumns(rows); } catch { return column; } }
    rows.#columns.set(field, column);
    return column;
  }
}

export function readQuantitativeField(rows, field) {
  validateField(field);
  const known = isOwned(rows) ? QuantitativeColumns.get(rows, field) : undefined;
  if (known !== undefined) return known;
  const column = cloneAndFreeze(rows.map((row, index) => {
    if (!Object.hasOwn(row, field) || !Number.isFinite(row[field])) {
      throw new TypeError(
        `Field "${field}" must contain a finite number at row ${index}.`
      );
    }
    return row[field];
  }));
  // Every row must be owned too: an unowned row could change after the read.
  return isOwned(rows) && rows.every(isOwned) ? QuantitativeColumns.set(rows, field, column) : column;
}

function utcDate(year, month = 1, day = 1) {
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  const timestamp = date.getTime();
  if (!Number.isFinite(timestamp)) return undefined;
  return date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
    ? timestamp
    : undefined;
}

function parseTemporalString(value) {
  const isoDateTime =
    /^(\d{4})[-/](\d{2})[-/](\d{2})[T ](\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)(Z|[+-]\d{2}:?\d{2})?$/iu
      .exec(value);
  if (isoDateTime === null) return Date.parse(value);
  const [, year, month, day, time, zone] = isoDateTime;
  const normalized = `${year}-${month}-${day}T${time}${zone ?? "Z"}`;
  return Date.parse(normalized);
}

function validTimestamp(value) {
  return Number.isFinite(value) && Number.isFinite(new Date(value).getTime());
}

export function validateTemporalUnit(unit) {
  if (unit !== undefined && !["auto", "year", "timestamp"].includes(unit)) {
    throw new Error(`Unsupported temporalUnit "${unit}"; use auto, year, or timestamp.`);
  }
  return unit;
}

export function resolveTemporalUnit(options, fieldType, previous) {
  if (fieldType !== "temporal") {
    if (Object.hasOwn(options, "temporalUnit")) {
      throw new Error("temporalUnit requires a temporal fieldType.");
    }
    return undefined;
  }
  validateTemporalUnit(options.temporalUnit);
  const sameBinding = ["field", "datum"].some(key =>
    Object.hasOwn(options, key) && Object.hasOwn(previous ?? {}, key) &&
    options[key] === previous[key]);
  return options.temporalUnit ?? (sameBinding && previous?.fieldType === "temporal"
    ? previous.temporalUnit : undefined);
}

export function normalizeTemporalValue(value, field = "value", index = 0, temporalUnit = "auto") {
  validateTemporalUnit(temporalUnit);
  let timestamp;
  if (temporalUnit === "year") {
    const year = typeof value === "string" && /^\d{4}$/.test(value) ? Number(value) : value;
    if (Number.isInteger(year) && year >= 0 && year <= 9999) timestamp = utcDate(year);
  } else if (temporalUnit === "timestamp") {
    if (typeof value === "number") timestamp = value;
  } else if (typeof value === "number") {
    timestamp = Number.isInteger(value) && value >= 1000 && value <= 9999
      ? utcDate(value)
      : value;
  } else if (typeof value === "string") {
    const year = /^(\d{4})$/.exec(value);
    const date = /^(\d{4})[-/](\d{2})[-/](\d{2})$/.exec(value);
    timestamp = year !== null
      ? utcDate(Number(year[1]))
      : date !== null
        ? utcDate(Number(date[1]), Number(date[2]), Number(date[3]))
        : parseTemporalString(value);
  }
  if (!validTimestamp(timestamp)) {
    throw new TypeError(
      `Field "${field}" must contain a temporal string or finite timestamp ` +
      `(including a valid date or four-digit year) at row ${index}; temporalUnit is ${temporalUnit}.`
    );
  }
  return timestamp;
}

export function readTemporalField(rows, field, temporalUnit) {
  validateField(field);
  validateTemporalUnit(temporalUnit);
  return cloneAndFreeze(rows.map((row, index) => {
    if (!Object.hasOwn(row, field)) {
      throw new TypeError(
        `Field "${field}" must contain a temporal string or finite timestamp at row ${index}.`
      );
    }
    return normalizeTemporalValue(row[field], field, index, temporalUnit);
  }));
}

export function readNominalField(rows, field) {
  validateField(field);
  return cloneAndFreeze(rows.map((row, index) => {
    if (!Object.hasOwn(row, field) || !isNominalValue(row[field])) {
      throw new TypeError(
        `Field "${field}" must contain a nominal value at row ${index}.`
      );
    }
    return row[field];
  }));
}

export function readScaleField(rows, field, fieldType, { allowUnknown = false, temporalUnit } = {}) {
  validateSemanticFieldType(fieldType);
  validateTemporalUnit(temporalUnit);
  if (!allowUnknown) {
    if (fieldType === "temporal") return readTemporalField(rows, field, temporalUnit);
    if (["nominal", "ordinal"].includes(fieldType)) {
      return readNominalField(rows, field);
    }
    return readQuantitativeField(rows, field);
  }
  validateField(field);
  return cloneAndFreeze(rows.map((row, index) => {
    if (!Object.hasOwn(row, field)) return undefined;
    const value = row[field];
    if (fieldType === "quantitative") {
      return Number.isFinite(value) ? value : undefined;
    }
    if (["nominal", "ordinal"].includes(fieldType)) {
      return isNominalValue(value) ? value : undefined;
    }
    try {
      return normalizeTemporalValue(value, field, index, temporalUnit);
    } catch {
      return undefined;
    }
  }));
}
