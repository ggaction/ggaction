export { routeDensitySamples } from "./densitySamples.js";

const TAU = 2 * Math.PI;
export const DENSITY_EPSILON = 1e-9;

export function compactRouteKernel(distanceOverBandwidth) {
  const residual = Math.max(0, 1 - distanceOverBandwidth ** 2);
  return residual * residual;
}


export function directionChannels(angle) {
  const coordinate = ((angle % TAU + TAU) % TAU) * 8 / TAU, lower = Math.floor(coordinate), fraction = coordinate - lower;
  return fraction === 0 ? [[lower, 1]] : [[lower, 1 - fraction], [(lower + 1) % 8, fraction]];
}

// Trusted normalized samples and finite positive grid dimensions from the solver.
// Sparse cells are numerically identical to a zero-filled dense reference grid.
function densityField(sampleCount, bounds, { bandwidth, size, directed }, budget) {
  const cells = new Map(), dx = bounds.width / (size - 1), dy = bounds.height / (size - 1);
  budget.charge(sampleCount);
  const add = (sampleX, sampleY, weight, angle) => {
    if (weight === 0) return;
    if (!Number.isFinite(weight)) throw new RangeError("Route density must be finite.");
    const channels = directed ? directionChannels(angle) : [[0, 1]];
    const x0 = Math.max(0, Math.ceil((sampleX - bandwidth - bounds.x) / dx)), x1 = Math.min(size - 1, Math.floor((sampleX + bandwidth - bounds.x) / dx));
    const y0 = Math.max(0, Math.ceil((sampleY - bandwidth - bounds.y) / dy)), y1 = Math.min(size - 1, Math.floor((sampleY + bandwidth - bounds.y) / dy));
    for (let y = y0; y <= y1; y++) {
      const deltaY = bounds.y + y * dy - sampleY;
      // A row intersects the compact kernel in a circle chord. Keep one extra
      // column at either end so rounded boundary arithmetic cannot remove ink;
      // the original radial kernel still decides every retained contribution.
      const radius = Math.sqrt(Math.max(0, (bandwidth - Math.abs(deltaY)) * (bandwidth + Math.abs(deltaY))));
      const first = Math.max(x0, Math.ceil((sampleX - radius - bounds.x) / dx) - 1);
      const last = Math.min(x1, Math.floor((sampleX + radius - bounds.x) / dx) + 1);
      budget.charge(1 + Math.max(0, last - first + 1) * channels.length);
      for (let x = first; x <= last; x++) {
        const value = weight * compactRouteKernel(Math.hypot(bounds.x + x * dx - sampleX, deltaY) / bandwidth);
        if (value === 0) continue;
        for (const [channel, fraction] of channels) {
          // Stored densities are always finite numbers, so a missing value marks a new cell.
          const key = (channel * size + y) * size + x, prior = cells.get(key), next = (prior ?? 0) + value * fraction;
          if (!Number.isFinite(next)) throw new RangeError("Route density must be finite.");
          if (prior === undefined) budget.samples(sampleCount + cells.size + 1);
          cells.set(key, next);
        }
      }
    }
  };
  return { add, field: { cells, bounds: { ...bounds }, size, dx, dy, directed } };
}

export function createRouteDensityField(samples, bounds, options, budget) {
  const { add, field } = densityField(samples.length, bounds, options, budget);
  for (const sample of samples) add(sample.x, sample.y, sample.weight, sample.angle);
  return field;
}

export function createPackedRouteDensityField(routes, samples, bounds, options, budget) {
  const { add, field } = densityField(samples.count, bounds, options, budget);
  for (let edge = 0; edge < routes.length; edge++) {
    const offset = samples.offsets[edge], points = routes[edge];
    for (let index = 0; index < points.length; index++) {
      add(points[index].x, points[index].y, samples.weights[offset + index], samples.angles[offset + index]);
    }
  }
  return field;
}

export function routeDensityAt(field, x, y, angle = 0) {
  const { cells, size } = field;
  if (!field.directed) return cells.get(y * size + x) ?? 0;
  let result = 0;
  for (const [channel, weight] of directionChannels(angle)) for (let offset = -1; offset <= 1; offset++) {
    result += weight * (cells.get((((channel + offset + 8) % 8) * size + y) * size + x) ?? 0);
  }
  return result;
}

export function routeGridGradient(field, x, y, angle = 0) {
  const last = field.size - 1, left = Math.max(0, x - 1), right = Math.min(last, x + 1), lower = Math.max(0, y - 1), upper = Math.min(last, y + 1);
  return {
    x: (routeDensityAt(field, right, y, angle) - routeDensityAt(field, left, y, angle)) / ((right - left) * field.dx),
    y: (routeDensityAt(field, x, upper, angle) - routeDensityAt(field, x, lower, angle)) / ((upper - lower) * field.dy)
  };
}

export function sampleRouteGradient(field, point, angle) {
  const { bounds, size, dx, dy } = field;
  const gx = Math.max(0, Math.min(size - 1, (point.x - bounds.x) / dx)), gy = Math.max(0, Math.min(size - 1, (point.y - bounds.y) / dy));
  const x = Math.min(size - 2, Math.floor(gx)), y = Math.min(size - 2, Math.floor(gy)), u = gx - x, v = gy - y;
  const corners = [routeGridGradient(field, x, y, angle), routeGridGradient(field, x + 1, y, angle), routeGridGradient(field, x, y + 1, angle), routeGridGradient(field, x + 1, y + 1, angle)];
  const weights = [(1 - u) * (1 - v), u * (1 - v), (1 - u) * v, u * v];
  return { x: corners.reduce((sum, gradient, index) => sum + gradient.x * weights[index], 0), y: corners.reduce((sum, gradient, index) => sum + gradient.y * weights[index], 0) };
}

function advectRoute(points, angleAt, field, step) {
  const next = points.map((point, index) => {
    if (index === 0 || index === points.length - 1) return { ...point };
    const gradient = sampleRouteGradient(field, point, angleAt(index)), norm = Math.hypot(gradient.x, gradient.y);
    if (!Number.isFinite(norm)) throw new RangeError("Route density gradient must be finite.");
    if (norm <= DENSITY_EPSILON) return { ...point };
    const { bounds } = field;
    return { x: Math.max(bounds.x, Math.min(bounds.x + bounds.width, point.x + step * gradient.x / norm)), y: Math.max(bounds.y, Math.min(bounds.y + bounds.height, point.y + step * gradient.y / norm)) };
  });
  return next.map((point, index) => index === 0 || index === next.length - 1 ? point : {
    x: next[index - 1].x / 4 + point.x / 2 + next[index + 1].x / 4,
    y: next[index - 1].y / 4 + point.y / 2 + next[index + 1].y / 4
  });
}

export function advectDensityRoute(points, samples, field, step) {
  return advectRoute(points, index => samples[index].angle, field, step);
}

export function advectPackedDensityRoute(points, samples, edge, field, step) {
  const offset = samples.offsets[edge];
  return advectRoute(points, index => samples.angles[offset + index], field, step);
}
