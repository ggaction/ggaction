import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {evidenceHash,evidenceFile,evidenceSourceFile} from '../../scripts/verification-evidence.js';
const root=process.cwd(),base='agent_docs/impl/roadmap9/qualification/animation-graph-public-evidence';
const sourceCommit=execFileSync('git',['rev-parse','350b72e55'],{encoding:'utf8'}).trim();
const ref=path=>({path,sha256:evidenceHash(readFileSync(path))});
const sourceInputs=readFileSync('.artifacts/animation-graph-public/source-inputs.txt','utf8').trim().split('\n').map(ref);
for(const r of sourceInputs)evidenceSourceFile(root,sourceCommit,r);
const artifacts=readdirSync(base).filter(f=>f.endsWith('.gz')).sort().map(f=>ref(`${base}/${f}`));for(const r of artifacts)evidenceFile(root,r);
const archive=JSON.parse(readFileSync('.artifacts/animation-graph-public/package.json'));
const installs=[20,22,24].map(n=>JSON.parse(readFileSync(`.artifacts/animation-graph-public/installed-${n}.json`)));
const record={schemaVersion:1,status:'public-completed-graph-checkpoint',sourceCommit,approval:'agent_docs/impl/roadmap9/AUTHORIZATION.json#remainingApproval',sourceInputs,artifacts,
 scope:{addedPublicExports:0,entry:'ggaction/animation',typedFamily:'completed-graph',flatRetention:true,rendererReadyFrame:true},
 checks:{evidenceValidation:{passed:23,failed:0},cleanCanonical:{passed:213,failed:0,receipt:'source-canonical.receipt.json.gz'},coverage:{passed:163,failed:0,lines:100,branches:97.45,functions:100,floors:{lines:95,branches:90,functions:100},log:'public-graph-coverage.log.gz'},contracts:{passed:36,failed:0},render:{passed:7,failed:0,backends:['Canvas','SVG','PNG','PDF']},browser:{passed:2,failed:0,pixelRatios:[1,2]},packageContracts:{passed:29,failed:0},docs:{original:{passed:229,failed:2,total:231,reason:'Search data byte cap'},repair:{passed:31,failed:0},build:{status:'passed',ruby:'3.3.12',ciRuby:'3.2.6'},builtPages:186,builtMachineArtifacts:1598,browserWidths:[320,390,768],browserStatus:'passed',postSourceCanonicalGeneration:'passed-with-no-tracked-diff'}},
 package:{sha256:archive.sha256,entries:archive.entryCount,packedBytes:archive.size,unpackedBytes:archive.unpackedSize,artifact:archive.file,canonicalStageSourceAudit:{matchedFiles:1135,log:'archive-audit.log.gz',hashes:'archive-current-bytes.json.gz'},measurements:[20,22,24].map(n=>JSON.parse(readFileSync(`.artifacts/animation-graph-public/package-size-${n}.json`))),limits:{entries:1135,packedBytes:1621000,unpackedBytes:7344000}},
 installed:{archiveSha256:archive.sha256,runStatus:'original-command-failed-only-at-bundle-limits; runtime-and-types-passed',nodes:installs.map(i=>({node:i.node,zlib:i.zlib,runtimePassed:i.cases.length,runtimeFailed:0,types:i.types,peers:i.peers})),bundleRepair:{status:'passed',measurements:18,basis:'Same archive and original measured outputs; no rerun or relabeling of original failed commands',artifact:'bundle-requalification.json.gz'}},
 originalFailures:[
 {log:'public-merge-owning.log.gz',passed:157,failed:1,reason:'Test graph proof omitted new registerAnimationPlan precondition',repair:'Required setup added; graph cardinality assertion retained; later source213 passed'},
 {log:'public-graph-current-types.log.gz',passed:5,failed:1,reason:'New hit fixture expected markId instead of existing ownerId',repair:'Expectation corrected; runtime unchanged; later source213 passed'},
 {log:'docs-build.log.gz',reason:'System Ruby2.6 lacks required bundler2.4.19',repair:'Preflight and successful build with installed Ruby3.3.12'},
 {logs:['docs-built.log.gz','docs-browser.log.gz'],status:'invalidated',reason:'Commands after failed build saw old _site; not qualification evidence',repair:'Corrected build,built and full browser logs replace these'},
 {logs:['prepack-installed-20.log.gz','prepack-installed-22.log.gz','prepack-installed-24.log.gz'],reason:'Invoked helper before package manifest existed',repair:'Canonical archive created, then all three runtime/type/bundle runs executed'}],
 openObligations:['Remaining typed families including partition, Cartesian rule/rect/line/area, Geo/polar/guides','Offline frames do not yet carry native scoped hit metadata','Root final combined corpus and release qualification'],
 notClaimed:['Full installed consumer corpus','Whole repository coverage','STEP061-064 or Roadmap9 completion','Package publication or documentation deployment']};
writeFileSync(`${base}/qualification.json`,JSON.stringify(record,null,2)+'\n');
console.log(`Verified ${sourceInputs.length} exact committed sources and ${artifacts.length} durable artifacts.`);
