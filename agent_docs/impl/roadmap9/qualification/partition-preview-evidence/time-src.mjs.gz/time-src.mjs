const repo = process.argv[2];
const { chart } = await import(repo + '/src/index.js');
const { planTransition, sampleTransition } = await import(repo + '/src/animation.js');
for (const n of [1000, 10000]) {
  const input = [{ key: 'root', parent: null, value: 0 }, ...Array.from({ length: n - 1 }, (_, id) => ({ key: id, parent: 'root', value: 1 }))];
  const program = chart().createCanvas({ width: 400, height: 400, margin: 20, plotBorder: false }).createData({ id: 'rows', keyField: 'key', values: input }).createHierarchyData({ id: 'hierarchy', key: 'key', parent: 'parent', value: 'value' });
  const from = program.layoutHierarchy({ id: 'layout', method: 'partition' }).createPartitionPlot({ id: 'partition', labels: false, cells: { strokeWidth: 0 } }), to = from.editCanvas({ width: 600 });
  const plan = planTransition({ from, to, options: { durationMs: 100, easing: 'linear', ...(n >= 10000 ? { maxEndpointNodes: 2 * (n + 1), maxOutputNodes: n + 1 } : {}) } });
  const t = []; for (let i = 0; i < 35; i++) { const s = performance.now(); sampleTransition(plan, 50); t.push(performance.now() - s); }
  const m = t.slice(5).sort((a, b) => a - b); console.log(n, 'median', m[15].toFixed(1), 'p95', m[Math.ceil(.95 * 30) - 1].toFixed(1));
}
