from pathlib import Path
import gzip,hashlib,json,re,subprocess
b=Path('.artifacts/json-count-merged');d=Path('agent_docs/impl/roadmap9/qualification/json-count-merged-evidence');d.mkdir(exist_ok=True)
def sha(x):return hashlib.sha256(x).hexdigest()
checks={}
for n in ['coverage','owning-20','owning-24','boundaries']:
 s=(b/(n+'.log')).read_text();assert re.search(r'(?:#|ℹ) fail 0',s);checks[n]=int(re.search(r'(?:#|ℹ) tests (\d+)',s)[1])
sources={}
for f in ['src/core/jsonText.js','src/grammar/graph/inferenceBudget.js']:
 raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','f4b389117:'+f]);sources[f]=sha(raw)
critical={}
for f in ['jsonText.js','inferenceBudget.js']:
 m=re.search(r'\b'+re.escape(f)+r'\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)',(b/'coverage.log').read_text());v=list(map(float,m.groups()));assert v==[100,100,100];critical[f]=v
archive=json.loads((b/'frozen.json').read_text());consumers=[]
for v in [20,22,24]:
 r=json.loads((b/f'installed-{v}.json').read_text());assert r['sha256']==archive['sha256'] and len(r['checks'])==12 and all(x['status']=='passed' for x in r['checks']);assert r['types']=='passed' and r['snippet']['status']=='passed'
 if v==20:
  recheck=json.loads((b/'budget-recheck20.json').read_text());assert recheck['status']=='passed' and recheck['sha256']==archive['sha256'];r={**r,'finalBudgetRecheck':recheck}
 else:assert r['status']=='passed'
 consumers.append(r)
diff=json.loads((b/'compare.log').read_text());assert diff['comparisons']==868 and diff['getterCalls']==0
q={'status':'json-string-count-owner-integrated; async-responsiveness-and-final-closeout-pending','base':'9b87a0cfc','upstreamSource':'f4b389117b570ee6ae2399867dc709d6b04c457c','upstreamPin':'5ec4f4b40402521f902f643c9d49365b9658db52','approval':'../../AUTHORIZATION.json#remainingApproval','scope':'Single private JSON string byte-count owner and existing inference delegation. Exact UTF16/escape/minimum/final quota order preserved; generic encodeValue/canonicalJSON/hash/API/schema/guards unchanged.','sourceSHA256':sources,'archive':archive,'checks':checks,'critical':critical,'differential':diff,'consumers':consumers,'packMeasurements':{str(v):json.loads((b/f'pack{v}.json').read_text()) for v in [20,22,24]},'artifactPolicy':{'entries':1259,'packedBytes':1811800,'unpackedBytes':8152600,'graphGzip':69600,'actualPackedMax':1811708,'actualUnpacked':8152539,'actualGraphGzipMax':69506,'runtimeGuardChanges':0},'reusedEvidence':[{'path':'../../chart/json-string-count-evidence/qualification.json','boundary':'Two runtime files byte-exact. Root fresh36source/critical,all UTF16/hash12tests on Node20/24,868differential and same new archive12publiccases/type/doc/6bundle on three Nodes verify composition. Upstream small lifecycle source-specific evidence retained; no new100k/100ms/P95 claim.'},{'path':'../prepared-scale-merged-evidence/qualification.json','boundary':'Public docs/types and non-inference owners unchanged; reuse246docs/186built pages, fresh source pin runs nine doc contracts.'}],'initialFailuresRetained':['Node20 packed1811708 exceeded previous1811600; minimum ceiling1811800.','Node20 graph gzip69506 exceeded69500. Original receipt preserved; new69600 ceiling revalidated without repeating passing runtime. Node22/24 passed updated policy.'],'pending':['Strict resumable writer/native snapshot connection and external snapshot/BigInt/wide-record boundaries','Route bounded execution/native closure/original1k10k solver admission','Common sample50ms/partition/Geo camera and hit performance','Long-lived mixed WeakSet attribution/retained100cycle','Final9commands/independent review/STEP057-077 closeout'],'evidenceFiles':{}}
for p in sorted(b.iterdir()):
 if p.is_file() and p.suffix in ['.log','.json','.mjs','.py']:
  raw=p.read_bytes();(d/(p.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][p.name]={'sha256':sha(raw),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(checks,archive['sha256'])
