const repo = process.argv[2];
const { chart } = await import(repo + '/src/index.js');
const { planTransition, sampleTransition } = await import(repo + '/src/animation.js');
const n = 100000, side = Math.ceil(Math.sqrt(n));
const rows = Array.from({ length: n }, (_, id) => ({ id, x: (id % side + 1) / (side + 1), y: (Math.floor(id / side) + 1) / (side + 1) }));
const from = chart().createCanvas({ width: 400, height: 400, margin: 20, plotBorder: false }).createData({ id: 'rows', keyField: 'id', values: rows }).createPointMark({ id: 'points', maxItems: 100000 }).encodeX({ field: 'x', scale: { id: 'x', domain: [0, 1], nice: false } }).encodeY({ field: 'y', scale: { id: 'y', domain: [0, 1], nice: false } });
const to = from.editScale({ id: 'x', domain: [0, 2], nice: false });
for (const formatVersion of [6, undefined]) {
  const plan = planTransition({ from, to, options: { durationMs: 100, easing: 'linear', maxEndpointNodes: 200002, maxOutputNodes: 100001, ...(formatVersion ? { formatVersion } : {}) } });
  const t = []; for (let i = 0; i < 35; i++) { const s = performance.now(); sampleTransition(plan, 50 + (i % 7)); t.push(performance.now() - s); }
  const m = t.slice(5).sort((a, b) => a - b);
  console.log('format', formatVersion ?? 'v4', 'first', t[0].toFixed(1), 'median', m[15].toFixed(1), 'p95', m[28].toFixed(1), 'max', m[29].toFixed(1));
}
