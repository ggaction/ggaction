import {createHash} from 'node:crypto';
const hash=s=>createHash('sha256').update(s).digest('hex');
export async function load(url,context,next){const result=await next(url,context);if(result.format!=='module'||!url.includes('/src/'))return result;let s=result.source.toString(),o=s;
 if(url.endsWith('/grammar/hitIndex.js')){
  s=s.replace('export function prepareHitIndex(scene, entries) {', 'export function prepareHitIndex(scene, entries) { const diagnosticStart=globalThis.__hitDiagnostic?.indexWork??0;');
  s=s.replace('states.set(result, { scene, root, diagnostics: cloneAndFreeze(diagnostics) });', 'if(globalThis.__hitDiagnostic)(globalThis.__hitDiagnostic.indexCalls??=[]).push({work:work.value,entries:entries.length,nodes:scene.nodes.length,totalDelta:globalThis.__hitDiagnostic.indexWork-diagnosticStart});states.set(result, { scene, root, diagnostics: cloneAndFreeze(diagnostics) });');
  s=s.replace('work.value += count;',`work.value += count; const d=globalThis.__hitDiagnostic; if(d){d.indexWork+=count;d.indexStages[d.indexPhase]=(d.indexStages[d.indexPhase]??0)+count;if(work.value>work.limit&&d.indexLimit===null)d.indexLimit={value:work.value,phase:d.indexPhase,limit:work.limit};}`);
  s=s.replace('if (work.value > work.limit)', 'if (work.value > work.limit && !globalThis.__hitDiagnostic?.observe)');
  s=s.replaceAll('scene.nodes.length > MAX_HIT_INDEX_ITEMS','(scene.nodes.length > MAX_HIT_INDEX_ITEMS && !globalThis.__hitDiagnostic?.observe)');
  s=s.replace('function sceneKeys(scene, work) {','function sceneKeys(scene, work) { if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.indexPhase="sceneKeys";');
  s=s.replace('ownArray(entries, "Hit entries");','if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.indexPhase="entries";ownArray(entries, "Hit entries");');
  s=s.replace('function metadata(value, work) {','function metadata(value, work) { if(globalThis.__hitDiagnostic){globalThis.__hitDiagnostic.indexPhase="metadata";globalThis.__hitDiagnostic.metadataCalls++;}');
  s=s.replace('const semanticKey = JSON.stringify', 'if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.indexPhase="semanticSignature";const semanticKey = JSON.stringify');
  s=s.replace('const root = build(items, work)', 'if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.indexPhase="build";const root = build(items, work)');
  s=s.replace('export function compareHitText(a, b, work) {','export function compareHitText(a, b, work) { if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.comparisons++;');
  s=s.replace('spend(work, 2);','spend(work, 2);if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.comparedUnits+=2;');
  s=s.replace('spend(work);\n  return a.length', 'spend(work);if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.lengthComparisons++;\n  return a.length');
  s=s.replace('spend(work);\n      const x =', 'spend(work);if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.sortComparisons++;\n      const x =');
  s=s.replace('const root = {}, pending', 'const root = {}, pending');
  s=s.replace('function boundsOf(items, work) {', 'function boundsOf(items, work) {if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.boundsVisits+=items.length;');
 }
 if(url.endsWith('/interaction/hitProgram.js')){
  s=s.replace('budget.work += count;', `budget.work += count; const d=globalThis.__hitDiagnostic;if(d){d.programWork+=count;d.programStages[d.programPhase]=(d.programStages[d.programPhase]??0)+count;if(budget.work>MAX_HIT_INDEX_WORK&&d.programLimit===null)d.programLimit={value:budget.work,phase:d.programPhase,limit:MAX_HIT_INDEX_WORK};}`);
  s=s.replace('if (budget.work > MAX_HIT_INDEX_WORK)','if (budget.work > MAX_HIT_INDEX_WORK && !globalThis.__hitDiagnostic?.observe)');
  s=s.replace('if (count > MAX_HIT_INDEX_ITEMS)', 'if (count > MAX_HIT_INDEX_ITEMS && !globalThis.__hitDiagnostic?.observe)');
  s=s.replace('if (snapshot.scene.nodes.length > MAX_HIT_INDEX_ITEMS)', 'if (snapshot.scene.nodes.length > MAX_HIT_INDEX_ITEMS && !globalThis.__hitDiagnostic?.observe)');
  s=s.replace('const owners = contexts(program, budget);','if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.programPhase="contexts";const owners = contexts(program, budget);if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.programPhase="items";');
  s=s.replace('const snapshot = canvasSceneSnapshot(program);','const snapshot = canvasSceneSnapshot(program);if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.nativeSceneNodes=snapshot.scene.nodes.length;');
  s=s.replace('const shape = prepareConcreteHitShape(snapshot.scene.nodes[i]', 'const shape = prepareConcreteHitShape(snapshot.scene.nodes[i]');
  s=s.replace('spend(budget, hitShapeWork(shape));','if(globalThis.__hitDiagnostic)globalThis.__hitDiagnostic.shapeWork+=hitShapeWork(shape);spend(budget, hitShapeWork(shape));if(globalThis.__hitDiagnostic?.observe){const d=globalThis.__hitDiagnostic;d.nativeShapes=(d.nativeShapes??0)+1;if(d.nativeShapes%1000===0){globalThis.gc?.();process.stderr.write(JSON.stringify({nativeShapes:d.nativeShapes,programWork:d.programWork})+"\\n");}}');
 }
 if(url.endsWith('/interaction/sceneFrame.js'))s=s.replace('scene.nodes.length > MAX_HIT_INDEX_ITEMS', '(scene.nodes.length > MAX_HIT_INDEX_ITEMS && !globalThis.__hitDiagnostic?.observe)');
 if(s===o)return result;process.stderr.write(JSON.stringify({diagnosticOnly:url,original:hash(o),instrumented:hash(s)})+'\n');return {...result,source:s};}
