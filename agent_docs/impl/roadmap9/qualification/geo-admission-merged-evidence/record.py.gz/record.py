from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,re
b=Path('.artifacts/geo-admission-merged');d=Path('agent_docs/impl/roadmap9/qualification/geo-admission-merged-evidence');d.mkdir(exist_ok=True)
a=json.loads((b/'pack.json').read_text());p=Path('.artifacts/integration-archives')/('ggaction-'+a['sha256']+'.tgz');shutil.copyfile(a['file'],p);a['file']=str(p.resolve())
u=json.loads(Path('agent_docs/impl/roadmap9/qualification/geo-sample-admission-product-evidence/summary.json').read_text())
q={'schemaVersion':1,'status':'verified-Geo-sample-admission-integration','base':'c8bac0e77','upstream':'e4182d027','archive':a,'sourceHashes':{},'evidenceFiles':{},'checks':{'sameArchiveNodeVersions':[20,22,24],'strictTypes':True,'browserDPR':[1,2],'browserBundles':6},'upstreamOriginal100k':{'archiveSHA256':u['archive']['sha256'],'verified':u['checks']['original100kAllNativeCurrentRebaseCoordinatesAndQueries'],'scope':'Upstream installed archive. This integration does not claim a new original100k run.'},'remaining':['original workloads on final combined archive','exclusive canonical 5+30 performance','original canonical 100cycle lifetime','final roadmap qualification']}
for f,expected in u['sourceHashes'].items():
 raw=Path(f).read_bytes();assert raw==subprocess.check_output(['git','show','e4182d027:'+f]),f
 digest=hashlib.sha256(raw).hexdigest();assert digest==expected;q['sourceHashes'][f]=digest
r=json.loads((b/'installed.json').read_text());assert r['archiveSHA256']==a['sha256'] and len(r['records'])==13 and all(x['status']=='passed' for x in r['records'])
caps=json.loads((b/'caps.json').read_text())
for n in [20,22,24]:
 for row in r['bundles'+str(n)]:assert row['gzipBytes']<=caps[row['specifier']],row
for label in ['owning','boundaries','cap-docs']:
 s=(b/(label+'.log')).read_text();assert '# fail 0' in s;q['checks'][label]=int(re.search(r'# tests (\d+)',s)[1])
q['checks']['criticalCoverage']=json.loads((b/'critical-coverage.json').read_text())
for f in b.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.stderr','.py']:
  raw=f.read_bytes();(d/(f.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));q['evidenceFiles'][f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(d/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
Path('agent_docs/impl/roadmap9/qualification/geo-admission-merged.md').write_text(f'''# Geo sample admission 합산 검증

Sampler의 presentation/group 전체 검사를 완료한 뒤 같은 동기 호출 안에서만 검증된 geometry closure를 소비한다. Generic resolver와 offline admission은 기존 전체 검사를 수행한다. Native stream·refinement·출력 및 aggregate work, 오류 순서, caller isolation, 최종 concrete validation과 deep-owned 반환을 유지한다. Public API/schema, global cache, ownership registry는 변경하지 않았다.

[합산 증거](geo-admission-merged-evidence/qualification.json)는 세 runtime source가 upstream e4182d027과 byte-identical임을 검산한다. Owning {q['checks']['owning']}개 및 codec/package/discovery {q['checks']['boundaries']}개가 통과했다. 동일 canonical archive의 Node20/22/24 runtime·strict types·실행 문서·6bundles와 source-free minified Chromium DPR1/2도 통과했다. Critical owner coverage와 정확한 package/bundle 실측값은 증거 JSON에 보존한다.

Archive SHA256 `{a['sha256']}`는 {a['entryCount']}entries/{a['packedBytes']}packed/{a['unpackedBytes']}unpacked bytes다. Node24 측정값에 맞춰 artifact ceiling만 정합했으며 원 runtime work/guard·fixture·SLO는 유지한다.

Upstream archive `{u['archive']['sha256']}`의 원100k native/current/rebase 각199999commands 및 전체footprint/scalar질의, offline 권한 거부를 재사용한다. 동일 source의 증거이지만 합산 archive에서 새 원100k를 실행했다는 뜻은 아니다. 상세 내용은 [upstream 구현 기록](GEO_SAMPLE_ADMISSION_IMPLEMENTATION.md)이 소유한다.

최종 합산본의 원 workload, 단독 CPU canonical5+30/DPR1·2 성능, 원 canonical100cycle lifetime은 후속 검증이다. Small sampler100cycle을 원 lifetime 자격으로 대체하지 않는다. STEP057–070/077은 미완료다.
''')
f=Path('agent_docs/impl/roadmap9/ROADMAP.md');s=f.read_text();needle='2026-11-01 현재 개별 차트 구현';i=s.index(needle);s=s[:i]+'Geo sampler의 같은 호출 내부에서 full-admitted geometry 계산을 재사용했다([합산 owning·3Node/browser](qualification/geo-admission-merged.md)). 원 검증·수학·work를 유지하고 최종 합산 성능/lifetime 자격은 남는다.\n\n'+s[i:];f.write_text(s)
print(q['checks'],a['sha256'])
