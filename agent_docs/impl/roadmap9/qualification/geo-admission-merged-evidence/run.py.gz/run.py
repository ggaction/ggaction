from pathlib import Path
import subprocess,json,os,shutil
base=Path('.artifacts/geo-admission-merged')
node='/opt/homebrew/Cellar/node@22/22.23.1/bin/node'
env=dict(os.environ,npm_execpath='/opt/homebrew/Cellar/node@22/22.23.1/lib/node_modules/npm/bin/npm-cli.js')
def run(label,args):
 print('START',label,flush=True)
 with (base/(label+'.log')).open('wb') as f: subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,env=env)
 print('PASS',label,flush=True)
files=sorted(str(p) for p in Path('test/unit/animation').glob('geo-*.test.js'))
run('owning',[node,'--experimental-test-coverage','--test','--test-concurrency=1',*files])
run('boundaries',[node,'scripts/run-tests.js','all',*[f'test/unit/animation/{name}.test.js' for name in ['column-codec','numeric-columns','numeric-format','numeric-geographic-transport','legacy-geographic-transport','envelope-codec']],*[f'test/contracts/{name}.test.js' for name in ['package-boundaries','test-discovery','geo-label-boundaries','package-artifact']]])
with (base/'pack.json').open('wb') as out,(base/'pack.stderr').open('wb') as err:
 subprocess.run([node,'agent_docs/impl/roadmap9/integration/geographic-route-merged-evidence/pack.mjs',str((base/'pack').resolve())],env=env,stdout=out,stderr=err,check=True)
shutil.copyfile(base/'pack.json','.artifacts/geo-hit-a3/archive.json')
run('installed',[node,'.artifacts/geo-hit-a3/installed.mjs'])
shutil.copyfile('.artifacts/geo-hit-a3/installed.json',base/'installed.json')
shutil.copyfile('.artifacts/geo-hit-a3/consumer.json',base/'consumer.json')
print('READY_FOR_CAPS_AND_DOCS',flush=True)
