import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {chart} from '../src/index.js';
import {chart as basic} from '../src/basic.js';
import {withoutAllocatedIdentity} from '../test/support/identity-equivalence.js';
const records=[];
for(const [factoryName,factory] of [['Full',chart],['Basic',basic]])for(const position of ['top','bottom','left','right']){
 const source=factory().createCanvas({width:1300,height:1100,margin:300}).createData({values:[{id:1,x:0,y:0,g:'A'},{id:'1',x:2,y:2,g:'B'}],keyField:'id'}).createScatterPlot({id:'points',x:'x',y:'y',color:'g',guides:false});
 const channel=['top','bottom'].includes(position)?'X':'Y';
 const created=source[`create${channel}Axis`]({position,line:{},ticksAndLabels:{values:[0,1,2],labels:{fontSize:10,offset:7}},title:{text:'Axis',fontSize:11,offset:35}}).createLegend({position,title:'Legend'});
 const edited=created[`edit${channel}AxisTitle`]({offset:50});
 const phases=[['created',created],['edited',edited]];
 if(factoryName==='Full')phases.push(['removed',edited[`remove${channel}Axis`]()]);
 for(const [phase,p] of phases){
  const value=withoutAllocatedIdentity({semanticSpec:p.semanticSpec,graphicSpec:p.graphicSpec,guideConfigs:p.guideConfigs,trace:p.trace});
  records.push({factory:factoryName,position,phase,sha256:createHash('sha256').update(JSON.stringify(value)).digest('hex')});
 }
}
await writeFile(process.argv[2],JSON.stringify(records,null,2)+'\n');console.log(records.length);
