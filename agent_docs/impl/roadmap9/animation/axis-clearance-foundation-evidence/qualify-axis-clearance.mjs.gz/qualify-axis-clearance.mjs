import {testOptionalDependencies} from '../scripts/consumers/optional-peers.js';
import {createHash} from 'node:crypto';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../scripts/browser-bundle-size.js';
import {run,root} from '../scripts/consumers/runtime.js';
import {writeFile,copyFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const file=path.resolve('.artifacts/release/ggaction-0.0.26.tgz');
const bytes=await readFile(file),pack={file,sha256:createHash('sha256').update(bytes).digest('hex'),entryCount:1192,size:bytes.length,unpackedSize:7721116};
const consumer=await preparePackageConsumer({packageSpec:file});
const receipt={node:process.version,archive:pack.sha256,package:{entries:pack.entryCount,packed:pack.size,unpacked:pack.unpackedSize},bundles:[],runtime:0};
try{
 await testOptionalDependencies(consumer);
 await copyFile(path.join(root,'scripts/consumers/fixtures/node/animation.mjs'),path.join(consumer.directory,'animation.mjs'));
 await writeFile(path.join(consumer.directory,'identity-equivalence.js'),(await readFile(path.join(root,'test/support/identity-equivalence.js'),'utf8')).replace('../../src/renderers/svg.js','ggaction/svg'));
 await writeFile(path.join(consumer.directory,'run.mjs'),`import {cases} from './animation.mjs';await cases.find(e=>e.id==='animation/implicit-legend-lanes-offline-native').run();`);
 await run(process.execPath,['run.mjs'],consumer.directory);receipt.runtime=1;
 for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)) receipt.bundles.push({specifier,...await measureMinimalBrowserBundle(consumer.directory,{specifier})});
 receipt.limitFailures=receipt.bundles.filter(m=>m.gzipBytes>BROWSER_BUNDLE_GZIP_LIMITS[m.specifier]);
 await writeFile('.artifacts/axis-clearance-installed-node20.json',JSON.stringify(receipt,null,2)+'\n');
 assert.deepEqual(receipt.limitFailures,[]);
}finally{await consumer.cleanup();}
