import {readFile} from 'node:fs/promises';
const target=new URL('../src/materialization/guides/resources.js',import.meta.url).href;
export async function load(url,context,next){
 if(url===target)return {format:'module',source:await readFile(new URL('./axis-clearance-before-resources.js',import.meta.url),'utf8'),shortCircuit:true};
 return next(url,context);
}
