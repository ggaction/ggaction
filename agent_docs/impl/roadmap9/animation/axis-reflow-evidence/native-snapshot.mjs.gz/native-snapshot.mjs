import fs from 'node:fs';
import { chart } from '../../src/index.js';
import { chart as basic } from '../../src/basic.js';
import { getErrorDetails } from '../../src/core/diagnostics.js';
const results=[];
function save(name,run){try{const p=run();results.push({name,guideConfigs:p.guideConfigs,materializationConfigs:p.materializationConfigs,graphicSpec:p.graphicSpec,trace:p.trace});}catch(e){results.push({name,error:e.message,details:getErrorDetails(e)});}}
for(const [family,make] of [['full',chart],['basic',basic]]){
const numeric=()=>make().createCanvas({width:400,height:300,margin:70}).createData({id:'data',values:[{x:0,y:0},{x:10,y:10}]}).createPointMark({id:'p'}).encodeX({field:'x'}).encodeY({field:'y'});
for(const [name,options] of Object.entries({plain:{},wrap:{labelMap:[{value:0,label:'Alpha Beta Gamma'},{value:10,label:'Delta Epsilon'}],maxWidth:40},hidden:{labelMap:[{value:0,label:''},{value:10,label:''}]},flush:{flush:true,alongOffset:4},rotation:{rotation:-Math.PI/4},mirrored:{position:'top'}})) save(`${family}/${name}`,()=>{const p=numeric().createXAxisLabels({values:[0,10],...options});return family==='full'?p.editCanvas({width:500}):p;});
save(`${family}/y`,()=>numeric().createYAxisLabels({values:[0,10],position:'right',maxWidth:30,labelMap:[{value:0,label:'A B C'},{value:10,label:'D E F'}]}));
for(const width of [800,400,220,100])save(`${family}/responsive/${width}`,()=>make().createCanvas({width,height:600,margin:10,responsive:{minPlotSize:{width:40,height:40}}}).createData({values:Array.from({length:8},(_,i)=>({x:`Long category ${i}`,y:i+1}))}).createBarPlot({x:'x',y:'y',guides:{axes:{x:{title:false,ticksAndLabels:{labels:{responsive:{maxLines:1},maxWidth:300}}},y:{title:false}},legend:false}}));
save(`${family}/overflow`,()=>numeric().createXAxisLabels({position:'top',offset:100}));
save(`${family}/overlap`,()=>numeric().createXAxisLabels({values:[0,0.01],labelMap:[{value:0,label:'Long label zero'},{value:0.01,label:'Long label one'}]}));
}
fs.writeFileSync(process.argv[2],JSON.stringify(results));
console.log(JSON.stringify({cases:results.length,success:results.filter(x=>!x.error).length,errors:results.filter(x=>x.error).map(x=>[x.name,x.error])}));
