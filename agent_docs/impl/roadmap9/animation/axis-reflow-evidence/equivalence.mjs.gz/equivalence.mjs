import fs from 'node:fs';
import assert from 'node:assert/strict';
const before=JSON.parse(fs.readFileSync('.artifacts/axis-reflow/native-before.json'));
const after=JSON.parse(fs.readFileSync('.artifacts/axis-reflow/native-after.json'));
for(let i=0;i<before.length;i++){
 for(const k of ['name','guideConfigs','materializationConfigs','trace','error','details'])assert.deepEqual(before[i][k],after[i][k],`${i}/${k}`);
 if(before[i].graphicSpec){const x=before[i].graphicSpec,y=after[i].graphicSpec;for(const k of Object.keys(x.objects)){
   if(x.objects[k].items?.some(v=>v.identity))assert.deepEqual(x.objects[k].items.map(v=>v.properties),y.objects[k].items.map(v=>v.properties));
   else assert.deepEqual(x.objects[k],y.objects[k],`${i}/graphic/${k}`);
 }}
}
console.log(JSON.stringify({cases:before.length,success:before.filter(x=>!x.error).length,failures:before.filter(x=>x.error).length,equal:true,excluded:'generated mark identity UUIDs and derived identity IDs from independent program creation'}));
