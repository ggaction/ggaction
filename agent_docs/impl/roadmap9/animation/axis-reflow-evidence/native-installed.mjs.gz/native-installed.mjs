import { preparePackageConsumer } from '../../scripts/package-consumer.js';
import { testOptionalDependencies } from '../../scripts/consumers/optional-peers.js';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const archive=path.resolve('.artifacts/release/ggaction-0.0.26.tgz');
const consumer=await preparePackageConsumer({packageSpec:archive});
try{
await testOptionalDependencies(consumer);
await writeFile(path.join(consumer.directory,'responsive-guides.mjs'),await readFile('scripts/consumers/fixtures/node/responsive-guides.mjs'));
await writeFile(path.join(consumer.directory,'responsive-public.js'),(await readFile('examples/responsive-guides/program.js','utf8')).replace('"../../src/index.js"','"ggaction"'));
await writeFile(path.join(consumer.directory,'runner.mjs'),`import {cases} from './responsive-guides.mjs';for(const entry of cases){await entry.run();console.log(entry.id+' passed');}`);
process.stdout.write(execFileSync(process.execPath,['runner.mjs'],{cwd:consumer.directory,encoding:'utf8',timeout:120000}));
console.log(JSON.stringify({node:process.version,archive,cases:2}));
}finally{await consumer.cleanup();}
