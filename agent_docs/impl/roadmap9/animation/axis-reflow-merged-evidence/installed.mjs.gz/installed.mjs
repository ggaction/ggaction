import { preparePackageConsumer } from '../../scripts/package-consumer.js';
import { testOptionalDependencies } from '../../scripts/consumers/optional-peers.js';
import { BROWSER_BUNDLE_GZIP_LIMITS, measureMinimalBrowserBundle } from '../../scripts/browser-bundle-size.js';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const archive=JSON.parse(await readFile(process.argv[2],'utf8')).file;
const consumer=await preparePackageConsumer({packageSpec:archive});
const receipt={node:process.version,archive,sha256:createHash('sha256').update(await readFile(archive)).digest('hex'),bundles:[]};
try {
await testOptionalDependencies(consumer);
await writeFile(path.join(consumer.directory,'animation-axis-reflow.mjs'),await readFile('scripts/consumers/fixtures/node/animation-axis-reflow.mjs'));
await writeFile(path.join(consumer.directory,'runner.mjs'),`import{cases}from'./animation-axis-reflow.mjs';for(const entry of cases){await entry.run();console.log(entry.id+' passed');}`);
process.stdout.write(execFileSync(process.execPath,['runner.mjs'],{cwd:consumer.directory,encoding:'utf8',timeout:180000}));
receipt.runtimeCases=3;
const types=(await readFile('test/contracts/animation-types.test.js','utf8')).split('await writeFile(file,`')[1].split('`);')[0]
 .replaceAll('${JSON.stringify(path.join(root,\'types/index.js\'))}',"'ggaction'")
 .replaceAll('${JSON.stringify(path.join(root,\'types/basic.js\'))}',"'ggaction/basic'")
 .replaceAll('${JSON.stringify(path.join(root,\'types/animation.js\'))}',"'ggaction/animation'")
 .replaceAll('${JSON.stringify(path.join(root,\'types/svg.js\'))}',"'ggaction/svg'")
 .replaceAll('${JSON.stringify(path.join(root,\'types/png.js\'))}',"'ggaction/png'")
 .replaceAll('${JSON.stringify(path.join(root,\'types/pdf.js\'))}',"'ggaction/pdf'");
await writeFile(path.join(consumer.directory,'animation.mts'),types);
process.stdout.write(execFileSync(process.execPath,[path.resolve('node_modules/typescript/bin/tsc'),'--noEmit','--strict','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','animation.mts'],{cwd:consumer.directory,encoding:'utf8',timeout:120000}));
receipt.strictTypes=true;
const snippet=(await readFile('docs/api/animation.md','utf8')).split('```javascript\n')[1].split('```')[0];
await writeFile(path.join(consumer.directory,'doc.mjs'),snippet);
const docOutput=execFileSync(process.execPath,['doc.mjs'],{cwd:consumer.directory,encoding:'utf8',timeout:120000});
if(!docOutput.includes('<svg'))throw Error('Public documentation did not produce SVG');receipt.documentationSnippets=1;
for(const specifier of Object.keys(BROWSER_BUNDLE_GZIP_LIMITS)) {
 const value=await measureMinimalBrowserBundle(consumer.directory,{specifier});
 receipt.bundles.push({...value,limit:BROWSER_BUNDLE_GZIP_LIMITS[specifier],pass:value.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier]});
}
await writeFile(process.argv[3],JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
if(receipt.bundles.some(b=>!b.pass))throw Error('Measured bundle exceeds its recorded cap');
} finally { await consumer.cleanup(); }
