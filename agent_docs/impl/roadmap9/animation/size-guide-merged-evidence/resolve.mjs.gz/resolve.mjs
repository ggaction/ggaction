import fs from'node:fs';import{execFileSync}from'node:child_process';
const stage=(n,f)=>execFileSync('git',['show',`:${n}:${f}`],{encoding:'utf8',maxBuffer:30e6});
const write=(f,s)=>fs.writeFileSync(f,s);
const conflicts=execFileSync('git',['diff','--name-only','--diff-filter=U'],{encoding:'utf8'}).trim().split('\n');
for(const f of conflicts.filter(f=>f.startsWith('docs/')&&!f.endsWith('snippet_cases.json')))write(f,stage(2,f));
for(const f of conflicts.filter(f=>f.startsWith('agent_docs/impl/roadmap9/animation/axis-label-evidence/')))write(f,stage(3,f));
write('scripts/package-artifact.js',stage(2,'scripts/package-artifact.js'));
write('scripts/browser-bundle-size.js',stage(2,'scripts/browser-bundle-size.js').replace('129_600 // Geographic resources and edge presentation: Node20 129,579 gzip bytes.','131_400 // Prior size-guide ceiling; combined archive must be measured.'));
let endpoint=stage(2,'src/animation/frameEndpoint.js');const from='decision.kernel==="guide-geometry"?!["line","path","text","rect"]';if(!endpoint.includes(from))throw Error('Missing guide seam');write('src/animation/frameEndpoint.js',endpoint.replace(from,from.slice(0,-1)+',"circle"]'));
const split=(text,choose)=>text.replace(/^<<<<<<<[^\n]*\n([\s\S]*?)^=======\n([\s\S]*?)^>>>>>>>[^\n]*\n/gm,(_,a,b)=>choose(a,b));
write('scripts/consumers/fixtures/node/animation.mjs',split(fs.readFileSync('scripts/consumers/fixtures/node/animation.mjs','utf8'),(_,b)=>b));
const snippets=JSON.parse(stage(2,'docs/_data/snippet_cases.json')),ids=new Set(snippets.map(v=>v.id));for(const value of JSON.parse(stage(3,'docs/_data/snippet_cases.json')))if(!ids.has(value.id)){snippets.push(value);ids.add(value.id);}write('docs/_data/snippet_cases.json',JSON.stringify(snippets,null,2)+'\n');
const timingFile='test/realistic-timings.json',timing=JSON.parse(stage(2,timingFile)),incoming=JSON.parse(stage(3,timingFile)),key='contracts/realistic-guide-transitions.test.js';for(const part of Object.keys(incoming))if(incoming[part]&&typeof incoming[part]==='object'&&Object.hasOwn(incoming[part],key))timing[part][key]=incoming[part][key];write(timingFile,JSON.stringify(timing,null,2)+'\n');
const architecture='agent_docs/SECOND_ARCHITECTURE.md';let index=0;const arch=split(fs.readFileSync(architecture,'utf8'),(a,b)=>index++===0?a:a+b).replace('| `ggaction/interaction` | 129,600 bytes |','| `ggaction/interaction` | 131,400 bytes |');write(architecture,arch);
for(const f of conflicts){if(/^<<<<<<<|^=======|^>>>>>>>/m.test(fs.readFileSync(f,'utf8')))throw Error('Unresolved '+f);}
console.log(JSON.stringify({resolved:conflicts.length,sharedSource:'root Cartesian circle plus native guide circle',generated:'regenerate next',budgets:'retain previous maximums until fresh combined measurement'}));
