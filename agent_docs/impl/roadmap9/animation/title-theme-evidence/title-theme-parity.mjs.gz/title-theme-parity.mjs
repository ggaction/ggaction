import { chart } from '../src/index.js';
import { chart as basic } from '../src/basic.js';
import { writeFileSync } from 'node:fs';
const results=[];
for (const create of [chart,basic]) for (const theme of ['light','dark',{base:'dark',tokens:{axisTitleGap:33,axisLabelGap:8}}]) {
 const base=create().createCanvas({width:700,height:500,margin:120}).createData({values:[{x:0,y:0},{x:10,y:10}]}).createPointMark().encodeX({field:'x'}).encodeY({field:'y'});
 for (const p of [base.applyTheme({theme}).createXAxis({title:{text:'Measure'}}),base.createXAxis({title:{text:'Measure'}}).applyTheme({theme})])
 results.push({guides:p.guideConfigs,graphics:p.graphicSpec,theme:p.materializationConfigs.theme,trace:p.trace});
}
for (const theme of [{base:'bad',tokens:{}},{base:'dark',tokens:{axisTitleGap:-1}},{base:'dark',tokens:{unknown:1}},{base:'dark'}]) {
 try {chart().applyTheme({theme});} catch(error) {results.push([error.constructor.name,error.message]);}
}
writeFileSync(process.argv[2],JSON.stringify(results));
