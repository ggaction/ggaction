import {collectTestFiles,testRunnerArguments} from '../../scripts/run-tests.js';
import {execFileSync} from 'node:child_process';
const files=collectTestFiles('unit',undefined,['unit/actions/guides/','unit/animation/categorical-legend-transitions.test.js','unit/animation/legend-transitions.test.js','unit/animation/size-legend-transitions.test.js']);
if(!files.length)throw Error('No owning files');
const owners=['src/grammar/legendSymbolRecipe.js','src/materialization/guides/categoricalLegend.js','src/materialization/animation/categoricalLegendState.js'];
console.log(JSON.stringify({files:files.length,owners,scope:'Focused owner coverage only; not whole-repository coverage'}));
execFileSync(process.execPath,['--experimental-test-coverage',...owners.map(p=>'--test-coverage-include='+p),...testRunnerArguments('unit',files)],{stdio:'inherit'});
