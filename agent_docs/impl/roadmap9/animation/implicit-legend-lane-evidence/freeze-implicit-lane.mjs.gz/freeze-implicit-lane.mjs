import {createPackageArtifact, compactPackageJavaScript} from '../scripts/package-artifact.js';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const pack=await createPackageArtifact();
const file=`.artifacts/animation-archives/ggaction-implicit-lane-final-${pack.sha256}.tgz`;
await copyFile(pack.file,file);
await writeFile('.artifacts/implicit-lane-final-frozen-pack.json',JSON.stringify({...pack,file},null,2)+'\n');
const owner=await readFile('scripts/package-artifact.js','utf8');
const compact=new Set([...owner.match(/const COMPACT_JAVASCRIPT_FILES = Object.freeze\(\[([\s\S]*?)\]\)/)[1].matchAll(/"([^"]+)"/g)].map(x=>x[1]));
const hashes={};for(const {path} of pack.files){if(!path.startsWith('src/')&&!path.startsWith('types/')&&!['package.json','README.md'].includes(path))continue;let bytes=await readFile(path);if(compact.has(path))bytes=Buffer.from(compactPackageJavaScript(bytes.toString(),{keepNames:false}));hashes[path]=createHash('sha256').update(bytes).digest('hex');}
await writeFile('.artifacts/implicit-lane-final-expected-packed-hashes.json',JSON.stringify(hashes,null,2)+'\n');
console.log(JSON.stringify({file,sha256:pack.sha256,size:pack.size,unpackedSize:pack.unpackedSize,entries:pack.entryCount}));
