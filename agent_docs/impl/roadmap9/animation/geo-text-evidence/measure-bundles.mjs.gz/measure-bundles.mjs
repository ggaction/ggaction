import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { measureMinimalBrowserBundle } from '../../scripts/browser-bundle-size.js';
const output=[];
for(const specifier of ['ggaction','ggaction/basic','ggaction/svg','ggaction/graph','ggaction/interaction','ggaction/animation']) output.push(await measureMinimalBrowserBundle(path.resolve('.artifacts/animation-geo-text/bundle-source-'+process.versions.node.split('.')[0]),{specifier}));
const data={node:process.version,zlib:process.versions.zlib,scope:'current-source-not-installed',entries:output};
await writeFile('.artifacts/animation-geo-text/bundles-'+process.versions.node.split('.')[0]+'.json',JSON.stringify(data,null,2));console.log(data);
