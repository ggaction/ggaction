import {spawnSync} from 'node:child_process';import fs from 'node:fs';
import {collectTestFiles} from '../../scripts/run-tests.js';import {assertCriticalCoverage,CRITICAL_COVERAGE_FLOORS,parseCoverageTable} from '../../scripts/coverage-policy.js';
const selected=['unit/animation','unit/grammar/native-position-placement','unit/actions/marks/linked-overlay','unit/actions/marks/linked-overlay-rematerialization','unit/actions/conditional-overlay','unit/actions/charts/density-plot','unit/actions/charts/raincloud-facade','unit/actions/charts/violin-plot-facade','unit/grammar/categorical-density','unit/actions/marks/create-rule-mark','unit/actions/encodings/rule-position-encodings','unit/actions/marks/density-area'];
const files=collectTestFiles('unit',undefined,selected.map(value=>value==='unit/animation'?value:value+'.test.js'));
const included=['src/grammar/animation/cartesian*.js','src/materialization/animation/cartesian*.js','src/grammar/positionOffset.js','src/grammar/ruleGeometry.js','src/grammar/densityAreaPath.js','src/grammar/categoricalDensity.js'];
const result=spawnSync(process.execPath,['--max-old-space-size=512','--test','--test-concurrency=2','--experimental-test-coverage',...included.map(p=>'--test-coverage-include='+p),...files],{encoding:'utf8',maxBuffer:32*1024*1024});
const output=result.stdout+result.stderr;fs.writeFileSync('.artifacts/cartesian-completion/coverage.log',output);console.log(output.slice(-25000));
fs.writeFileSync('.artifacts/cartesian-completion/coverage.json',JSON.stringify(Object.fromEntries(parseCoverageTable(output)),null,2));
if(result.status!==0)process.exitCode=result.status??1;
else {const floors=Object.fromEntries(Object.entries(CRITICAL_COVERAGE_FLOORS).filter(([p])=>/^(?:(grammar|materialization)\/animation\/cartesian|grammar\/(positionOffset|ruleGeometry|densityAreaPath)\.js)/.test(p)));assertCriticalCoverage(output,floors);console.log('Cartesian critical floors passed: '+Object.keys(floors).length);}
