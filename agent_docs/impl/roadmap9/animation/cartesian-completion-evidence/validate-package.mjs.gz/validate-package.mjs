import fs from 'node:fs/promises';import {inspectPackageArtifact} from '../../scripts/package-artifact.js';
process.env.npm_execpath='/opt/homebrew/lib/node_modules/npm/bin/npm-cli.js';
const p=inspectPackageArtifact(),result={node:process.version,zlib:process.versions.zlib,entries:p.entryCount,packedBytes:p.size,unpackedBytes:p.unpackedSize};
await fs.writeFile('.artifacts/cartesian-completion/package-validated-'+process.versions.node.split('.')[0]+'.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
