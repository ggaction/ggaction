import {cartesianCompletionVariants,cartesianCompletionFrame}from'../../test/support/animation-cartesian-completion.js';
import{render}from'../../src/renderers/canvas/index.js';import{createCanvas}from'@napi-rs/canvas';
for(const variant of cartesianCompletionVariants){try{const {frame,checks,plan}=cartesianCompletionFrame(variant),c=createCanvas(1,1);render(frame,c.getContext('2d'));console.log(variant,plan.tracks.map(x=>[x.kind,x.reason]),checks.map(x=>[...c.getContext('2d').getImageData(...x.point,1,1).data]));}catch(e){console.log(variant,e.stack)}}
