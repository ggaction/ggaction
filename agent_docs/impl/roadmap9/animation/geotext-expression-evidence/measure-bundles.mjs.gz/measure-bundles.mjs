import fs from 'node:fs/promises';import path from 'node:path';import {measureMinimalBrowserBundle} from '../../scripts/browser-bundle-size.js';
const values={node:process.version,zlib:process.versions.zlib,bundles:{}};
for(const specifier of ['ggaction','ggaction/basic','ggaction/svg','ggaction/interaction','ggaction/graph','ggaction/animation']) values.bundles[specifier]=await measureMinimalBrowserBundle(path.resolve('.artifacts/geotext-expressions/bundle-source'),{specifier});
await fs.writeFile('.artifacts/geotext-expressions/source-bundles-'+process.versions.node.split('.')[0]+'.json',JSON.stringify(values,null,2));console.log(JSON.stringify(values));
