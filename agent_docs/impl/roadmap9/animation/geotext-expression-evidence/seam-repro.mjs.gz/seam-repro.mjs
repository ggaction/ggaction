import {chart} from '../../src/index.js';
import {planTransition,sampleTransition,serializeAnimation,deserializeAnimation} from '../../src/animation.js';
import {projectAnimationEndpoint} from '../../src/animation/endpoints.js';
import {projectGeoAnimationPresentations} from '../../src/materialization/animation/geoPresentation.js';
import {projectGeoTextAnimations} from '../../src/materialization/animation/geoText.js';
import {prepareGeoTextTracks,sampleGeoTextTracks} from '../../src/animation/geoTextTracks.js';
import {geoTextFrameCollector} from '../../src/animation/geoTextFrames.js';
const base=chart().createCanvas({width:400,height:300,margin:0}).createGeometryData({id:'places',format:'geojson',coordinateKind:'planar',featureKey:'id',values:{type:'FeatureCollection',features:[{type:'Feature',id:'a',properties:{name:'Old'},geometry:{type:'Point',coordinates:[40,50]}},{type:'Feature',id:'b',properties:{name:'Second'},geometry:{type:'Point',coordinates:[40,50]}}]}}).createProjection({id:'map',type:'identity'}).createCoordinate({type:'geo'}).createGeoPointMark({id:'places-mark'}).createMarkLabels({field:'name',dx:20}).layoutLabels({target:'places-mark-labels',leader:{}});
const next=base.editTextMark({target:'places-mark-labels',textOverrides:[{match:{fields:{name:'Old'}},occurrence:0,text:'New'}]}).removeLabelLayout({target:'places-mark-labels'}).editProjection({scalePx:4});
const state=p=>{const e=projectAnimationEndpoint(p);return projectGeoTextAnimations(p,e,projectGeoAnimationPresentations(p,e));};
const a=state(base),b=state(next),prepared=prepareGeoTextTracks(a,b),samples=sampleGeoTextTracks(prepared.state,.5);
console.log(JSON.stringify({sourceLeader:a.groups[0].leaderInsertion,targetLeader:b.groups[0].leaderInsertion,samples:samples.map(s=>({expressions:s.presentation.expressions.length,labels:s.graphics.labels.map(g=>({type:g.type,sources:g.properties.sources?.map(v=>({text:v.properties.text,x:v.properties.x,weight:v.weight}))})),leaders:s.graphics.leaders.length})),slots:geoTextFrameCollector(samples,b).slots}));
try{const p=planTransition({from:base,to:next,options:{durationMs:100,easing:'linear'}});const f=sampleTransition(p,50);console.log('sample',f.scene.nodes.length);const r=planTransition({from:f,to:next,options:{durationMs:100,easing:'linear'}});deserializeAnimation(serializeAnimation(r));}catch(error){console.log(error.stack);}
