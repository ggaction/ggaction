import {chart} from '../../src/index.js';
import {planTransition,sampleTransition} from '../../src/animation.js';
import {transitionGeoTexts} from '../../src/animation/planner.js';
const a=chart().createCanvas({width:400,height:300,margin:0}).createGeometryData({id:'places',format:'geojson',coordinateKind:'planar',featureKey:'id',values:{type:'FeatureCollection',features:[{type:'Feature',id:'a',properties:{name:'Old'},geometry:{type:'Point',coordinates:[40,50]}}]}}).createProjection({id:'map',type:'identity'}).createCoordinate({type:'geo'}).createGeoPointMark({id:'places-mark'}).createMarkLabels({id:'labels',field:'name',dx:4});
const b=a.editTextMark({target:'labels',textOverrides:[{match:{fields:{name:'Old'}},occurrence:0,text:''}]}).editProjection({scalePx:4});
const p=planTransition({from:a,to:b,options:{durationMs:100,easing:'linear'}});
console.log(JSON.stringify(transitionGeoTexts(p),null,2));console.log(JSON.stringify(sampleTransition(p,50),null,2));
