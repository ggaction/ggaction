import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {tmpdir} from 'node:os';import path from 'node:path';import {createHash} from 'node:crypto';
import {compactPackageJavaScript} from '../scripts/package-artifact.js';
const root=process.cwd(),record=JSON.parse(await readFile('.artifacts/dynamic-guide-final-archive.json','utf8'));
const text=await readFile('scripts/package-artifact.js','utf8'),list=name=>new Set(JSON.parse(text.match(new RegExp('const '+name+' = Object.freeze\\((\\[[\\s\\S]*?\\])\\);'))[1]));
const json=list('COMPACT_JSON_FILES'),js=list('COMPACT_JAVASCRIPT_FILES'),hash=x=>createHash('sha256').update(x).digest('hex');
const directory=await mkdtemp(path.join(tmpdir(),'ggaction-guide-proof-')),mismatches=[],hashes={};
try{
 execFileSync('tar',['-xzf',record.file,'-C',directory]);
 for(const {path:file} of record.files){
  const raw=await readFile(path.join(root,file));hashes[file]=hash(raw);
  const expected=json.has(file)?Buffer.from(JSON.stringify(JSON.parse(raw))):js.has(file)?Buffer.from(compactPackageJavaScript(raw.toString(),{keepNames:file==='knowledge/task-resolver.js'})):raw;
  const packed=await readFile(path.join(directory,'package',file));if(!expected.equals(packed))mismatches.push(file);
 }
 const output={archive:record.file,sha256:hash(await readFile(record.file)),files:record.files.length,mismatches,hashes};
 await writeFile('.artifacts/dynamic-guide-exact-inputs.json',JSON.stringify(output,null,2)+'\n');
 console.log(JSON.stringify({files:output.files,mismatches,sha256:output.sha256}));if(mismatches.length)process.exitCode=1;
}finally{await rm(directory,{recursive:true,force:true});}
