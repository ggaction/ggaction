import { identifyItems } from "../items/common.js";
import { memberRowReferences } from "../rows.js";
import { textSelectionPolicy } from "./text.js";
import { findDataset } from "../../../selectors/datasets.js";
import { requireLayer } from "../../../selectors/layers.js";
import { areaSelectionPolicy } from "./area.js";
import { arcSelectionPolicy } from "./arc.js";
import { barSelectionPolicy } from "./bar.js";
import { lineSelectionPolicy } from "./line.js";
import { pointSelectionPolicy } from "./point.js";
import { ruleSelectionPolicy } from "./rule.js";
import { tickSelectionPolicy } from "./tick.js";
import { rectSelectionPolicy } from "./rect.js";
import { applyItemMissingPolicy } from "../../../grammar/itemMissing.js";
import { resolveOverlayItems } from "../items/overlay.js";

const POLICIES = Object.freeze({
  text: textSelectionPolicy,
  arc: arcSelectionPolicy,
  area: areaSelectionPolicy,
  bar: barSelectionPolicy,
  line: lineSelectionPolicy,
  point: pointSelectionPolicy,
  rule: ruleSelectionPolicy,
  tick: tickSelectionPolicy,
  rect: rectSelectionPolicy
});

export function findSelectionPolicy(markType) {
  return POLICIES[markType];
}

export function requireSelectionPolicy(markType) {
  const policy = findSelectionPolicy(markType);
  if (policy === undefined) {
    throw new Error(`Mark type "${markType}" has no selection policy.`);
  }
  return policy;
}

export function resolveMarkItems(program, target, grain = "item") {
  return resolveItems(program, target, grain, false);
}

// Concrete output records direct membership; expanding all ancestors belongs
// to selection and inspection, not every geometry rebuild.
export function resolveMarkIdentities(program, target) {
  return resolveItems(program, target, "item", true);
}

function resolveItems(program, target, grain, identityOnly) {
  const resolvers = { resolveMarkItems, resolveMarkSourceItems, identityOnly };
  const layer = requireLayer(program, target, `Unknown mark target "${target}"`);
  if (layer.derivedBindings?.overlay) {
    if (grain !== "item") throw new Error(`Overlay "${target}" supports item selection grain.`);
    return resolveOverlayItems(program, layer, resolvers);
  }
  const dataset = findDataset(program, layer.data);
  if (dataset === undefined) {
    throw new Error(`Mark "${target}" requires an existing dataset for selection.`);
  }
  const policy = requireSelectionPolicy(layer.mark?.type);
  if (!policy.supportedGrains.includes(grain)) {
    throw new Error(`Mark "${target}" does not support ${grain} selection grain.`);
  }
  return policy.resolveItems(program, layer, applyItemMissingPolicy(layer, dataset), grain, resolveMarkItems, resolvers);
}

// Composite source membership does not require the parent's graphics to have
// finished rebuilding. Each owning policy supplies its same final semantic grain.
export function resolveMarkSourceItems(program, target, grain = 'item') {
  const layer = requireLayer(program, target), policy = requireSelectionPolicy(layer.mark.type);
  if (!policy.resolveSourceItems) return resolveMarkItems(program, target, grain);
  const dataset = applyItemMissingPolicy(layer, findDataset(program, layer.data));
  return identifyItems(program, layer, grain, policy.resolveSourceItems(program, layer, dataset, grain)).map(item => ({
    ...item, properties: item.properties ?? {},
    rows: memberRowReferences(program, item.members, layer.data, item.memberKeys)
  }));
}
