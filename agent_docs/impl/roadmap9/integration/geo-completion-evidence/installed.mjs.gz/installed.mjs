import fs from 'node:fs/promises';
import path from 'node:path';
import { preparePackageConsumer } from '../../scripts/package-consumer.js';
import { run, tscCommand } from '../../scripts/consumers/runtime.js';
import { documentationPrograms } from '../../scripts/doc-snippets.js';
import { measureMinimalBrowserBundle } from '../../scripts/browser-bundle-size.js';
import {testTypeScriptConsumer} from '../../scripts/consumers/types.js';
const artifact=JSON.parse(await fs.readFile('.artifacts/geo-integration-pack-final.json','utf8'));
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
const report={node:process.version,zlib:process.versions.zlib,sha256:artifact.sha256,cases:[],bundles:{}};
try {
  run('npm',['install','--ignore-scripts','--no-audit','--no-fund','@napi-rs/canvas@'+JSON.parse(await fs.readFile('package-lock.json','utf8')).packages['node_modules/@napi-rs/canvas'].version],consumer.directory);
  for(const [example,output] of [['nested-responsive','nested-responsive-public.js'],['responsive-guides','responsive-public.js']]) await fs.writeFile(path.join(consumer.directory,output),(await fs.readFile('examples/'+example+'/program.js','utf8')).replaceAll('../../src/index.js','ggaction'));
  for(const name of ['geometry','projections','observed-graphs','inferred-graphs','contours','interaction','logical-selection','calendar-plots','edge-routes','responsive-guides','nested-responsive'])await fs.copyFile('scripts/consumers/fixtures/node/'+name+'.mjs',path.join(consumer.directory,name+'.mjs'));
  await fs.writeFile(path.join(consumer.directory,'run.mjs'),`import fs from 'node:fs/promises';const out=[];for(const name of ['geometry','projections','observed-graphs','inferred-graphs','contours','interaction','logical-selection','calendar-plots','edge-routes','responsive-guides','nested-responsive']){const {cases}=await import('./'+name+'.mjs');for(const entry of cases){await entry.run();out.push({id:entry.id,status:'passed'});}}await fs.writeFile('geometry-cases.json',JSON.stringify(out));`);
  run(process.execPath,['run.mjs'],consumer.directory);
  report.cases=JSON.parse(await fs.readFile(path.join(consumer.directory,'geometry-cases.json'),'utf8'));
  await fs.writeFile(path.join(consumer.directory,'geometry-types.mts'),`import {chart,type GeometrySourceResource,type CreateGeometryDataOptions,type GeoJSONInput,type TopoJSONInput} from 'ggaction';
import {chart as basic} from 'ggaction/basic';
const values:GeoJSONInput={type:'FeatureCollection',features:[],copyright:'retained'};
const options:CreateGeometryDataOptions={id:'shape',format:'geojson',coordinateKind:'geographic',values,featureKey:['properties','code']};
const p=chart().createGeometryData(options).editGeometryData({limits:{maxFeatures:10}});
const topology:TopoJSONInput={type:'Topology',arcs:[],objects:{region:{type:'Point',coordinates:[0,0]}}};
chart().createGeometryData({id:'topology',format:'topojson',coordinateKind:'planar',values:topology});
const source=p.semanticSpec.resources.find((r):r is GeometrySourceResource=>r.kind==='geometry'&&r.options.method==='geo');
// @ts-expect-error Basic does not register geographic source actions.
basic().createGeometryData(options);
// @ts-expect-error Stored identity is immutable.
source!.result.identity.revision=1;
// @ts-expect-error A source coordinate kind is mandatory.
chart().createGeometryData({id:'bad',format:'geojson',values});
`);
  run(process.execPath,[tscCommand,'--strict','--exactOptionalPropertyTypes','--skipLibCheck','--noEmit','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','geometry-types.mts'],consumer.directory);
  await fs.writeFile(path.join(consumer.directory,'projection-types.mts'),"\nimport {chart, type ProjectionResource, type CreateProjectionOptions} from 'ggaction';\nimport {chart as basic} from 'ggaction/basic';\nconst options:CreateProjectionOptions={id:'map',type:'conic-equal-area',parallelsDeg:[30,60],fit:{geometry:'shape',width:600,height:400}};\nconst p=chart().createProjection(options).editProjection({rotateDeg:[10,20,0]}).editProjection({scalePx:200});\np.editProjection({target:{childPath:['left'],id:'map'},type:'identity',fit:{width:100,height:100}});\np.createProjection({id:'insets',type:'albers-usa',precisionPx:.5});\np.removeResource({kind:'projection',id:'map'});\ndeclare const resource:ProjectionResource;\nconst scale:number|undefined=resource.result.scalePx;\n// @ts-expect-error The stored result is immutable.\nresource.result.scalePx=200;\n// @ts-expect-error Identity has no spherical rotation.\nchart().createProjection({id:'bad',type:'identity',rotateDeg:[0,0]});\n// @ts-expect-error Composite inset policy has no arbitrary clipping angle.\nchart().createProjection({id:'bad',type:'albers-usa',clipAngleDeg:80});\n// @ts-expect-error Parallel policy is conic only.\nchart().createProjection({id:'bad',type:'mercator',parallelsDeg:[20,40]});\n// @ts-expect-error Fit conflicts with explicit scale.\nchart().createProjection({id:'bad',type:'identity',scalePx:2,fit:{width:100,height:100}});\n// @ts-expect-error Fit conflicts with explicit translation on edit too.\np.editProjection({translatePx:[0,0],fit:{width:100,height:100}});\n// @ts-expect-error Projection authoring is Full only.\nbasic().createProjection({id:'bad',type:'identity'});\nvoid scale;\n");
  run(process.execPath,[tscCommand,'--strict','--exactOptionalPropertyTypes','--skipLibCheck','--noEmit','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','projection-types.mts'],consumer.directory);
  await testTypeScriptConsumer(consumer.directory);report.types='geometry, projection and all public consumers passed';
  const example=(await documentationPrograms()).find(value=>value.id==='projection-fit');
  await fs.writeFile(path.join(consumer.directory,'projection-doc.mjs'),example.code+"\nimport assert from 'node:assert/strict';assert.deepEqual(fitted.semanticSpec.resources.find(value=>value.kind==='projection').result,{scalePx:5,translatePx:[25,0],bounds:[25,0,75,100]});");
  run(process.execPath,['projection-doc.mjs'],consumer.directory);report.publicSnippet='projection-fit literal bounds passed';
  await fs.writeFile(path.join(consumer.directory,'projection-smoke.mjs'),`import assert from 'node:assert/strict';import {createRequire} from 'node:module';import path from 'node:path';import {pathToFileURL} from 'node:url';import fs from 'node:fs';
const root=path.dirname(path.dirname(createRequire(import.meta.url).resolve('ggaction')));
const {createProjectionKernel,projectRaw}=await import(pathToFileURL(path.join(root,'src/grammar/geo/projections.js')));
const {PROJECTION_DESCRIPTORS}=await import(pathToFileURL(path.join(root,'src/grammar/geo/projectionOptions.js')));
assert.equal(PROJECTION_DESCRIPTORS.length,15);assert.ok(Math.abs(projectRaw({type:'mercator'},[0,Math.PI/4]).point[1]-.881373587019543)<1e-9);
for(const {type} of PROJECTION_DESCRIPTORS){const p=createProjectionKernel({type});const expected=type==='albers-usa'?[-100,40]:[20,30];const actual=p.inverse(p.forward(expected).point).point;assert.ok(actual.every((v,i)=>Math.abs(v-expected[i])<1e-6),type);}
const manifest=JSON.parse(fs.readFileSync(path.join(root,'licenses/geometry-math.json')));const require=createRequire(path.join(root,'package.json'));const dependency=require.resolve(manifest.directDependency);const installed=JSON.parse(fs.readFileSync(path.join(path.dirname(path.dirname(dependency)),'package.json')));assert.equal(installed.version,manifest.packages[0].version);assert.ok(fs.readFileSync(path.join(root,'THIRD_PARTY_NOTICES'),'utf8').length>1000);console.log('packaged geographic math verified');`);
  run(process.execPath,['projection-smoke.mjs'],consumer.directory);
  const licenseContract=(await fs.readFile('test/contracts/geographic-math.test.js','utf8')).replace('const root = fileURLToPath(new URL("../../", import.meta.url));', 'const root = path.dirname(path.dirname(createRequire(import.meta.url).resolve("ggaction")));').replace('import { PROJECTION_DESCRIPTORS } from "../../src/grammar/geo/projectionOptions.js";', 'const { PROJECTION_DESCRIPTORS } = await import(new URL("node_modules/ggaction/src/grammar/geo/projectionOptions.js", import.meta.url));').replace('const pkg = JSON.parse(read("package.json")), lock = JSON.parse(read("package-lock.json"));','const pkg = JSON.parse(read("package.json"));').split('\n').filter(line=>!line.includes('lock.packages')&&!line.includes('assert.equal(stored.')).join('\n');
  await fs.writeFile(path.join(consumer.directory,'license.test.mjs'),licenseContract);
  run(process.execPath,['--test','license.test.mjs'],consumer.directory);
  report.dependencyProof='all 3 packages: version, license hash, complete source signatures';
  report.privateKernel='15 projections, raw literal, inverse, installed dependency version and notices passed';
  for(const specifier of ['ggaction','ggaction/basic','ggaction/svg','ggaction/interaction','ggaction/graph']) report.bundles[specifier]=await measureMinimalBrowserBundle(consumer.directory,{specifier});
} finally {
  await fs.writeFile(`.artifacts/geo-integration-installed-${process.versions.node.split('.')[0]}.json`,JSON.stringify(report,null,2));
  await consumer.cleanup();
}
console.log(JSON.stringify(report,null,2));
