import { collectTestFiles } from '../../scripts/run-tests.js';
import { spawnSync } from 'node:child_process';
const files=[...new Set([...collectTestFiles('unit',undefined,['capability:hit-testing']),...collectTestFiles('unit',undefined,['unit/actions/encodings/category-order.test.js'])])];
const owners=['grammar/selectionHandles.js','interaction/regionResize.js','interaction/categoryReorder.js','interaction/regionCoordinates.js','interaction/regionSelection.js','interaction/hitProgram.js','materialization/categoryOrder.js'];
const result=spawnSync(process.execPath,['--experimental-test-coverage',...owners.map(x=>'--test-coverage-include=src/'+x),'--test',...files],{stdio:'inherit'});process.exitCode=result.status??1;
