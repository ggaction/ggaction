import assert from 'node:assert/strict';
import {mkdir,symlink,readlink} from 'node:fs/promises';
import path from 'node:path';
import {chromium}from'playwright';
import AxeBuilder from'@axe-core/playwright';
import{startStaticServer}from'../../test/support/static-server.js';
import{openBrowserPage,assertNoBrowserErrors,saveBrowserEvidence,closeBrowserWithEvidence}from'../../test/support/browser.js';
const mount=path.resolve('.artifacts/handles/site');await mkdir(mount,{recursive:true});
const link=path.join(mount,'ggaction');try{await symlink(path.resolve('_site'),link);}catch(error){if(error.code!=='EEXIST')throw error;assert.equal(await readlink(link),path.resolve('_site'));}
const server=await startStaticServer(mount),browser=await chromium.launch({headless:true});
try{
 for(const width of [320,390,768,1280])for(const route of ['api/interaction/','recipes/inspect-chart/']){
  const context=await browser.newContext({viewport:{width,height:900}});
  try{
   const{page,errors}=await openBrowserPage(context,server.baseUrl+'ggaction/'+route);
   await page.waitForFunction(()=>[...document.images].filter(image=>image.loading!=='lazy').every(image=>image.complete&&image.naturalWidth>0));
   assert.match(await page.locator('main').innerText(),route.startsWith('api')?/getSelectionHandles/:/createSelectionHandleChart/);
   const bounds=await page.evaluate(()=>({body:document.documentElement.scrollWidth,viewport:window.innerWidth}));
   assert.ok(bounds.body<=bounds.viewport+1,JSON.stringify(bounds));
   const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
   assert.deepEqual(axe.violations.map(x=>({id:x.id,impact:x.impact})),[]);
   await page.locator(route.startsWith('api')?'#resize-a-selection-or-reorder-categories':'h1').scrollIntoViewIfNeeded();
   await page.screenshot({path:'.artifacts/handles/docs-'+route.split('/')[0]+'-'+width+'.png'});
   assertNoBrowserErrors(errors,'Changed interaction documentation');await page.close();
   console.log(JSON.stringify({page:route,width,overflow:false,axeViolations:0,consoleErrors:0}));
  }finally{await context.close();}
 }
}catch(error){await saveBrowserEvidence(browser,error);throw error;}
finally{await closeBrowserWithEvidence(browser);await server.close();}
