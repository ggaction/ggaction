import gzip,hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd();out=root/'agent_docs/impl/roadmap9/interaction/legend-visibility-evidence';out.mkdir(exist_ok=True)
def read(name):return json.loads((root/'.artifacts'/name).read_text())
files=[]
for p in sorted((root/'.artifacts').glob('visibility-*')):
 if p.suffix not in ['.log','.mjs','.py']:continue
 data=gzip.compress(p.read_bytes(),mtime=0);dest=out/(p.name+'.gz');dest.write_bytes(data);files.append({'path':dest.name,'sha256':hashlib.sha256(data).hexdigest()})
for name in ['visibility-fixed.json','visibility-superseded.json','visibility-oracle.json','visibility-final-measured20.json']:(out/name).write_bytes((root/'.artifacts'/name).read_bytes())
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
sources=sorted({f for f in changed if f.startswith(('src/','types/'))})
data={
'baseCommit':'23fe1677907b27d39dbe1568ffcc30451b5e0548','sourceCommit':None,'authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
'scope':'STEP060 C2 categorical visibility as an outer final-item view composed with native user filtering; explicit domain policy, control legend, session and immutable revision closure',
'sourceHashes':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in sources},
'checks':{
'nativeAndComposition':{'initialNative':32,'sessionAndLegacy':43,'stateValidation':11,'resourceDAGAndHistogram':45,'legendOrderAndOriginalSource':48},
'newCriticalOwners':{'passed':56,'floor':[95,90,100],'owners':{'actions/data/filterGeometry.js':[100,90.48,100],'actions/data/visibility.js':[100,92.11,100],'grammar/markVisibility.js':[100,100,100],'interaction/legendCategory.js':[100,100,100],'interaction/legendVisibility.js':[100,94.59,100],'materialization/markVisibility.js':[100,100,100]},'timing':'Before final dormant-value restoration addition; final changed owner below.'},
'finalDormantRestoration':{'passed':22,'owner':'actions/data/visibility.js','coverage':[100,92.5,100]},
'sharedOwners':{'passed':235,'owners':{'interaction/bindings.js':[100,98.67,100],'interaction/legendSelection.js':[100,93.02,100],'interaction/selection.js':[100,99.19,100],'interaction/session.js':[100,94.42,100],'grammar/categoryOrder.js':[89.63,89.25,100],'grammar/markFilter.js':[83.33,76,100],'materialization/scales/policies/binnedPosition.js':[92.11,75,100],'materialization/selection/filter.js':[96.36,75,100],'selectors/datasets.js':[86.36,87.5,84.21]},'policy':'Existing canonical floors unchanged; final dormant action-only delta is measured separately.'},
'publicContracts':46,'finalCatalog':11,'finalSourceTypesSessionBoundary':{'passed':35,'total':37,'remaining':'Two discovery failures were module location only; moving render test to existing chart capability closed all16 owning discovery checks.'},'finalDiscovery':16,
'realistic':{'passed':16,'witness':'Five pinned datasets times observations/categories/series and inventory, both scale policies, typed category hiding/restoration and codec.'},
'browser':{'passed':1,'witness':'Canvas and SVG DPR2 actual category clicks, Escape/cancel, one committed edit, restore and cleanup.'},
'render':{'passed':1,'command':'node scripts/run-tests.js render charts/mark-selection-points/visibility.render.js','witness':'Independent literal first/third glyph omission, same Canvas calls/SVG/PNG/PDF streams, editable/graphic codec and expected flattened scene.'},
'docs':{'initialPassed':45,'initialTotal':47,'qualified':47,'builtPages':170,'llmArtifacts':1458,'widths':[320,390,768,1440],'axeViolations':0},
'installed':[read('visibility-final-consumer'+str(v)+'.log') for v in [20,22,24]],'installedPublicSnippet':read('visibility-final-doc-consumer.log')},
'artifact':read('visibility-fixed.json'),'supersededArtifact':read('visibility-superseded.json'),'packageMeasurementNode20':read('visibility-final-measured20.json'),
'limits':{'entries':988,'packedBytes':1417000,'unpackedBytes':6443000,'fullGzip':690300,'basicGzip':378400,'interactionGzip':111900,'svgGzip':25000,'graphGzip':44000,'searchBytes':987000},
'preservedFailures':[
'Persistence direct import violated the existing boundary; the existing resourceState reexport owns visibility validation. No allowlist relaxation.',
'Binned visible domains incorrectly consulted only markConfigs.markFilter. The canonical active filter selector now covers visibility, and literal bin domain tests verify the correction.',
'User filter / authored category order validation used visible rows. Both stages now resolve original source for authored intent validation, then project active domains; unknown new values still reject.',
'Linked filter projection discarded dormant visibility while replacing the underlying membership. Native filter writes on the original program now preserve the outer recipe and compare pre-visibility membership.',
'Nested semantic no-op previously looked at the outer program instead of the resolved owner. The scope-specific identity check retains exact program/trace/revision.',
'The render oracle initially passed child IDs through the public edit item shape, then compared flattened scene save/restore calls with nested program calls. It now uses explicit primitive omission and compares the same renderer path; source is unchanged.',
'The render module was first placed under unit, outside canonical render discovery. Moving it into the existing mark-selection-points slice closes the two owning discovery failures.',
'Catalog final10/11 identified missing Covered evidence markers for the new action sections. Markers were added without changing support claims and the owning11 passed.',
'First docs source check45/47 found missing action names in CHANGELOG and search986895 over984000. Names and measured987000cap close47/47.',
'First package check exceeded entry cap. New six owners measured988 entries and Node20 packed1416316/unpacked6442865, so only minimum rounded caps changed.',
'First Node22 candidate and final Node20 bundle measurements exceeded prior limits. Node20 runtime/types completed; recorded bundle JSON passes new measured caps. Node22/24 final commands pass including budgets.',
'Final cb065aa8 supersedes e582ecdc after stored dormant hidden values were recognized for explicit restoration; unknown never-seen input still rejects.'
],
'globalCoverage':'Not rerun. Focused new/shared critical owners plus final public consumers qualified. Root retains full integration obligations.',
'remaining':['non-categorical legend interaction requirements','parameter controls/context action targets','annotation anchor/offset editing','node drag/partition focus/geo navigation/keyboard','AT35/38/65/80 complete consumer closure','STEP074 integrated qualification and STEP077'],
'commands':{
'critical':'node --test --experimental-test-coverage --test-coverage-include=src/actions/data/filterGeometry.js --test-coverage-include=src/actions/data/visibility.js --test-coverage-include=src/grammar/markVisibility.js --test-coverage-include=src/interaction/legendCategory.js --test-coverage-include=src/interaction/legendVisibility.js --test-coverage-include=src/materialization/markVisibility.js test/unit/actions/data/mark-visibility.test.js test/unit/grammar/mark-visibility.test.js test/unit/interaction-legend-visibility.test.js test/unit/interaction-legend-selection.test.js test/unit/actions/data/filter-*.test.js',
'finalSource':'node --test test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js test/contracts/interaction-types.test.js test/unit/interaction-legend-visibility.test.js; owning discovery rerun after module move',
'realistic':'GGACTION_TEST_TIDYTUESDAY_CACHE_ROOT=/Users/hyeonjeon/Projects/ggactionnewbrand/.artifacts/datasets/tidytuesday node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js',
'browser':'node --test --test-name-pattern="categorical visibility" test/browser/interaction-session.browser.js',
'installed':'Node20/22/24: node .artifacts/visibility-consumer.mjs; Node20 cap-only check: node .artifacts/visibility-budget-check.mjs; Node22: node .artifacts/visibility-doc-consumer.mjs',
'docs':'npm run docs:generate; final docs:provenance, docs:images, docs:machine, docs:llms; node --test test/docs/documentation.test.js test/docs/documentation-coverage.test.js; npm run docs:build; npm run test:docs:built; node .artifacts/visibility-doc-browser.mjs'},'evidenceFiles':files}
(out/'qualification.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
