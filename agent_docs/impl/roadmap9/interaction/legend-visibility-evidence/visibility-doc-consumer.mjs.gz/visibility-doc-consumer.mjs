import assert from 'node:assert/strict';
import {readFile,writeFile,realpath} from 'node:fs/promises';import path from 'node:path';
import {build,preview} from 'vite';import {chromium} from 'playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';import {documentationPrograms} from '../scripts/doc-snippets.js';
const artifact=JSON.parse(await readFile('.artifacts/visibility-fixed.json','utf8'));
const example=(await documentationPrograms()).find(example=>example.id==='interaction-legend-visibility');assert.ok(example);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});consumer.directory=await realpath(consumer.directory);let server,browser;
try{
 await writeFile(path.join(consumer.directory,'index.html'),'<html lang="en"><head><title>Legend visibility</title></head><body><canvas id="chart" aria-label="Category visibility legend"></canvas><script type="module" src="/main.js"></script></body></html>');
 await writeFile(path.join(consumer.directory,'main.js'),example.code+'\nimport {getMarkItems} from "ggaction/inspection";window.legendExample={session:visibilitySession,items:()=>getMarkItems(visibilitySession.getState().program,{target:"points"})};');
 await build({root:consumer.directory,logLevel:'silent',build:{target:'esnext'}});server=await preview({root:consumer.directory,logLevel:'silent',preview:{host:'127.0.0.1',port:0}});
 browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(server.resolvedUrls.local[0]);await page.waitForFunction(()=>window.legendExample);
 const point=await page.evaluate(()=>{const n=window.legendExample.session.getState().scene.nodes.find(n=>n.type==='rect'&&n.properties.width===14&&n.properties.height===12);return{x:n.offset[0]+n.properties.x+7,y:n.offset[1]+n.properties.y+6};});const box=await page.locator('canvas').boundingBox();await page.mouse.click(box.x+point.x,box.y+point.y);
 assert.deepEqual(await page.evaluate(()=>window.legendExample.items().map(item=>item.fields.id)),['b']);assert.deepEqual(errors,[]);
 console.log(JSON.stringify({node:process.version,archive:artifact.sha256,id:example.id,sourceFree:true,rendered:true,visible:['b'],errors:[]}));await page.evaluate(()=>window.legendExample.session.destroy());
}finally{await browser?.close();if(server)await new Promise(resolve=>server.httpServer.close(resolve));await consumer.cleanup();}
