import fs from 'node:fs';import {spawnSync} from 'node:child_process';
const tests=fs.readdirSync('test/unit').filter(file=>file.startsWith('interaction-')&&file.endsWith('.test.js')).map(file=>'test/unit/'+file);
tests.push(...fs.readdirSync('test/unit/grammar').filter(file=>file.startsWith('hit-')&&file.endsWith('.test.js')).map(file=>'test/unit/grammar/'+file));
const result=spawnSync(process.execPath,['--experimental-test-coverage',...['interaction/session.js','interaction/keyboardFocus.js','grammar/hitShapes.js','grammar/hitClipDistance.js'].map(file=>'--test-coverage-include=src/'+file),'--test',...tests],{stdio:'inherit'});process.exitCode=result.status??1;
