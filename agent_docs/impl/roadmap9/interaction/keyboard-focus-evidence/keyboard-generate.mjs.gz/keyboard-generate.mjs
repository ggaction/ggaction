import {spawnSync} from 'node:child_process';
for(const script of ['generate-doc-signatures.js','generate-doc-snippet-contracts.js','generate-doc-page-metadata.js','generate-doc-search-index.js','generate-doc-machine-artifacts.js','generate-llm-docs.js']) {
 const result=spawnSync(process.execPath,['scripts/'+script],{stdio:'inherit'});
 if(result.status!==0){process.exitCode=result.status??1;break;}
}
