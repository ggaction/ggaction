import assert from 'node:assert/strict';
import {readFile,writeFile,realpath} from 'node:fs/promises';
import path from 'node:path';
import {build,preview} from 'vite';
import {chromium} from 'playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {documentationPrograms} from '../scripts/doc-snippets.js';
const artifact=JSON.parse(await readFile('.artifacts/viewport-fixed.json','utf8'));
const snippet=(await documentationPrograms()).find(example=>example.id==='interaction-viewport');assert.ok(snippet);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});consumer.directory=await realpath(consumer.directory);let server,browser;
try{
 await writeFile(path.join(consumer.directory,'index.html'),'<html lang="en"><head><title>Map navigation</title></head><body><canvas id="chart" aria-label="Map points"></canvas><script type="module" src="/main.js"></script></body></html>');
 await writeFile(path.join(consumer.directory,'main.js'),snippet.code+'\nwindow.controls={session:viewportSession,dispose:disposeViewport};');
 await build({root:consumer.directory,logLevel:'silent',build:{target:'esnext'}});server=await preview({root:consumer.directory,logLevel:'silent',preview:{host:'127.0.0.1',port:0}});
 browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(server.resolvedUrls.local[0]);await page.waitForFunction(()=>window.controls);
 assert.equal(await page.locator('output').textContent(),'Scale 1; translation 0, 0');
 await page.getByRole('button',{name:'Pan right',exact:true}).focus();await page.keyboard.press('Enter');
 assert.equal(await page.locator('output').textContent(),'Scale 1; translation 20, 0');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),1);
 assert.equal(await page.evaluate(()=>document.activeElement.id),'map-right');
 await page.getByRole('button',{name:'Zoom in',exact:true}).focus();await page.keyboard.press('Space');
 assert.equal(await page.locator('output').textContent(),'Scale 2; translation 20, 0');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),2);
 await page.getByRole('button',{name:'Original view',exact:true}).click();assert.equal(await page.locator('output').textContent(),'Scale 1; translation 0, 0');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),3);
 await page.evaluate(()=>window.controls.dispose());assert.deepEqual(errors,[]);
 console.log(JSON.stringify({node:process.version,archive:artifact.sha256,id:snippet.id,sourceFree:true,viewportRevision:3,transform:{scalePx:1,translatePx:[0,0]},keyboard:true,disposed:true,errors:[]}));
}finally{await browser?.close();if(server)await new Promise(resolve=>server.httpServer.close(resolve));await consumer.cleanup();}
