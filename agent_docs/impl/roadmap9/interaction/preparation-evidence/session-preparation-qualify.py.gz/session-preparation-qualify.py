from pathlib import Path
import gzip,hashlib,json,subprocess,shutil
root=Path('agent_docs/impl/roadmap9/interaction/preparation-evidence');root.mkdir(exist_ok=True)
def j(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','types'],text=True).splitlines();h=hashlib.sha256()
for f in sorted(set(files)):h.update(f.encode()+b'\0'+Path(f).read_bytes()+b'\0')
r={'parent':'68d09461d','sourceCommit':'57a2463deb9fca9f37af08684939bf696892c003','authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 'scope':'Atomic optional renderer asset preparation for native candidates, history and external replacement, four exact dependency tags, abortable leases and terminal runtime disposal. No authoring API, persisted state or renderer computation added.',
 'runtimeAndTypesFingerprint':h.hexdigest(), 'checks':{'cross':251,'finalFocused':17,'critical':j('.artifacts/session-preparation-critical.log'),
 'realistic':{'tests':16,'datasets':5,'recipes':3,'path':'test/contracts/realistic-logical-selection.test.js'},
 'browser':{'tests':1,'dpr':2,'canonicalFragment':'docs/api/interaction.md#prepare-assets-before-committing','expected':{'commits':1,'history':1,'bitmapCloses':4,'writesAfterDestroy':0}},
 'lifecycle':{'inspectCycles':100,'activeCaptureAndRAFCycles':100,'finalListeners':0,'finalCaptures':0,'finalFrames':0},
 'boundariesAndCoveragePolicy':6,'packagePolicyAndManifest':2,
 'docs':{'initial':{'total':208,'passed':205,'failed':3},'changedOwning':49,'builtPages':172,'llmArtifacts':1531,'finalPinnedBuild':'passed: 172 pages and 1531 LLM artifacts','manualInspection':'320px and 1440px screenshots inspected: contextual fragment label, contained code, readable copy and navigation','responsiveWidths':[320,390,768,1440],'axeViolations':0,'overflow':False},
 'installed':[json.JSONDecoder().raw_decode(Path(f'.artifacts/session-preparation-consumer{n}.log').read_text())[0] for n in (20,22,24)]},
 'artifact':j('.artifacts/session-preparation-fixed.json'),'node20PackageMeasurement':j('.artifacts/session-preparation-package-measure20-final.json'),
 'limits':{'entries':1049,'packedBytes':1491000,'unpackedBytes':6780000,'interactionGzip':115900,'searchBytes':1028800},
 'preservedFailures':['Initial test fixtures used an unsupported hconcat object and undersized Canvas default margins; corrected literal fixtures passed.',
 'Initial new assets.phase event conflicted with existing transaction phase discriminants. The new assets.status lifecycle preserves existing transaction consumers; strict types pass.',
 'Initial capability entry omitted type:file; repaired discovery registration passes.',
 'Initial docs208 had 3 failures: two search-cap checks and unregistered contextual fragment. Owning49 passes after minimal cap and reviewed hash registration; a later stale provenance owning failure was regenerated.',
 'Visual inspection found normal resolver cleanup labeled expected-error; the canonical example uses try/finally, retaining exact browser abort/cleanup behavior, and its generator now labels it Contextual fragment.',
 'Initial package entries1049 exceeded1048; canonical Node20 measurements justify minimal package ceilings. Initial Node20 installed command passed15runtime+types and measured all5bundles, then failed old114100 interaction cap; same archive measurements pass115900 cap. Node22/24 complete commands exit0.'],
 'reusedEvidence':'No broad normal/source/installed sweep claimed. Changed source cross251 and focused17 cover the new boundary; prior unrelated renderer proofs remain unchanged. The exact real browser fragment and Node actual decoded image pixels are fresh.',
 'remaining':['Public animation planner/player and current-scene asset preparation integration','Async domain worker/layout result attachment and ResizeObserver lifecycle','Native navigation/multi-binding arbitration and final AT40-41/STEP074-077 matrix'],
 'commands':{'cross':'node --test --experimental-test-coverage --test-coverage-include=src/interaction/preparation.js --test-coverage-include=src/interaction/session.js test/unit/interaction-*.test.js test/contracts/interaction-types.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js',
 'realistic':'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned cache',
 'browser':'node --test --test-name-pattern="canonical asset resolver" test/browser/interaction-session.browser.js',
 'installed':'Node20/22/24 node .artifacts/session-preparation-consumer.mjs with same fixed archive; Node20 same measurement cap recheck',
 'docs':'docs:generate; test:docs original208; changed owning49; docs:build; test:docs:built; final source pin follows source commit'},'evidenceFiles':[]}
for p in sorted(Path('.artifacts').glob('session-preparation-*')):
 if p.is_file() and p.suffix in ['.log','.mjs','.json','.py']:
  out=root/(p.name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
for p in sorted(Path('.artifacts/interaction-preparation-docs').glob('*.png')):
 out=root/p.name;shutil.copy2(p,out);r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
(root/'qualification.json').write_text(json.dumps(r,indent=2)+'\n')
