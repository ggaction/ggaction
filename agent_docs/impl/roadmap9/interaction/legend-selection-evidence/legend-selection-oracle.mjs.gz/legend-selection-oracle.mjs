import assert from 'node:assert/strict';
import {chart} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
import {prepareProgramHitFrame} from '../src/interaction/hitProgram.js';
const p=chart().createCanvas({width:500,height:350,margin:100})
 .createData({keyField:'id',values:[{id:'a',x:1,y:2,c:1},{id:'b',x:2,y:3,c:'1'},{id:'c',x:3,y:4,c:1}]})
 .createScatterPlot({id:'points',x:'x',y:'y',color:'c',guides:false})
 .createLegend({target:'points',channels:['color']}).selectMarks({id:'picked',target:'points',items:[]})
 .highlightMarks({selection:'picked',color:'red',dimOthers:false,bringToFront:false});
const before=serializeProgram(p),session=createInteractionSession({program:p,bindings:[{type:'legend',effect:'selection',target:'points',channel:'color',selection:'picked'}]});
const listeners=new Map(),host={getBoundingClientRect:()=>({left:0,top:0,width:500,height:350}),addEventListener(type,fn){listeners.set(type,fn)},removeEventListener(type){listeners.delete(type)}};
session.mount(host);const frame=prepareProgramHitFrame(p),samples=frame.entries.filter(e=>e.metadata.role==='legend-item'&&frame.scene.nodes[e.zIndex].type==='rect');
const actual=[];for(const i of [0,1,0]){const b=samples[i].shape.bounds;listeners.get('click')({clientX:(b.left+b.right)/2,clientY:(b.top+b.bottom)/2,pointerType:'mouse'});actual.push(getMarkItems(session.getState().program,{target:'points'}).filter(i=>i.properties.fill==='red').map(i=>i.fields.id))}
const expected=[['a','c'],['a','b','c'],['b']];assert.deepEqual(actual,expected);assert.equal(serializeProgram(p),before);
const restored=getMarkItems(deserializeProgram(serializeProgram(session.getState().program)),{target:'points'}).filter(i=>i.properties.fill==='red').map(i=>i.fields.id);assert.deepEqual(restored,['b']);session.destroy();assert.equal(listeners.size,0);
console.log(JSON.stringify({inputCategories:[1,'1',1],expected,actual,diff:[],restored,immutable:true,listenersAfterDestroy:listeners.size},null,2));
