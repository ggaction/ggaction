import gzip, hashlib, json, pathlib, subprocess
root=pathlib.Path.cwd(); out=root/'agent_docs/impl/roadmap9/interaction/legend-selection-evidence'; out.mkdir(exist_ok=True)
def read(name): return json.loads((root/'.artifacts'/name).read_text())
files=[]
for p in sorted((root/'.artifacts').glob('legend-selection-*')):
    if p.suffix not in ['.log','.mjs','.py']: continue
    data=gzip.compress(p.read_bytes(),mtime=0); dest=out/(p.name+'.gz'); dest.write_bytes(data)
    files.append({'path':dest.name,'sha256':hashlib.sha256(data).hexdigest()})
for name in ['legend-selection-fixed.json','legend-selection-superseded.json','legend-selection-oracle.json','legend-selection-final-package20.json']:
    (out/name).write_bytes((root/'.artifacts'/name).read_bytes())
sources=[x for x in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if x.startswith(('src/','types/'))]
sources+=['src/interaction/legendSelection.js','src/materialization/legendTargets.js']
data={
 'baseCommit':'beb751bf9', 'sourceCommit':None,
 'authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 'scope':'STEP060 C1 categorical legend selection; current-frame samples/labels to native immutable selection and linked closure',
 'sourceHashes':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in sorted(set(sources))},
 'checks':{
  'baseline':33,'sharedInteractionCoverage':{'passed':178,'owners':{'hitGuides.js':[100,95.16,100],'hitProgram.js':[100,95.35,100],'selection.js':[100,99.14,100],'session.js':[100,94.34,100]},'timing':'Before the pure legend-target/overflow relocation; final focused source and exact package checks follow.'},
  'relocatedOwners':324,
  'focusedCriticalCoverage':{'passed':302,'owners':{'grammar/legendOverflow.js':[100,100,100],'interaction/legendSelection.js':[100,93.75,100],'materialization/legendTargets.js':[100,100,100]},'floors':'New critical owners95/90/100; all existing canonical floors unchanged.'},
  'finalSourceTypesBoundariesDiscovery':37,
  'realistic':{'passed':16,'witness':'Five pinned datasets times observations/categories/series with actual categorical legend selection, toggle, typed membership and codec; inventory included.'},
  'browser':{'passed':1,'witness':'Real Canvas and SVG DPR2 legend activation, Escape cancellation, one committed click, remount and no page errors.'},
  'docs':{'initialPassed':46,'initialTotal':47,'refreshedOwning':47,'responsiveAxeWidths':[320,390,768,1440]},
  'installed':[read('legend-selection-final-consumer'+str(v)+'.log') for v in [20,22,24]],
  'installedPublicSnippet':read('legend-selection-final-doc-consumer.log')
 },
 'artifact':read('legend-selection-fixed.json'),
 'supersededArtifact':read('legend-selection-superseded.json'),
 'packageMeasurementNode20':read('legend-selection-final-package20.json'),
 'limits':{'entries':982,'packedBytes':1411000,'unpackedBytes':6415000,'fullGzip':688300,'basicGzip':378000,'interactionGzip':111000,'svgGzip':25000,'graphGzip':44000,'searchBytes':984000},
 'preservedFailures':[
  'Initial test fixture put first-hidden summary on the default swatch; native validation correctly rejected it. The regression uses the supported line recipe.',
  'Fixture symbol and opacity shapes were corrected to the existing nested layers contract; no authoring API changed.',
  'Source boundary rejected an interaction import from actions. Read-only legend target/block resolution moved to materialization, and pure overflow projection to grammar; the action reexports preserve existing callers. No allowlist relaxation.',
  'Initial package and interaction bundle limits were exceeded. Measured source entry growth and max Node20/24 gzip require the recorded minimal limits.',
  'Intermediate focused selection omitted existing overflow error branches. The relevant existing legend suite plus new owner tests measured302 and the unchanged grammar floor passed.',
  'The first source-free docs browser launch used a /var symlink while Vite used /private/var. Realpath consumer root fixed the harness, then the exact final archive example passed.',
  'After final source edits, one of47 docs checks found stale provenance; provenance/machine/LLM regeneration closed47/47.',
  'Archive d5a4933f is superseded by c6d8c8cb after EOF normalization and a generic editing-pointer diagnostic. The final exact archive passed all three Nodes.'
 ],
 'globalCoverage':'Not rerun. Focused changed owners and final public consumers are qualified. The original full integration obligations remain with root.',
 'remaining':['C2 categorical legend visibility and explicit visible-data/all-data scale policy','remaining non-categorical legend interaction requirements','parameter controls/context actions','annotation anchor/offset editing','node drag/partition focus/geo navigation/keyboard','AT35/38/65/80 complete consumer closure','STEP074 integrated qualification and STEP077'],
 'commands':{
  'finalSource':'node --test test/unit/interaction-legend-selection.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js test/contracts/interaction-types.test.js',
  'criticalReproduction':'node --test --experimental-test-coverage --test-coverage-include=src/grammar/legendOverflow.js --test-coverage-include=src/interaction/legendSelection.js --test-coverage-include=src/materialization/legendTargets.js test/unit/interaction-legend-selection.test.js test/unit/materialization/legend-targets.test.js test/unit/actions/guides/*legend*.test.js test/unit/grammar/*legend*.test.js',
  'realistic':'GGACTION_TEST_TIDYTUESDAY_CACHE_ROOT=/Users/hyeonjeon/Projects/ggactionnewbrand/.artifacts/datasets/tidytuesday node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js',
  'browser':'node --test --test-name-pattern="categorical legend clicks" test/browser/interaction-session.browser.js',
  'installed':'Node20/22/24: node .artifacts/legend-selection-consumer.mjs; Node22: node .artifacts/legend-selection-doc-consumer.mjs',
  'docs':'npm run docs:generate; final docs:images; docs:capabilities; docs:provenance; docs:machine; docs:llms; node --test test/docs/documentation.test.js test/docs/documentation-coverage.test.js; npm run docs:build; npm run test:docs:built; node .artifacts/legend-selection-doc-browser.mjs'
 },'evidenceFiles':files
}
(out/'qualification.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
