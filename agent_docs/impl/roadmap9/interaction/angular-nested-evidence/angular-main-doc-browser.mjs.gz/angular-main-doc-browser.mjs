import assert from "node:assert/strict";

import { createServer } from "node:http";
import { mkdir, readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";

import AxeBuilder from "@axe-core/playwright";
import { chromium } from "playwright";

const siteRoot = path.resolve(process.argv[2] ?? "_site");
const artifactRoot = path.resolve(".artifacts/interaction-angular-nested-docs");
const contentTypes = new Map([
  [".css", "text/css"],
  [".html", "text/html"],
  [".js", "text/javascript"],
  [".json", "application/json"],
  [".png", "image/png"],
  [".ts", "text/plain"],
  [".txt", "text/plain"]
]);

function localPath(requestUrl) {
  const parsed = new URL(requestUrl, "http://127.0.0.1");
  let pathname = decodeURIComponent(parsed.pathname);
  if (pathname === "/ggaction") pathname = "/";
  if (pathname.startsWith("/ggaction/")) pathname = pathname.slice("/ggaction".length);
  return pathname;
}

const server = createServer(async (request, response) => {
  try {
    let target = path.join(siteRoot, localPath(request.url));
    if ((await stat(target)).isDirectory()) target = path.join(target, "index.html");
    assert.equal(target.startsWith(siteRoot), true);
    const body = await readFile(target);
    response.writeHead(200, {
      "content-type": contentTypes.get(path.extname(target)) ?? "application/octet-stream"
    });
    response.end(body);
  } catch {
    response.writeHead(404);
    response.end("Not found");
  }
});

await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
const { port } = server.address();
const baseUrl = `http://127.0.0.1:${port}/ggaction/`;
await mkdir(artifactRoot, {recursive:true});
const browser = await chromium.launch({headless:true});
try {
 for (const route of ['api/interaction/','api/appearance/selection-and-highlighting/','api/composition/']) for (const width of [320,390,768,1440]) {
  const context = await browser.newContext({viewport:{width,height:900}});
  const page = await context.newPage();
  await page.goto(baseUrl+route,{waitUntil:'networkidle'});
  await page.locator('h1').waitFor();
  const dims=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,width:innerWidth}));
  assert.ok(dims.scroll <= dims.width+1,JSON.stringify(dims));
  const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
  assert.deepEqual(result.violations.map(v=>({id:v.id,targets:v.nodes.map(n=>n.target)})),[]);
  if(route==='api/interaction/') await page.getByText('Brush or lasso an existing selection',{exact:true}).last().scrollIntoViewIfNeeded();
  await page.screenshot({path:path.join(artifactRoot,route.replaceAll('/','-')+width+'.png')});
  console.log(JSON.stringify({route,width,overflow:false,axeViolations:0}));
  await context.close();
 }
} finally {await browser.close();await new Promise(resolve=>server.close(resolve));}
