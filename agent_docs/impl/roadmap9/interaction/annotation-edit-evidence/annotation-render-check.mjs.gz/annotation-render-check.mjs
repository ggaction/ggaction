import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';import{tmpdir}from'node:os';import path from'node:path';import{execFileSync}from'node:child_process';
import{createCanvas,loadImage}from'@napi-rs/canvas';
import{chart,render}from'../src/index.js';import{renderToSVG}from'../src/renderers/svg.js';import{renderToPNGBuffer}from'../src/renderers/png.js';import{renderToPDFBuffer}from'../src/renderers/pdf.js';
import{createMockCanvasContext}from'../test/support/canvas.js';import{serializeProgram,deserializeProgram}from'../src/persistence.js';
const p=chart().createCanvas({width:400,height:280,margin:20}).createData({values:[{x:2,y:3},{x:8,y:7}]}).createPointMark().encodeX({field:'x',scale:{domain:[0,10]}}).encodeY({field:'y',scale:{domain:[0,10]}}).createAnnotation({id:'note',text:'Original',x:2,y:3,dx:8,dy:-8});
const publicProgram=p.editAnnotation({target:'note',text:'Revised',x:8,y:7,dx:12,dy:-16});
const lower=p.encodeText({target:'note',value:'Revised'}).encodeX({target:'note',datum:8,fieldType:'quantitative',scale:{id:'x'},coordinate:'main'}).encodeY({target:'note',datum:7,fieldType:'quantitative',scale:{id:'y'},coordinate:'main'}).editTextMark({target:'note',dx:12,dy:-16});
const programs=[publicProgram,lower,deserializeProgram(serializeProgram(publicProgram))];
const contexts=programs.map(()=>createMockCanvasContext());programs.forEach((p,i)=>render(p,contexts[i]));
for(const ctx of contexts.slice(1))assert.deepEqual(ctx.calls,contexts[0].calls);
const svg=programs.map(p=>renderToSVG(p,{resourceNamespace:'annotation'}));assert.equal(svg[0],svg[1]);assert.equal(svg[0],svg[2]);
const png=await Promise.all(programs.map(p=>renderToPNGBuffer(p)));assert.deepEqual(png[0].buffer,png[1].buffer);assert.deepEqual(png[0].buffer,png[2].buffer);
const dir=await mkdtemp(path.join(tmpdir(),'annotation-render-'));
try{const pixels=[];for(const [i,p]of programs.entries()){const stem=path.join(dir,String(i));await writeFile(stem+'.pdf',(await renderToPDFBuffer(p)).buffer);execFileSync('pdftoppm',['-r','72','-singlefile','-png',stem+'.pdf',stem]);const image=await loadImage(stem+'.png'),canvas=createCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);pixels.push(Buffer.from(ctx.getImageData(0,0,image.width,image.height).data));}assert.deepEqual(pixels[0],pixels[1]);assert.deepEqual(pixels[0],pixels[2]);}finally{await rm(dir,{recursive:true,force:true});}
console.log('Annotation native public/lower/codec Canvas calls, SVG, exact PNG and exact PDF: PASS');
