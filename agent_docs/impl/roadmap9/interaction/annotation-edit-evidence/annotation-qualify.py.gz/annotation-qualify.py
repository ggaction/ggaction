from pathlib import Path
import gzip,hashlib,json,subprocess,shutil
root=Path('agent_docs/impl/roadmap9/interaction/annotation-edit-evidence');root.mkdir(exist_ok=True)
def j(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
installed=[]
for n in (20,22,24):
 s=Path(f'.artifacts/annotation-consumer{n}.log').read_text()
 installed.append(json.JSONDecoder().raw_decode(s)[0])
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','types'],text=True).splitlines()
h=hashlib.sha256()
for f in sorted(set(files)): h.update(f.encode()+b'\0'+Path(f).read_bytes()+b'\0')
record={
 'parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'sourceCommit':None,
 'authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 'scope':'Full editAnnotation wraps existing Text content, datum anchor, style, placement and layout owners. Explicit annotate dispatch uses the native receiver without a Full static dependency; Basic rejects. No stored schema or renderer changes.',
 'runtimeAndTypesFingerprint':h.hexdigest(),
 'checks':{'interaction':190,'newRegressions':6,'ownerCoverage':{'actions/marks/text/annotation.js':[100,93.55,100],'interaction/selection.js':[100,98.47,100]},'contractsFinal':60,'realistic':{'tests':16,'datasets':5,'recipes':3},'realisticInventory':2,'browser':1,'renderers':'Public editor / native lowered chain / codec: exact Canvas calls and SVG; exact decoded PNG and rasterized PDF pixels.','docs':{'initialPassed':202,'initialTotal':205,'correctedOwningChecks':49,'builtPages':172,'llmArtifacts':1525,'widths':[320,390,768,1440],'axeViolations':0},'installed':installed},
 'artifact':j('.artifacts/annotation-fixed.json'),'packageMeasurementNode20':j('.artifacts/annotation-measure20-final.json'),
 'limits':{'entries':1037,'packedBytes':1476000,'unpackedBytes':6717000,'fullGzip':723800,'basicGzip':382000,'svgGzip':25000,'interactionGzip':112800,'graphGzip':44000,'searchBytes':1023600},
 'preservedFailures':['Initial missing implementation tests failed. Test-only corrections use native geometry text, valid condition schema and explicit categorical scales.','Initial contract run46/48 required catalog lifecycle vocabulary and coverage section; owning11 and final60 passed.','Initial docs202/205: changelog entry and measured search budget1023542 exceeded1021500; corrected owning49 passed. No full205 rerun claimed.','Node20 same archive runtime10 and strictTS passed before Full723738 exceeded723200. Original log preserved; unchanged measured bundles checked against minimum723800 cap; Node22/24 complete exit0.','Initial package1037 entries exceeded1036. Final Node20 packed1475547/unpacked6716141 fit bounded1476000/6717000.'],
 'remaining':['Geographic annotation command routing after stable peer merge','Screen anchor creation, item membership editing and pointer anchor drag','Pointer navigation, general keyboard focus/history and coordinate morph','Full AT35/38/65/80 and STEP074/077'],
 'reusedEvidence':'Native Text geometry/materializers/renderer inputs are unchanged. No new visual primitive. No full normal/coverage or complete installed matrix claimed.',
 'commands':{'interaction':'node --test --experimental-test-coverage --test-coverage-include=src/actions/marks/text/annotation.js --test-coverage-include=src/interaction/selection.js all test/unit/interaction-*.test.js','contracts':'node --test test/contracts/{action-catalog,package-boundaries,action-value-vocabulary,compact-action-cards,interaction-types,source-boundaries,test-discovery}.test.js','realistic':'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned corpus cache','browser':'node scripts/run-tests.js browser browser/interaction-session.browser.js with annotation name filter','renderer':'node .artifacts/annotation-render-check.mjs','installed':'Node20/22/24 node .artifacts/annotation-consumer.mjs; node .artifacts/annotation-cap-check.mjs','docs':'docs:generate; test:docs (202/205); owning documentation checks49; docs:build; test:docs:built; node .artifacts/annotation-doc-browser.mjs'},'evidenceFiles':[]}
for p in sorted(Path('.artifacts').glob('annotation-*')):
 if p.is_file() and p.suffix in ['.log','.mjs','.json','.py']:
  out=root/(p.name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));record['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
for p in sorted(Path('.artifacts/interaction-annotation-docs').glob('*.png')):
 out=root/p.name;shutil.copyfile(p,out);record['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
(root/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
