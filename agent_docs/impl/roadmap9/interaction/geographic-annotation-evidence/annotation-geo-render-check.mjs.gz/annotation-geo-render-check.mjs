import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';import{tmpdir}from'node:os';import path from'node:path';import{execFileSync}from'node:child_process';
import{createCanvas,loadImage}from'@napi-rs/canvas';
import{chart,render}from'../src/index.js';import{renderToSVG}from'../src/renderers/svg.js';import{renderToPNGBuffer}from'../src/renderers/png.js';import{renderToPDFBuffer}from'../src/renderers/pdf.js';
import{createMockCanvasContext}from'../test/support/canvas.js';import{serializeProgram,deserializeProgram}from'../src/persistence.js';
import{createInteractionSession}from'../src/interaction.js';
const p=chart().createCanvas({width:300,height:200,margin:0}).createGeometryData({id:'places',format:'geojson',coordinateKind:'planar',featureKey:'id',values:{type:'Feature',id:1,properties:{},geometry:{type:'Point',coordinates:[80,90]}}}).createProjection({id:'map',type:'identity'}).createCoordinate({type:'geo'}).createGeoAnnotation({id:'note',anchor:{type:'position',position:[20,30]},text:'Original'});
const payload={anchor:{type:'feature',geometry:'places',key:1},text:'Port',dx:8,dy:-12};
const session=createInteractionSession({program:p,bindings:[]});session.dispatch({type:'annotate',target:'note',payload});const publicProgram=session.getState().program;session.destroy();
const lower=p.editGeoAnnotation({target:'note',...payload});
const programs=[publicProgram,lower,deserializeProgram(serializeProgram(publicProgram))];
const contexts=programs.map(()=>createMockCanvasContext());programs.forEach((p,i)=>render(p,contexts[i]));
for(const ctx of contexts.slice(1))assert.deepEqual(ctx.calls,contexts[0].calls);
const svg=programs.map(p=>renderToSVG(p,{resourceNamespace:'annotation'}));assert.equal(svg[0],svg[1]);assert.equal(svg[0],svg[2]);
const png=await Promise.all(programs.map(p=>renderToPNGBuffer(p)));assert.deepEqual(png[0].buffer,png[1].buffer);assert.deepEqual(png[0].buffer,png[2].buffer);
const dir=await mkdtemp(path.join(tmpdir(),'annotation-render-'));
try{const pixels=[];for(const [i,p]of programs.entries()){const stem=path.join(dir,String(i));await writeFile(stem+'.pdf',(await renderToPDFBuffer(p)).buffer);execFileSync('pdftoppm',['-r','72','-singlefile','-png',stem+'.pdf',stem]);const image=await loadImage(stem+'.png'),canvas=createCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);pixels.push(Buffer.from(ctx.getImageData(0,0,image.width,image.height).data));}assert.deepEqual(pixels[0],pixels[1]);assert.deepEqual(pixels[0],pixels[2]);}finally{await rm(dir,{recursive:true,force:true});}
console.log('Geographic annotation session/native/codec Canvas calls, SVG, exact PNG and exact PDF: PASS');
