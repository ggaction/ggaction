from pathlib import Path
import subprocess,json,re
def readrev(stage,p): return subprocess.check_output(['git','show',f':{stage}:{p}'],text=True)
conflicts=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines()
canonical={'CHANGELOG.md','agent_docs/SECOND_ARCHITECTURE.md','docs/_data/snippet_cases.json','knowledge/action-intents.json','scripts/coverage-policy.js','scripts/browser-bundle-size.js','scripts/package-artifact.js','scripts/generate-doc-search-index.js'}
for p in conflicts:
 if p not in canonical: Path(p).write_text(readrev(2,p))
for p in ['scripts/package-artifact.js','scripts/generate-doc-search-index.js']:
 Path(p).write_text(readrev(2,p))
Path('scripts/browser-bundle-size.js').write_text(readrev(3,'scripts/browser-bundle-size.js'))
for p in ['CHANGELOG.md','scripts/coverage-policy.js']:
 s=Path(p).read_text();s=re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> [^\n]+\n',lambda m:m[1]+m[2],s,flags=re.S);Path(p).write_text(s)
p=Path('agent_docs/SECOND_ARCHITECTURE.md');s=p.read_text();n=[0]
def arch(m):
 n[0]+=1
 return m[2] if n[0]==1 else m[1]+'\n'+m[2]
s=re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> [^\n]+\n',arch,s,flags=re.S);p.write_text(s)
p='docs/_data/snippet_cases.json';a=json.loads(readrev(2,p));b=json.loads(readrev(3,p));ids={v['id'] for v in a};a.extend(v for v in b if v['id'] not in ids);Path(p).write_text(json.dumps(a,indent=2)+'\n')
def merge(a,b,base):
 if a==b or b==base:return a
 if a==base:return b
 if isinstance(a,dict) and isinstance(b,dict):
  out=dict(a)
  for k,v in b.items():out[k]=merge(a[k],v,base.get(k) if isinstance(base,dict) else None) if k in a else v
  return out
 raise RuntimeError('Unexpected non-additive JSON conflict')
p='knowledge/action-intents.json';a,b,base=[json.loads(readrev(i,p)) for i in [2,3,1]];Path(p).write_text(json.dumps(merge(a,b,base),indent=2)+'\n')
