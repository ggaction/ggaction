from pathlib import Path
import gzip, hashlib, json, subprocess, shutil
root=Path('agent_docs/impl/roadmap9/interaction/annotation-drag-evidence');root.mkdir(exist_ok=True)
def j(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','types'],text=True).splitlines();h=hashlib.sha256()
for f in sorted(set(files)): h.update(f.encode()+b'\0'+Path(f).read_bytes()+b'\0')
r={'parent':'af2891a016f4d39e64fb6eeb8d8d73ec668ad3d7','sourceCommit':None,'authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 'scope':'Annotation pointer binding reuses native dx/dy editors while preserving screen/data/plot/item/feature anchors. The explicit layer is the edit unit. Node and annotation reuse one bounded committed-frame/coordinate owner; session preview and exact hit frame share the same native materialization. No stored schema or renderer changes.',
 'runtimeAndTypesFingerprint':h.hexdigest(),
 'checks':{'focusedNodeAndAnnotation':18,'interactionTypesDiscoveryBoundary':228,
 'ownerCoverage':{'interaction/annotationMovement.js':[100,91.43,100],'interaction/movementFrame.js':[100,93.33,100],'interaction/nodeMovement.js':[100,93.33,100],'interaction/session.js':[100,95.95,100]},
 'realistic':{'tests':16,'datasets':5,'recipes':3},'browser':{'tests':3,'realInput':['mouse drag','touch drag','Escape cancellation','keyboard host command'],'dpr':2},
 'renderers':'Actual drag result versus independent literal native Text and codec: exact Canvas calls, SVG, PNG buffers and rasterized PDF pixels.',
 'docs':{'source':207,'builtPages':172,'llmArtifacts':1531,'routes':['api/interaction/'],'widths':[320,390,768,1440],'axeViolations':0,'visualReuse':'Same documentation layout and controls; E8 mobile layout inspection remains valid. Current viewport screenshots and browser interactions are preserved.'},
 'installed':[json.JSONDecoder().raw_decode(Path(f'.artifacts/annotation-drag-consumer{n}.log').read_text())[0] for n in (20,22,24)]},
 'artifact':j('.artifacts/annotation-drag-fixed.json'),'packageMeasurementNode20':j('.artifacts/annotation-drag-measure20-initial.json'),
 'limits':{'entries':1047,'packedBytes':1485000,'unpackedBytes':6760000,'fullGzip':729300,'basicGzip':384500,'svgGzip':25000,'interactionGzip':113500,'graphGzip':44000,'searchBytes':1027500},
 'preservedFailures':['Initial tests omitted required projection id, inspected a nonexistent scene-node identity field and encoded an offset on a source-owned rather than independent Text. Corrected fixtures use explicit native owners.',
 'The overflow fixture expected an error after RAF, but current pointer-coordinate mapping rejects a noninvertible/overflow point earlier and cancels the gesture. Assert exact cancel, zero commit and original program instead.',
 'Node20 same-tar13 runtime and strictTS passed before interaction113413>113000 ceiling failed. Final owning cap113500 rechecks the same measured archive. Node22 and24 commands exit0; no fresh Node20 runtime rerun is claimed.'],
 'remaining':['General history, reset, focus and multi-binding gesture arbitration','Geographic navigation/session camera and animation-player integration','Full AT35/38/65/80 and STEP065-077 closure'],
 'commands':{'focused':'node --test --experimental-test-coverage --test-coverage-include=src/interaction/annotationMovement.js --test-coverage-include=src/interaction/movementFrame.js --test-coverage-include=src/interaction/nodeMovement.js test/unit/interaction-annotation-drag.test.js test/unit/interaction-node-move.test.js',
 'cross':'node --test --experimental-test-coverage --test-coverage-include=src/interaction/session.js --test-coverage-include=src/interaction/annotationMovement.js --test-coverage-include=src/interaction/movementFrame.js --test-coverage-include=src/interaction/nodeMovement.js test/unit/interaction-*.test.js test/contracts/interaction-types.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js',
 'realistic':'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned corpus cache',
 'browser':'node --test --test-name-pattern="canonical annotation dragging|canonical annotation buttons|screen annotation controls" test/browser/interaction-session.browser.js',
 'render':'node .artifacts/annotation-drag-render-check.mjs','installed':'Node20/22/24 node .artifacts/annotation-drag-consumer.mjs; node .artifacts/annotation-drag-cap-recheck.mjs',
 'docs':'docs:generate; test:docs; docs:build; test:docs:built; node .artifacts/annotation-drag-doc-browser.mjs; source-pinned owning docs'},
 'reusedEvidence':'The source is frozen across focused/cross/browser/realistic/render/installed checks. Package and bundle limit updates change no archived runtime input. No full normal/coverage or full installed sweep claimed.','evidenceFiles':[]}
for p in sorted(Path('.artifacts').glob('annotation-drag-*')):
 if p.is_file() and p.suffix in ['.log','.mjs','.json','.py']:
  out=root/(p.name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
for p in sorted(Path('.artifacts/interaction-annotation-drag-docs').glob('*.png')):
 out=root/p.name;shutil.copyfile(p,out);r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
(root/'qualification.json').write_text(json.dumps(r,indent=2)+'\n')
