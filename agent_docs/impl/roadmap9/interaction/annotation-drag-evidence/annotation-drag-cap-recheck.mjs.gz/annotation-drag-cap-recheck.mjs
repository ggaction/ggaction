import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {BROWSER_BUNDLE_GZIP_LIMITS} from '../scripts/browser-bundle-size.js';
const text=await readFile('.artifacts/annotation-drag-consumer20.log','utf8');
const result=JSON.parse(text.slice(0,text.indexOf('\nnode:internal')));
for(const item of result.bundles)assert.ok(item.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[item.specifier]);
console.log(JSON.stringify({node:result.node,artifact:result.artifact,bundles:result.bundles,limits:BROWSER_BUNDLE_GZIP_LIMITS,status:'passed',reuse:'Unchanged archive and measurement; only measured ceilings changed after preserved initial failure.'},null,2));
