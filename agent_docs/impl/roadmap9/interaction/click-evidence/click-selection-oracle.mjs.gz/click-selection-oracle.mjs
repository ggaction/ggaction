import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chart } from '../src/index.js';
import { createInteractionSession } from '../src/interaction.js';
import { serializeProgram } from '../src/persistence.js';
import { resolveStoredSelection } from '../src/materialization/selection/state.js';
const source=chart().createCanvas({width:300,height:200,margin:0})
 .createData({id:'rows',keyField:'id',values:[{id:'a',x:50,y:60},{id:'b',x:50,y:60},{id:'c',x:200,y:130}]})
 .createPointMark({id:'points'}).encodePointRadius({value:8})
 .encodeX({field:'x',scale:{domain:[0,300],range:[0,300]}})
 .encodeY({field:'y',scale:{domain:[0,200],range:[0,200]}})
 .selectMarks({id:'picked',target:'points',items:[]});
const before=serializeProgram(source),actual=[];
for (const mode of ['replace','toggle']) {
 const listeners=new Set(),surface={getBoundingClientRect:()=>({left:10,top:20,width:300,height:200}),addEventListener:(type,fn)=>listeners.add(fn),removeEventListener:(type,fn)=>listeners.delete(fn)};
 const session=createInteractionSession({program:source,bindings:[{type:'select',target:'points',selection:'picked',mode}]}),events=[];
 session.mount(surface);session.subscribe(event=>events.push([event.type,event.phase,event.origin]));
 const states=[];
 for (const point of [[50,60],[50,60],[280,180],[200,130]]) {
  for (const listener of [...listeners]) listener({clientX:point[0]+10,clientY:point[1]+20,button:0});
  const s=session.getState(),resolved=resolveStoredSelection(s.program,'picked');states.push({revision:s.revision,selected:resolved.items.filter(item=>resolved.keys.includes(item.key)).map(item=>item.fields.id)});
 }
 actual.push({mode,states,events});session.destroy();assert.equal(listeners.size,0);
}
const pair = type => [[type,'commit','user'],[type,'settled','user']];
const expected=[
 {mode:'replace',states:[{revision:1,selected:['b']},{revision:1,selected:['b']},{revision:2,selected:[]},{revision:3,selected:['c']}],events:[...pair('select'),...pair('clearSelection'),...pair('select'),['destroy',undefined,undefined]]},
 {mode:'toggle',states:[{revision:1,selected:['b']},{revision:2,selected:[]},{revision:2,selected:[]},{revision:3,selected:['c']}],events:[...pair('select'),...pair('select'),...pair('select'),['destroy',undefined,undefined]]}
];
assert.deepEqual(actual,expected);
const result={input:{points:[['a',50,60],['b',50,60],['c',200,130]],clicks:[[50,60],[50,60],[280,180],[200,130]],onMiss:'clear'},expected,actual,diff:[],sourceUnchanged:serializeProgram(source)===before};
await writeFile(new URL('./click-selection-expected-actual-diff.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log('Literal selection/revision/event oracle passed; original immutable.');
assert.equal(serializeProgram(source),before);
