import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const root='agent_docs/impl/roadmap9/interaction/arbitration-evidence';fs.mkdirSync(root,{recursive:true});
const read=f=>fs.readFileSync(f,'utf8');
const json=f=>{const s=read(f),start=s.indexOf('{'),end=s.indexOf('\n}\n',start)+2;return JSON.parse(s.slice(start,end||undefined));};
const sha=b=>createHash('sha256').update(b).digest('hex');
const h=createHash('sha256');for(const f of execFileSync('git',['ls-files','src','types'],{encoding:'utf8'}).trim().split('\n').sort()){h.update(f+'\0');h.update(fs.readFileSync(f));h.update('\0');}
const record={
 sourceCommit:execFileSync('git',['rev-parse','d74d66a6a'],{encoding:'utf8'}).trim(),parent:'77be2b6910b31a9f6323c2a1fbfdc96800d121ec',authorization:'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 scope:'Editing bindings reuse existing normalized gesture priorities and explicit modifier conjunctions. Read-only domain applicability probes choose exactly one transaction and shared pointer capture. The winner survives modifier changes; only the same navigation viewport accepts a second pointer. No new renderer, persisted schema, geometry policy or animation import.',
 runtimeAndTypesFingerprint:h.digest('hex'),
 checks:{focused:324,newArbitrationCases:9,critical:json('.artifacts/session-arbitration-critical.json'),
 realistic:{tests:16,datasets:5,recipes:3},
 browser:{tests:3,canonicalFragment:'Combine editing gestures',actualCanvasAndSvg:true,labelDragShiftBrushClickEscape:true,nativeMapWheelPinchAndGlobeRegression:true,viewportDeviceScaleFactor:2,rendererPixelRatio:2},
 docsAndBoundaries:55,sourcePinnedDocs:49,manifestPolicy:2,
 built:{pages:172,llmArtifacts:1535,widths:[320,390,768,1440],axeViolations:0,overflow:false,manualInspection:'320px and1440px arbitration prose and contained executable example inspected after source pin.'},
 installed:[json('.artifacts/session-arbitration-consumer20-budget.log'),json('.artifacts/session-arbitration-consumer22.log'),json('.artifacts/session-arbitration-consumer24.log')]},
 artifact:json('.artifacts/session-arbitration-fixed.json'),packageNode20Measurement:json('.artifacts/session-arbitration-measure20-final.json'),
 limits:{entries:1061,packedBytes:1506000,unpackedBytes:6847000,fullGzip:732400,basicGzip:386100,interactionGzip:121000,graphGzip:44100,searchBytes:1038300},
 preservedFailures:[
 'Initial source refactor omitted a local scene binding and the final-up click movement cancellation branch. Existing lifecycle regressions detected both; final324 owner/cross-boundary tests passed.',
 'Former one-editing-binding rejection tests were replaced with the current exact equal-priority ambiguity rejection. Differently ranked or disjoint-modifier adapters now coexist intentionally.',
 'Initial docs50/55 detected stale source provenance and LLM output after final runtime edits, plus generated search1038216>1037700. Canonical generators and measured cap1038300 resolved all55; source-pinned49 followed.',
 'Initial canonical package validation failed entries1061>1060. A read-only copy of the canonical inspector measured Node20 1061/1505994/6846835; canonical Node22 pack passed with minimum caps1061/1506000/6847000. Measurement alone is not reported as validation.',
 'Node20 same-tar21runtime and strict types passed; interaction120959gzip exceeded120000. Only the cap changed to121000 and the same measured bundles were revalidated. Node22/24 independently passed21runtime/types/fivebundles. Initial exit1 is preserved.'
 ],
 reusedEvidence:'The final324 source checks and3 actual browser flows include the second-pointer viewport guard. The16 realistic source tests ran before that last guard; their single-pointer selection input does not use the changed joinCandidate path. Existing rendering, native camera math and asset preparation remain unchanged. No whole repository sweep, complete installed suite or public animation integration is claimed.',
 remaining:['Public animation current-frame preparation and camera integration','Combined AT40/41 worker/session/player closure','Accessible keyboard focus and nonvisual semantic data','Resize/reorder gesture adapters from the original STEP058 contract','STEP074-077 overall qualification'],
 commands:{focused:'node --test --experimental-test-coverage --test-coverage-include=src/interaction/session.js --test-coverage-include=src/interaction/pointerBindings.js --test-coverage-include=src/interaction/pointerCapture.js --test-coverage-include=src/interaction/gestures.js test/unit/interaction-*.test.js test/unit/gesture-controller.test.js test/contracts/interaction-types.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js',realistic:'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned TidyTuesday cache',browser:'node --test --test-name-pattern="canonical editing arbitration|canonical map navigation|rotation navigation" test/browser/interaction-session.browser.js',installed:'Node20/22/24 node .artifacts/session-arbitration-consumer.mjs using same1a470b78 tar; Node20 cap-only verification is separate',docs:'docs:generate; docs:preflight; owning49+packageboundaries6; source pin provenance/machine/llms; owning49; build/built; targeted4width browser/Axe'},
 evidenceFiles:[]
};
for(const name of fs.readdirSync('.artifacts').filter(n=>n.startsWith('session-arbitration-')&&/\.(log|mjs|json)$/.test(n)).sort()){
 const body=gzipSync(fs.readFileSync('.artifacts/'+name)),out=name+'.gz';fs.writeFileSync(root+'/'+out,body);record.evidenceFiles.push({path:out,sha256:sha(body)});
}
for(const name of fs.readdirSync('.artifacts/interaction-arbitration-docs').filter(n=>n.endsWith('.png')).sort()){
 const body=fs.readFileSync('.artifacts/interaction-arbitration-docs/'+name);fs.writeFileSync(root+'/'+name,body);record.evidenceFiles.push({path:name,sha256:sha(body)});
}
fs.writeFileSync(root+'/qualification.json',JSON.stringify(record,null,2)+'\n');
