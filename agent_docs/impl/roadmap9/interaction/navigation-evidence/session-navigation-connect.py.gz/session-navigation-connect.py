from pathlib import Path
p=Path('src/interaction/session.js');s=p.read_text();s='import { normalizeCameraNavigation, resolveCameraNavigation, prepareCameraNavigation, joinCameraNavigation, cameraNavigationDraft, navigationCenter, cameraWheelCommand, cameraKeyboardCommand } from "./cameraNavigation.js";\n'+s
s=s.replace('nodes = [], annotations = [];','nodes = [], annotations = [], navigation = [];')
s=s.replace('"effect", "scaleDomain"], "Interaction binding"','"effect", "scaleDomain", "scaleExtent", "initial", "rotationStepDeg"], "Interaction binding"')
s=s.replace('(head.type === "annotate" ? annotations', '(head.type === "navigate" ? navigation : head.type === "annotate" ? annotations')
s=s.replace('nodes.length + annotations.length > 1','nodes.length + annotations.length + navigation.length > 1')
s=s.replace('return { annotation: annotations.length', 'return { navigation: navigation.length ? normalizeCameraNavigation(program, navigation[0]) : undefined, annotation: annotations.length')
s=s.replace('const prepareEdit = command => {\n    let prepared = prepareInteractionEdit(program, prepareNearestSelection(program, command, bridge));','const prepareEdit = (command, native) => {\n    let prepared = native ?? prepareInteractionEdit(program, prepareNearestSelection(program, command, bridge));')
s=s.replace('(configured.node || configured.annotation)', '(configured.node || configured.annotation || configured.navigation)')
s=s.replace('if (configured.annotation) resolveAnnotationMovement(linked.program, configured.annotation, true);','if (configured.annotation) resolveAnnotationMovement(linked.program, configured.annotation, true);\n    if (configured.navigation) resolveCameraNavigation(linked.program, configured.navigation, true);')
s=s.replace('if (configured.region || configured.node || configured.annotation) {','if (configured.region || configured.node || configured.annotation || configured.navigation) {')
s=s.replace('const binding = configured.region ?? configured.node ?? configured.annotation, moving = binding.type === "moveNode" || binding.type === "annotate", eventType = moving ? binding.type : "select";','const binding = configured.region ?? configured.node ?? configured.annotation ?? configured.navigation, navigating = binding.type === "navigate", moving = navigating || binding.type === "moveNode" || binding.type === "annotate", eventType = navigating ? "setViewport" : moving ? binding.type : "select";')
s=s.replace('const result = (moving ? movement.command : regionGestureCommand)(token.context, token.points);\n              const command = interactionTransaction(result.command, token.transactionId), draft = prepareEdit(command);\n              previewProgram = moving ? draft.prepared.program : materializeRegisteredSelectionPreview(draft?.prepared.program ?? program, result.overlay);\n              if (moving) { nextInteger(nextInteger(draft.frame.version)); bridge.updateFrame(draft.frame); token.previewed = true; lastHit = null; }','const result = navigating ? cameraNavigationDraft(token.context, token.pointers) : (moving ? movement.command : regionGestureCommand)(token.context, token.points);\n              const command = interactionTransaction(result.command, token.transactionId), draft = prepareEdit(command, result.prepared);\n              previewProgram = moving ? draft?.prepared.program ?? program : materializeRegisteredSelectionPreview(draft?.prepared.program ?? program, result.overlay);\n              if (moving && draft) { nextInteger(nextInteger(draft.frame.version)); bridge.updateFrame(draft.frame); token.previewed = true; lastHit = null; }')
s=s.replace('binding: { id: "selection", kind: binding.type },','binding: { id: "selection", kind: navigating ? "pan" : binding.type, ...(navigating ? { pinch: true } : {}) },')
s=s.replace('const context = moving ? movement.prepare(program, binding, base, scene, transform, point, bridge.hit(point, { slop: 0 }))','const context = navigating ? prepareCameraNavigation(program, binding, base, scene, transform, point) : moving ? movement.prepare(program, binding, base, scene, transform, point, bridge.hit(point, { slop: 0 }))')
s=s.replace('sample: (token, point) => {\n                const previous', 'join: navigating ? (token, pointers) => { token.context = joinCameraNavigation(token.context, pointers); } : undefined,\n              sample: (token, point) => {\n                if (navigating) return;\n                const previous')
s=s.replace('preview: token => {\n                if (token.raf', 'preview: (token, pointers) => {\n                if (navigating) token.pointers = pointers;\n                if (token.raf')
s=s.replace('drag: (token, _point, _pointerType, gestureKind) => {','drag: (token, _point, _pointerType, gestureKind, pointers) => {\n                if (navigating) token.pointers = pointers;')
s=s.replace('result = preview(token);\n                  discard(token, false);','result = preview(token);\n                  // Asset preparation may defer the final commit; its displayed\n                  // baseline must be the committed frame throughout that wait.\n                  discard(token, navigating);')
s=s.replace('return edit(result.command, result.draft);','if (navigating && result.draft === null) { publish(eventType, details(token, "cancel", [{ code: "gesture-cancelled", message: "movement" }])); return outcome("unchanged"); }\n                return edit(result.command, result.draft);')
marker='''          if (configured.select) {
            const binding = configured.select, eventType'''
insert='''          if (configured.navigation) {
            const binding = configured.navigation;
            const navigate = (event, wheel) => {
              if (destroyed || mounted !== lease || (!wheel && (event.altKey || event.ctrlKey || event.metaKey))) return;
              if (!wheel && !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "+", "=", "-", "_", "Home"].includes(event.key)) return;
              const point = wheel ? pointerCoordinates(element, event, transform).screenPoint : navigationCenter(base, binding.target, transform);
              perform(() => {
                if (destroyed || mounted !== lease) return outcome("stale");
                lease.capture.cancel("movement");
                const context = prepareCameraNavigation(program, binding, base, bridge.getState().scene, transform, point);
                if (!context) return outcome("unchanged");
                const command = wheel ? cameraWheelCommand(context, event.deltaY, event.deltaMode, element.getBoundingClientRect().height) : cameraKeyboardCommand(context, event.key);
                if (!command) return outcome("unchanged");
                event.preventDefault();
                transactionSequence = nextInteger(transactionSequence);
                return edit(interactionTransaction(command, `interaction-${transactionSequence}`));
              });
            };
            for (const [type, listener] of [["wheel", event => navigate(event, true)], ["keydown", event => navigate(event, false)]]) {
              lease.listeners.push([type, listener]); element.addEventListener(type, listener, { passive: false });
            }
          }
          if (configured.select) {
            const binding = configured.select, eventType'''
assert marker in s;s=s.replace(marker,insert)
p.write_text(s)
p=Path('src/interaction/cameraNavigation.js');s=p.read_text().replace('if (!delta) return null;','if (!Array.isArray(delta)) return null;');p.write_text(s)
