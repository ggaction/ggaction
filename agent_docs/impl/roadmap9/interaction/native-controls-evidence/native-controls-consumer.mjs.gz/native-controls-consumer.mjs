import assert from 'node:assert/strict';import fs from 'node:fs/promises';import path from 'node:path';
import {build} from 'vite';import {chromium} from 'playwright';import AxeBuilder from '@axe-core/playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';import {prepareTutorials} from '../scripts/tutorial-consumer.js';import {documentationPrograms} from '../scripts/doc-snippets.js';
import {startStaticServer} from '../test/support/static-server.js';import {openBrowserPage,assertNoBrowserErrors,closeBrowserWithEvidence} from '../test/support/browser.js';
const artifact=JSON.parse(await fs.readFile('.artifacts/keyboard-focus-fixed.json','utf8')),consumer=await preparePackageConsumer({packageSpec:artifact.file});let server,browser;
try{
 const directory=await fs.realpath(consumer.directory),examples=(await documentationPrograms()).filter(e=>['interaction-native-controls','interaction-parameter-context','interaction-node-movement'].includes(e.id));
 const {inputs,consumers}=await prepareTutorials(directory,{examples});
 for(const c of consumers){const session=c.id==='interaction-native-controls'?'controlSession':c.id==='interaction-node-movement'?'nodeSession':'parameterSession';await fs.appendFile(path.join(directory,'tutorials',c.name,'main.js'),`\nwindow.__controls=${session};`);}
 const result=await build({root:directory,configFile:false,logLevel:'silent',build:{rollupOptions:{input:inputs},outDir:'dist'}});
 const modules=[...new Set(result.output.filter(e=>e.type==='chunk').flatMap(e=>Object.keys(e.modules)))];assert.equal(modules.some(p=>p.includes('/roadmap9-paints/')),false);
 server=await startStaticServer(path.join(directory,'dist'));browser=await chromium.launch({headless:true});const context=await browser.newContext({hasTouch:true,viewport:{width:1000,height:900}});
 try{for(const c of consumers){const{page,errors}=await openBrowserPage(context,new URL(`tutorials/${c.name}/`,server.baseUrl).href,{waitFor:()=>window.__ggactionSnippetCompleted});
  if(c.id==='interaction-native-controls'){
   await page.locator('#choose-a').focus();await page.keyboard.press('Enter');assert.equal(await page.locator('#control-summary').textContent(),'A: 2, selected; B: 5');
   for(const id of ['hide-a','only-b','show-a'])await page.locator('#'+id).tap();assert.equal(await page.locator('#control-summary').textContent(),'B: 5');
   await page.locator('#clear-filter').tap();assert.equal(await page.locator('#control-summary').textContent(),'A: 2, selected; B: 5');
   await page.locator('#reset-control').focus();await page.keyboard.press('Space');assert.equal(await page.locator('#control-summary').textContent(),'A: 2; B: 5');
  }else if(c.id==='interaction-node-movement'){
   await page.locator('#node-right').focus();await page.keyboard.press('Enter');assert.equal(await page.locator('output').textContent(),'First node: 90, 90');
   await page.locator('#node-second-right').tap();assert.equal(await page.locator('#node-second-right').textContent(),'Move second node right (230, 160)');
  }else{
   const range=page.getByRole('slider',{name:'Multiplier'});await range.focus();await page.keyboard.press('ArrowRight');assert.equal(await range.inputValue(),'2');
   await page.locator('#open-context').tap();assert.equal(await page.evaluate(()=>document.activeElement.id),'select-context');await page.keyboard.press('Space');assert.equal(await page.evaluate(()=>document.activeElement.id),'multiplier');assert.equal(await page.evaluate(()=>window.__controls.getState().history.undoCount),2);
  }
  assertNoBrowserErrors(errors,c.id);await page.close();}
 }finally{await context.close();}
 console.log(JSON.stringify({node:process.version,artifact:artifact.sha256,sourceFree:true,actualChromium:true,modules:modules.length,examples:consumers.map(c=>({id:c.id,sha256:c.sha256,htmlSha256:c.htmlSha256})),keyboard:true,touch:true,nativeSelection:true,visibilityFilterCoexistence:true,contextActionWithoutHover:true}));
}finally{if(browser)await closeBrowserWithEvidence(browser);await server?.close();await consumer.cleanup();}
