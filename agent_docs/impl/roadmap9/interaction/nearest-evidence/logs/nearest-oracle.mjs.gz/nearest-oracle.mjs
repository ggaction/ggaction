import {chart} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const original=chart().createCanvas({width:200,height:160,margin:0})
.createData({id:'rows',keyField:'id',values:[{id:'a',x:50,y:60},{id:'b',x:100,y:100}]})
.createPointMark({id:'points'}).encodePointRadius({value:8})
.encodeX({field:'x',scale:{domain:[0,200],range:[0,200]}}).encodeY({field:'y',scale:{domain:[0,160],range:[0,160]}})
.selectMarks({id:'picked',items:[]}).highlightMarks({selection:'picked',color:'red',dimOthers:false,bringToFront:false});
const snapshot=serializeProgram(original),session=createInteractionSession({program:original,bindings:[]}),phases=[],selections=[];
session.subscribe(e=>{if(e.phase)phases.push(e.phase)});
const ids=p=>getMarkItems(p,{target:'points'}).filter(item=>item.properties.fill==='red').map(item=>item.fields.id);
for(const nearest of [{space:'screen',point:{x:63,y:60},maxDistance:6},{space:'data',fields:['x','y'],values:[98,101],metric:'manhattan',maxDistance:3},{space:'screen',point:{x:1000,y:1000},maxDistance:1}]){
 session.dispatch({type:'select',target:'points',payload:{id:'picked',nearest}});selections.push(ids(session.getState().program));
}
const actual={selections,restored:ids(deserializeProgram(serializeProgram(session.getState().program))),originalUnchanged:serializeProgram(original)===snapshot,phases,revision:session.getState().revision};
const expected={selections:[['a'],['b'],[]],restored:[],originalUnchanged:true,phases:['commit','settled','commit','settled','commit','settled'],revision:3};
const diff=Object.keys(expected).filter(key=>JSON.stringify(expected[key])!==JSON.stringify(actual[key]));
console.log(JSON.stringify({expected,actual,diff},null,2));session.destroy();if(diff.length)process.exitCode=1;
