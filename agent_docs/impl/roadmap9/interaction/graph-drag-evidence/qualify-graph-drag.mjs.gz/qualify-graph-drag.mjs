import assert from 'node:assert/strict';
import {documentationPrograms} from '../scripts/doc-snippets.js';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {testOptionalDependencies} from '../scripts/consumers/optional-peers.js';
import {root,run,tscCommand} from '../scripts/consumers/runtime.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../scripts/browser-bundle-size.js';
const packageSpec=path.resolve(process.env.ANIMATION_PACKAGE_SPEC ?? '.artifacts/release/ggaction-0.0.26.tgz');
const measurementOnly=process.env.ANIMATION_MEASURE_BUNDLES==='1';
const bundleOnly=process.env.ANIMATION_BUNDLE_ONLY==='1';
const tag=process.versions.node.split('.')[0]+(bundleOnly?'-bundle-final':measurementOnly?'-measure':''),directory=path.resolve('.artifacts/graph-drag-installed/node'+tag);
await mkdir(directory,{recursive:true});
const artifact=await readFile(packageSpec),sha256=createHash('sha256').update(artifact).digest('hex');
const receipt={node:process.version,archive:packageSpec,sha256,records:[]};
const save=()=>writeFile(path.join(directory,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
const consumer=await preparePackageConsumer({packageSpec});
async function check(id,fn){const start=performance.now();try{const value=await fn();receipt.records.push({id,status:'passed',durationMs:performance.now()-start,value});}catch(error){receipt.records.push({id,status:'failed',durationMs:performance.now()-start,error:error.stack});throw error;}finally{await save();}}
try{
 await check('optional-peers',()=>testOptionalDependencies(consumer));
 if(!measurementOnly&&!bundleOnly) {
 await copyFile(path.join(root,'scripts/consumers/fixtures/node/interaction-animation.mjs'),path.join(consumer.directory,'animation.mjs'));
 await writeFile(path.join(consumer.directory,'animation-run.mjs'),`import {cases} from './animation.mjs';for(const entry of cases){await entry.run();console.log(entry.id+' passed');}`);
 await check('interaction-animation-five-public-cases',()=>run(process.execPath,['animation-run.mjs'],consumer.directory,{stdio:'inherit'}));
 await copyFile(path.join(root,'scripts/consumers/fixtures/interaction.ts'),path.join(consumer.directory,'animation.mts'));
 await check('interaction-strict-types',()=>run(process.execPath,[tscCommand,'--noEmit','--strict','--exactOptionalPropertyTypes','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','animation.mts'],consumer.directory));

 }
 for(const specifier of ['ggaction','ggaction/basic','ggaction/svg','ggaction/graph','ggaction/animation','ggaction/interaction']) await check(specifier,async()=>{
   const measurement=await measureMinimalBrowserBundle(consumer.directory,{specifier});if(!measurementOnly)assert.ok(measurement.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier],JSON.stringify(measurement));return measurement;
 });
 if(process.env.SESSION_FRAME_BROWSER==='1') await check('source-free-actual-browser-current-drag',()=>run(process.execPath,['--test','--test-name-pattern=current routed graph drag','test/browser/interaction-animation.browser.js'],root,{stdio:'inherit',env:{...process.env,GGACTION_BROWSER_PACKAGE_DIRECTORY:consumer.directory}}));
 receipt.status=measurementOnly?'measured':'passed';receipt.peers=consumer.resolvedPeers;await save();console.log(JSON.stringify(receipt,null,2));
}finally{await consumer.cleanup();}
