import assert from 'node:assert/strict';
import fs from 'node:fs';
import { invertPositionInterval } from '../src/grammar/scales/inversion.js';
const fixtures = [
 {name:'linear-reversed',scale:{type:'linear',domain:[100,0],range:[200,0]},input:[50,150],expected:{kind:'range',bounds:[25,75]}},
 {name:'log',scale:{type:'log',domain:[1,1000],range:[0,300]},input:[100,200],expected:{kind:'range',bounds:[10,100]}},
 {name:'epoch',scale:{type:'time',domain:[1709078400000,1709337600000],range:[0,300]},input:[100,200],expected:{kind:'range',bounds:[1709164800000,1709251200000]}},
 {name:'band-gap',scale:{type:'band',domain:['a',1,'1',false],range:[0,400],step:100,start:20,bandwidth:60,paddingInner:.4,paddingOuter:.2,align:.5},input:[90,110],expected:{kind:'categories',values:[]}}
];
const cases=fixtures.map(({expected,...fixture})=>{const before=structuredClone(fixture),actual=invertPositionInterval(fixture.scale,fixture.input);assert.deepEqual(actual,expected);assert.deepEqual(fixture,before);return{...fixture,expected,actual,diff:[],immutable:true}});
fs.writeFileSync(new URL('./brush-inversion-expected-actual-diff.json',import.meta.url),JSON.stringify({cases},null,2)+'\n');
console.log('4 literal inverse cases pass; source and inputs unchanged.');
