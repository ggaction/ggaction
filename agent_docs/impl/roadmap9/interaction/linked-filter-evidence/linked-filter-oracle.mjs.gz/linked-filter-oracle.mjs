import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {chart,hconcat} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const child=chart().createCanvas({width:300,height:200}).createData({id:'rows',keyField:'id',values:[{id:'a',x:1,y:3},{id:'b',x:2,y:2},{id:'c',x:3,y:1}]}).createScatterPlot({id:'points',x:'x',y:'y',guides:false}).selectMarks({id:'universe',items:[],empty:'all'});
const program=hconcat({programs:['a','b','c'].map(id=>({id,program:child}))});
const target=id=>({childPath:[id],id:'points'});
const bindings=[['a','b'],['b','c']].map(([from,to])=>({type:'linkFilter',id:to,target:target(to),selection:'universe',resolve:'global',sources:[{target:target(from),selection:'universe',projection:{type:'rows',sourceData:'rows',targetData:'rows'}}]}));
const session=createInteractionSession({program,bindings}),events=[],cases=[],saved=serializeProgram(program);
session.subscribe(e=>{if(e.phase)events.push({phase:e.phase,revision:e.revision,owners:e.affectedOwners.map(owner=>owner.childPath[0])})});
for(const ids of [['a'],['c'],[],['a','b','c']]){
 session.dispatch({type:'select',target:target('a'),payload:{id:'universe',select:{field:'id',op:'oneOf',values:ids}}});
 const p=session.getState().program,actual=['b','c'].map(id=>getMarkItems(p.children[id],{target:'points'}).map(item=>item.fields.id)),expected=[ids,ids];
 cases.push({expected,actual,diff:JSON.stringify(expected)===JSON.stringify(actual)?[]:['membership mismatch'],codecEqual:JSON.stringify(deserializeProgram(serializeProgram(p)).graphicSpec)===JSON.stringify(p.graphicSpec)});
}
const result={cases,events,expectedPhases:Array.from({length:4},()=>['commit','settled']).flat(),sourceImmutable:serializeProgram(program)===saved,revision:session.getState().revision};
await writeFile('.artifacts/linked-filter-expected-actual-diff.json',JSON.stringify(result,null,2)+'\n');
assert.ok(cases.every(c=>!c.diff.length&&c.codecEqual));assert.deepEqual(events.map(e=>e.phase),result.expectedPhases);assert.equal(result.sourceImmutable,true);assert.equal(result.revision,4);session.destroy();
