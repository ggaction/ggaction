import assert from 'node:assert/strict';
import fs from 'node:fs';
import {chart} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const p=chart().createCanvas({width:200,height:200,margin:0}).createData({values:[{id:'a',x:0,y:0},{id:'b',x:5,y:5},{id:'c',x:10,y:10}],keyField:'id'}).createScatterPlot({id:'points',x:{field:'x',scale:{domain:[0,10]}},y:{field:'y',scale:{domain:[0,10]}},guides:false}).selectMarks({id:'picked',target:'points',items:[]}).highlightMarks({selection:'picked',color:'red',bringToFront:false,dimOthers:false});
const selected=p=>getMarkItems(p,{target:'points'}).filter(i=>i.properties.fill==='red').map(i=>i.fields.id);
const before=serializeProgram(p),cases=[];
for(const type of ['brush','lasso']){
 const session=createInteractionSession({program:p,bindings:[{type,target:'points',selection:'picked'}]});const listeners=new Map(),capture=new Set();let scheduled;
 const host={getBoundingClientRect:()=>({left:0,top:0,width:200,height:200}),addEventListener:(t,f)=>listeners.set(t,f),removeEventListener:t=>listeners.delete(t),setPointerCapture:i=>capture.add(i),releasePointerCapture:i=>capture.delete(i),hasPointerCapture:i=>capture.has(i),requestAnimationFrame:f=>(scheduled=f,1),cancelAnimationFrame:()=>{scheduled=undefined;}};
 const phases=[];session.subscribe(e=>{if(e.phase)phases.push(e.phase)});session.mount(host);
 const fire=(t,x,y)=>listeners.get(t)({clientX:x,clientY:y,pointerId:1,pointerType:'mouse'});
 fire('pointerdown',50,50);if(type==='lasso')fire('pointermove',150,50);fire('pointermove',150,150);if(type==='lasso')fire('pointermove',50,150);
 const flush=scheduled;scheduled=undefined;flush();const preview=selected(session.getState().previewProgram);assert.equal(session.getState().program,p);
 fire('pointerup',type==='brush'?150:50,150);const next=session.getState().program;
 const options=next.semanticSpec.resources.find(r=>r.id==='picked').options;
 const actual={preview,committed:selected(next),restored:selected(deserializeProgram(serializeProgram(next))),phases,revision:session.getState().revision,previewCleared:session.getState().previewProgram===null,captureReleased:capture.size===0,baselineUnchanged:serializeProgram(p)===before,...(type==='brush'?{region:options.predicate.region}:{polygon:options.screenPolygon})};
 const expected={preview:['b'],committed:['b'],restored:['b'],phases:['preview','preview','commit','settled'],revision:1,previewCleared:true,captureReleased:true,baselineUnchanged:true,...(type==='brush'?{region:{x:{ranges:[{min:2.5,max:7.5,minInclusive:true,maxInclusive:true}]},y:{ranges:[{min:2.5,max:7.5,minInclusive:true,maxInclusive:true}]}}}:{polygon:[{x:50,y:50},{x:150,y:50},{x:150,y:150},{x:50,y:150}]})};
 assert.deepEqual(actual,expected);session.destroy();assert.equal(listeners.size,0);cases.push({case:type,expected,actual,diff:[]});
}
fs.writeFileSync('.artifacts/selection-gesture-expected-actual-diff.json',JSON.stringify({cases},null,2)+'\n');console.log(JSON.stringify({cases:cases.length,diff:[]},null,2));
