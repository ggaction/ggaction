import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {chart} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const rows=[{id:'a',category:'A',value:2},{id:'b',category:'B',value:5},{id:'c',category:'C',value:3}];
const program=chart().createCanvas({width:360,height:240}).createData({id:'rows',keyField:'id',values:rows})
 .createBarPlot({id:'bars',x:'category',y:'value',guides:false});
const session=createInteractionSession({program,bindings:[]}),phases=[];
session.subscribe(e=>{if(e.phase)phases.push(e.phase)});
const baseline=serializeProgram(program),cases=[];
const visible=p=>getMarkItems(p,{target:'bars'}).map(i=>i.fields.category);
for(const [name,payload,expected] of [
 ['filter',{select:{field:'category',op:'eq',value:'B'}},['B']],
 ['clear-filter',{clear:true},['A','B','C']]
]){
 session.dispatch({type:'filter',target:'bars',payload});
 const actual=visible(session.getState().program);assert.deepEqual(actual,expected);
 cases.push({name,expected,actual,diff:[]});
}
for(const [name,payload,expected] of [
 ['reorder',{channel:'x',values:['C','A']},['C','A','B']],
 ['clear-order',{channel:'x',clear:true},['A','B','C']]
]){
 session.dispatch({type:'reorder',target:'bars',payload});
 const actual=session.getState().program.resolvedScales.x.domain;assert.deepEqual(actual,expected);
 cases.push({name,expected,actual,diff:[]});
 if(name==='reorder'){
  session.dispatch({type:'filter',target:'bars',payload:{select:{field:'category',op:'neq',value:'A'}}});
  const actual=session.getState().program.resolvedScales.x.domain,expected=['C','B'];assert.deepEqual(actual,expected);
  cases.push({name:'filter-authored-order',expected,actual,diff:[]});
  session.dispatch({type:'filter',target:'bars',payload:{clear:true}});
  assert.deepEqual(session.getState().program.resolvedScales.x.domain,['C','A','B']);
 }
}
const restored=deserializeProgram(serializeProgram(session.getState().program));
assert.deepEqual(restored.graphicSpec,session.getState().program.graphicSpec);
assert.equal(serializeProgram(program),baseline);assert.deepEqual(phases,Array(6).fill(['commit','settled']).flat());
assert.equal(session.getState().revision,6);session.destroy();assert.equal(session.getState().destroyed,true);
const sourceHash=createHash('sha256').update(await readFile(new URL('../src/interaction/selection.js',import.meta.url))).digest('hex');
await writeFile(new URL('./direct-controls-expected-actual-diff.json',import.meta.url),JSON.stringify({rows,cases,phases,revision:6,sourceImmutable:true,codecExact:true,destroyed:true,sourceHash},null,2)+'\n');
