import {readFile,writeFile} from 'node:fs/promises';import {execFileSync} from 'node:child_process';import path from 'node:path';
import {preparePackageConsumer} from '../scripts/package-consumer.js';import {documentationPrograms} from '../scripts/doc-snippets.js';
const artifact=JSON.parse(await readFile(new URL('./direct-controls-fixed.json',import.meta.url),'utf8'));
const example=(await documentationPrograms()).find(p=>p.id==='interaction-direct-controls');
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
try{await writeFile(path.join(consumer.directory,'example.mjs'),"import assert from 'node:assert/strict';\n"+example.code+"\nassert.deepEqual(orderedProgram.resolvedScales.x.domain,['B','A']);\n");
execFileSync(process.execPath,['example.mjs'],{cwd:consumer.directory,stdio:'pipe'});
console.log(JSON.stringify({node:process.version,artifact:artifact.sha256,case:example.id,codeHash:example.sha256,sourceFree:true,passed:true}));
}finally{await consumer.cleanup()}
