import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';import{tmpdir}from'node:os';import path from'node:path';import{execFileSync}from'node:child_process';
import{createCanvas,loadImage}from'@napi-rs/canvas';
import{chart,render}from'../src/index.js';import{renderToSVG}from'../src/renderers/svg.js';import{renderToPNGBuffer}from'../src/renderers/png.js';import{renderToPDFBuffer}from'../src/renderers/pdf.js';
import{createMockCanvasContext}from'../test/support/canvas.js';import{serializeProgram,deserializeProgram}from'../src/persistence.js';
import{getMarkItems}from'../src/inspection.js';
const p=chart().createCanvas({width:400,height:280,margin:50});
const publicProgram=p.createAnnotation({id:'note',space:'screen',x:20,y:30,text:'Original',fontWeight:600}).editAnnotation({target:'note',text:'Screen note',x:45,y:80,dx:5,dy:-10});
const lower=p.createGraphics({id:'note',type:'text',length:0,parent:'canvas'}).editGraphics({target:'note',property:'items',value:[{type:'text',properties:{x:50,y:70,text:'Screen note',fill:'#334155',opacity:1,fontSize:12,fontFamily:'sans-serif',fontWeight:600,textAlign:'left',textBaseline:'alphabetic',rotation:0}}]});
const programs=[publicProgram,lower,deserializeProgram(serializeProgram(publicProgram))];
const contexts=programs.map(()=>createMockCanvasContext());programs.forEach((p,i)=>render(p,contexts[i]));
for(const ctx of contexts.slice(1))assert.deepEqual(ctx.calls,contexts[0].calls);
const svg=programs.map(p=>renderToSVG(p,{resourceNamespace:'annotation'}));assert.equal(svg[0],svg[1]);assert.equal(svg[0],svg[2]);
const png=await Promise.all(programs.map(p=>renderToPNGBuffer(p)));assert.deepEqual(png[0].buffer,png[1].buffer);assert.deepEqual(png[0].buffer,png[2].buffer);
const dir=await mkdtemp(path.join(tmpdir(),'annotation-render-'));
try{const pixels=[];for(const [i,p]of programs.entries()){const stem=path.join(dir,String(i));await writeFile(stem+'.pdf',(await renderToPDFBuffer(p)).buffer);execFileSync('pdftoppm',['-r','72','-singlefile','-png',stem+'.pdf',stem]);const image=await loadImage(stem+'.png'),canvas=createCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);pixels.push(Buffer.from(ctx.getImageData(0,0,image.width,image.height).data));}assert.deepEqual(pixels[0],pixels[1]);assert.deepEqual(pixels[0],pixels[2]);}finally{await rm(dir,{recursive:true,force:true});}
console.log('Screen annotation primitive public/lower/codec Canvas calls, SVG, exact PNG and exact PDF: PASS');
