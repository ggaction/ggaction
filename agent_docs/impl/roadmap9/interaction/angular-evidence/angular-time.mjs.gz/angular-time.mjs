import { chart } from '../src/index.js';import {getMarkItems} from '../src/inspection.js';
const p=chart().createCanvas({width:200,height:200,margin:0}).createData({values:[0,1000,43200000,86400000].map(angle=>({angle,radius:1}))}).createPolarScatterPlot({id:'points',theta:{field:'angle',fieldType:'temporal',scale:{type:'time',domain:[0,86400000]}},radius:'radius',guides:false});
console.log(p.resolvedScales, getMarkItems(p,{target:'points'}).map(i=>i.channels));
