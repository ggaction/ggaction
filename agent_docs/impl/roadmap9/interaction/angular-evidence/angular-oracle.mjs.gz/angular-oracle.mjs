import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createAngularSelectionChart} from '../examples/polar-points/program.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {invertAngularInterval} from '../src/grammar/scales/angularInversion.js';
const rad=d=>d*Math.PI/180;
const numeric=[
 {input:{scale:{type:'linear',domain:[0,360],range:[0,360]},angles:[350,10]},expected:[[0,10],[350,360]]},
 {input:{scale:{type:'linear',domain:[0,360],range:[-180,180]},angles:[350,10]},expected:[[170,190]]},
 {input:{scale:{type:'linear',domain:[0,360],range:[360,0]},angles:[350,10]},expected:[[0,10],[350,360]]},
 {input:{scale:{type:'log',domain:[1,1000],range:[0,360]},angles:[0,120]},expected:[[1,10],[1000,1000]]}
].map(c=>{const actual=invertAngularInterval(c.input.scale,...c.input.angles.map(rad)).ranges.map(r=>[r.min,r.max]);const diff=actual.map((r,i)=>r.map((v,j)=>v-c.expected[i][j]));assert.equal(actual.length,c.expected.length);assert.ok(diff.flat().every(v=>Math.abs(v)<1e-10));return {...c,actual,diff,tolerance:1e-10};});
const input={rows:[0,5,90,180,355,360].map(angle=>({id:`p${angle}`,angle,radius:1})),angles:[350,10]};
const p=createAngularSelectionChart(input.rows),s=createInteractionSession({program:p,bindings:[{type:'brush',axis:'theta',target:'points',selection:'picked'}]}),listeners=new Map(),captures=new Set(),phases=[];let scheduled;
const host={getBoundingClientRect:()=>({left:0,top:0,width:200,height:200}),addEventListener:(t,f)=>listeners.set(t,f),removeEventListener:t=>listeners.delete(t),setPointerCapture:id=>captures.add(id),hasPointerCapture:id=>captures.has(id),releasePointerCapture:id=>captures.delete(id),requestAnimationFrame:f=>{scheduled=f;return 1;},cancelAnimationFrame:()=>{scheduled=undefined;}};
s.mount(host);s.subscribe(e=>{if(e.phase)phases.push(e.phase)});
const pointer=d=>({pointerId:1,pointerType:'mouse',clientX:100+80*Math.sin(rad(d)),clientY:100-80*Math.cos(rad(d))});
listeners.get('pointerdown')(pointer(350));listeners.get('pointermove')(pointer(10));const flush=scheduled;scheduled=undefined;flush();assert.equal(s.getState().program,p);listeners.get('pointerup')(pointer(10));
const actual={ids:getMarkItems(s.getState().program,{target:'points'}).filter(i=>i.properties.fill==='red').map(i=>i.fields.id),phases,revision:s.getState().revision,captureCount:captures.size,overlay:s.getState().previewProgram};
const expected={ids:['p0','p5','p355','p360'],phases:['preview','preview','commit','settled'],revision:1,captureCount:0,overlay:null};assert.deepEqual(actual,expected);s.destroy();
const evidence={numeric,public:{input,inputSha256:createHash('sha256').update(JSON.stringify(input)).digest('hex'),calls:['createAngularSelectionChart(rows)','createInteractionSession({program,bindings:[{type:"brush",axis:"theta",target:"points",selection:"picked"}]}).mount(host)','pointerdown(350deg);pointermove(10deg);RAF;pointerup(10deg)'],expected,actual,diff:[]}};
await writeFile(new URL('./angular-expected-actual-diff.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');console.log('4 numeric literal cases and public seam transaction exact');
