import { chart } from '../src/index.js';
const p=chart().createCanvas({width:200,height:200,margin:0}).createData({values:[{a:0,r:1},{a:360,r:1}]}).createPolarScatterPlot({id:'points',theta:{field:'a',scale:{domain:[0,360]}},radius:{field:'r',scale:{domain:[0,1]}},guides:false});
console.log(JSON.stringify({layer:p.semanticSpec.layers[0],scale:p.resolvedScales,items:p.getMarkItems({target:'points'}).map(i=>({channels:i.channels,geometry:i.geometry}))},null,2));
