import {chart} from '../src/index.js';
let reads=0;const p=chart().createCanvas({width:200,height:200,margin:0});
try {p.materializeSelectionPreview({sector:{frame:{get centerX(){reads++;return 100;},centerY:100,availableRadius:100},startTheta:0,endTheta:90,outerRadius:100}});} catch(e){console.log(e.message)}
console.log({reads});
