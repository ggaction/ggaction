import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {chart} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
import {resolveStoredSelection} from '../src/materialization/selection/state.js';
import {createAngularSelectionChart} from '../examples/polar-points/program.js';
const baseRows=[{id:'a',x:50,y:60},{id:'b',x:200,y:130}];
const linear={field:'x',scale:{domain:[0,300],range:[0,300]}};
const point=(angle)=>({x:100+80*Math.sin(angle*Math.PI/180),y:100-80*Math.cos(angle*Math.PI/180)});
const scenarios=[
 {name:'x',rows:baseRows,x:linear,binding:{type:'brush',axis:'x'},points:[{x:20,y:100},{x:100,y:100}],expected:['a']},
 {name:'y',rows:baseRows,x:linear,binding:{type:'brush',axis:'y'},points:[{x:120,y:30},{x:120,y:90}],expected:['a']},
 {name:'xy',rows:baseRows,x:linear,binding:{type:'brush',axis:'xy'},points:[{x:20,y:20},{x:100,y:100}],expected:['a']},
 {name:'log',rows:[1,10,100].map((x,i)=>({id:String(i),x,y:60})),x:{field:'x',scale:{type:'log',domain:[1,100],range:[0,200],reverse:true}},binding:{type:'brush',axis:'x'},points:[{x:50,y:100},{x:150,y:100}],expected:['1']},
 {name:'time',rows:[1709251200000,1709337600000,1709424000000].map((x,i)=>({id:String(i),x,y:60})),x:{field:'x',fieldType:'temporal',temporalUnit:'timestamp',scale:{domain:[1709251200000,1709424000000],range:[0,200],nice:false}},binding:{type:'brush',axis:'x'},points:[{x:50,y:100},{x:150,y:100}],expected:['1']},
 {name:'category',rows:['A','B','C'].map((x,i)=>({id:String(i),x,y:60})),x:{field:'x',fieldType:'nominal',scale:{type:'band',domain:['A','B','C'],range:[0,300],padding:0}},binding:{type:'brush',axis:'x'},points:[{x:110,y:100},{x:190,y:100}],expected:['1']},
 {name:'angular',rows:[0,5,90,180,355,360].map(angle=>({id:String(angle),angle,radius:1})),binding:{type:'brush',axis:'theta'},points:[point(350),point(10)],expected:['0','5','355','360']},
 {name:'lasso',rows:baseRows,x:linear,binding:{type:'lasso'},points:[{x:20,y:20},{x:100,y:20},{x:100,y:100},{x:20,y:100}],expected:['a']}
];
const evidence=[];
for(const input of scenarios){
 const program=input.name==='angular'?createAngularSelectionChart(input.rows):chart().createCanvas({width:300,height:200,margin:0}).createData({id:'rows',keyField:'id',values:input.rows}).createPointMark({id:'points'}).encodePointRadius({value:8}).encodeX(input.x).encodeY({field:'y',scale:{domain:[0,200],range:[0,200]}}).selectMarks({id:'picked',target:'points',items:[]});
 const initial=serializeProgram(program),listeners=new Map(),captures=new Set(),frames=new Map(),phases=[];let sequence=0;
 const host={getBoundingClientRect:()=>({left:0,top:0,width:input.name==='angular'?200:300,height:200}),addEventListener:(type,fn)=>listeners.set(type,fn),removeEventListener:type=>listeners.delete(type),setPointerCapture:id=>captures.add(id),hasPointerCapture:id=>captures.has(id),releasePointerCapture:id=>captures.delete(id),requestAnimationFrame:fn=>{frames.set(++sequence,fn);return sequence;},cancelAnimationFrame:id=>frames.delete(id)};
 const session=createInteractionSession({program,bindings:[{...input.binding,target:'points',selection:'picked'}]});session.mount(host);session.subscribe(e=>{if(e.phase)phases.push(e.phase);});
 const fire=(type,p={x:0,y:0})=>listeners.get(type)?.({pointerId:1,pointerType:'mouse',button:0,clientX:p.x,clientY:p.y});
 const move=()=>{fire('pointerdown',input.points[0]);for(const p of input.points.slice(1))fire('pointermove',p);const pending=[...frames.values()];frames.clear();pending.forEach(fn=>fn());};
 move();fire('pointercancel');fire('pointerup',input.points.at(-1));
 const cancel={sameProgram:session.getState().program===program,sameSerialized:serializeProgram(program)===initial,phases:[...phases],capture:captures.size,frames:frames.size,preview:session.getState().previewProgram};
 const expectedCancel={sameProgram:true,sameSerialized:true,phases:['preview','cancel'],capture:0,frames:0,preview:null};assert.deepEqual(cancel,expectedCancel);
 phases.length=0;move();fire('pointerup',input.points.at(-1));
 const next=session.getState().program,result=resolveStoredSelection(next,'picked'),restored=resolveStoredSelection(deserializeProgram(serializeProgram(next)),'picked');
 const ids=r=>r.items.filter(i=>r.keys.includes(i.key)).map(i=>i.fields.id);
 const commit={ids:ids(result),restoredIds:ids(restored),phases:[...phases],revision:session.getState().revision,capture:captures.size,frames:frames.size,preview:session.getState().previewProgram,baselineUnchanged:serializeProgram(program)===initial};
 const expectedCommit={ids:input.expected,restoredIds:input.expected,phases:['preview','preview','commit','settled'],revision:1,capture:0,frames:0,preview:null,baselineUnchanged:true};assert.deepEqual(commit,expectedCommit);
 session.destroy();assert.equal(listeners.size,0);
 evidence.push({input,inputSha256:createHash('sha256').update(JSON.stringify(input)).digest('hex'),calls:['chart/createAngularSelectionChart(rows)','createInteractionSession({program,bindings:[binding]}).mount(host)','down;move;RAF;cancel;late-up;down;move;RAF;up;codec;destroy'],expected:{cancel:expectedCancel,commit:expectedCommit},actual:{cancel,commit},diff:[]});
}
await writeFile(new URL('./angular-at36-expected-actual-diff.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');
console.log('AT36: 8 public scenarios, cancel and commit each, codec and cleanup passed');
