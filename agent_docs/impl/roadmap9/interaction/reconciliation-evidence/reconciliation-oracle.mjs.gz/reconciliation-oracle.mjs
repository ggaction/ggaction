import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chart} from '../src/index.js';
import {getMarkItems} from '../src/inspection.js';
import {createInteractionSession} from '../src/interaction.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const program=chart().createCanvas({width:300,height:200}).createData({id:'rows',keyField:'id',values:[{id:'a',x:1,y:2},{id:'b',x:2,y:3},{id:'c',x:3,y:4}]}).createScatterPlot({id:'points',x:'x',y:'y',guides:false})
.selectMarks({id:'picked',field:'id',op:'eq',value:'b'}).highlightMarks({selection:'picked',color:'red',dimOthers:false,bringToFront:false});
const before=serializeProgram(program), actual=[];
for(const selectionPolicy of ['keep-hidden','drop']) {
 const session=createInteractionSession({program,selectionPolicy,bindings:[]}), events=[];
 session.subscribe(e=>events.push(e));
 session.updateProgram(program.filterMarks({target:'points',field:'id',op:'neq',value:'b'}));
 session.updateProgram(deserializeProgram(serializeProgram(session.getState().program)).removeMarkFilter({target:'points'}));
 actual.push({policy:selectionPolicy,events:events.map(e=>({type:e.type,changes:e.selectionChanges.map(c=>({hidden:c.hiddenKeys.length,restored:c.restoredKeys.length,dropped:c.droppedKeys.length,ownerMissing:c.ownerMissing}))})),selected:getMarkItems(session.getState().program).filter(i=>i.properties.fill==='red').map(i=>i.fields.id),revision:session.getState().revision});
 session.destroy();
}
const expected=[
 {policy:'keep-hidden',events:[{type:'program',changes:[{hidden:1,restored:0,dropped:0,ownerMissing:false}]},{type:'program',changes:[{hidden:0,restored:1,dropped:0,ownerMissing:false}]}],selected:['b'],revision:2},
 {policy:'drop',events:[{type:'program',changes:[{hidden:0,restored:0,dropped:1,ownerMissing:false}]},{type:'program',changes:[]}],selected:[],revision:2}
];
assert.deepEqual(actual,expected);assert.equal(serializeProgram(program),before);
console.log(JSON.stringify({expected,actual,diff:[],sourceUnchanged:true,sourceHash:createHash('sha256').update(before).digest('hex')},null,2));
