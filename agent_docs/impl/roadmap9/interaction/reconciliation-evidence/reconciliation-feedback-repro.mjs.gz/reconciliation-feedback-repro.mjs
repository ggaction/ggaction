import {chart} from '../src/index.js';
import {getMarkItems} from '../src/inspection.js';
import {createInteractionSession} from '../src/interaction.js';
let p=chart().createCanvas().createData({id:'rows',keyField:'id',values:[{id:'a',x:1,y:2},{id:'b',x:2,y:3}]})
.createScatterPlot({id:'a',x:'x',y:'y',guides:false}).createPointMark({id:'b',data:'rows'}).encodeX({target:'b',field:'x'}).encodeY({target:'b',field:'y'});
const bkey=getMarkItems(p,{target:'b'}).find(i=>i.fields.id==='b').key;
p=p.encodeOpacity({target:'a',value:1}).selectMarks({id:'aSel',target:'a',property:'opacity',op:'eq',value:1}).selectMarks({id:'bSel',target:'b',field:'id',op:'eq',value:'b'})
.encodeOpacity({target:'a',conditions:[{when:{selection:'bSel'},value:{value:.5}}],otherwise:{value:1}})
;
const s=createInteractionSession({program:p,selectionPolicy:'drop',bindings:[]});
s.updateProgram(p.filterMarks({target:'b',field:'id',op:'neq',value:'b'}));
console.log('accepted',s.getState().revision);
