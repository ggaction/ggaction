import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chart } from '../src/index.js';
import { createInteractionSession } from '../src/interaction.js';
import { serializeProgram } from '../src/persistence.js';
import { resolveStoredSelection } from '../src/materialization/selection/state.js';
const source=chart().createCanvas({width:300,height:200,margin:0})
 .createData({id:'rows',keyField:'id',values:[{id:'a',x:50,y:60},{id:'b',x:50,y:60},{id:'c',x:200,y:130}]})
 .createPointMark({id:'points'}).encodePointRadius({value:8})
 .encodeX({field:'x',scale:{domain:[0,300],range:[0,300]}})
 .encodeY({field:'y',scale:{domain:[0,200],range:[0,200]}})
 .selectMarks({id:'picked',target:'points',items:[]});
const before=serializeProgram(source),actual=[];

for(const name of ['escape','movement','commit']) {
 const captures=new Set(),handlers=new Map(),events=[];
 const host={getBoundingClientRect:()=>({left:10,top:20,width:300,height:200}),addEventListener:(type,fn)=>handlers.set(type,fn),removeEventListener:(type,fn)=>{if(handlers.get(type)===fn)handlers.delete(type)},setPointerCapture:id=>captures.add(id),releasePointerCapture:id=>captures.delete(id),hasPointerCapture:id=>captures.has(id)};
 const session=createInteractionSession({program:source,bindings:[{type:'select',target:'points',selection:'picked'}]});session.mount(host);session.subscribe(e=>{if(e.phase)events.push(e.phase)});
 const pointer={pointerId:1,pointerType:'mouse',button:0,clientX:60,clientY:80};handlers.get('pointerdown')(pointer);
 if(name==='escape')handlers.get('keydown')({key:'Escape'});
 if(name==='movement')for(let x=1;x<=100;x++)handlers.get('pointermove')({...pointer,clientX:60+x});
 handlers.get('pointerup')(pointer);handlers.get('click')({...pointer,detail:1});
 const accepted=session.getState(),resolved=resolveStoredSelection(accepted.program,'picked');
 const result={name,programUnchanged:serializeProgram(accepted.program)===before,revision:accepted.revision,selected:resolved.items.filter(item=>resolved.keys.includes(item.key)).map(item=>item.fields.id),events:[...events],captures:captures.size};
 session.destroy();result.listenersAfterDestroy=handlers.size;actual.push(result);
}
const expected=[
 {name:'escape',programUnchanged:true,revision:0,selected:[],events:['cancel'],captures:0,listenersAfterDestroy:0},
 {name:'movement',programUnchanged:true,revision:0,selected:[],events:['cancel'],captures:0,listenersAfterDestroy:0},
 {name:'commit',programUnchanged:false,revision:1,selected:['b'],events:['commit','settled'],captures:0,listenersAfterDestroy:0}
];assert.deepEqual(actual,expected);assert.equal(serializeProgram(source),before);
await writeFile(new URL('./pointer-capture-expected-actual-diff.json',import.meta.url),JSON.stringify({scope:'Public captured click; no drag preview or history claim',expected,actual,diff:[]},null,2)+'\n');
console.log('Public literal capture/selection/revision oracle passed.');
