import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,realpath} from 'node:fs/promises';
import path from 'node:path';
import {build} from 'vite';
import {chromium} from 'playwright';
import AxeBuilder from '@axe-core/playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {startStaticServer} from '../test/support/static-server.js';
import {openBrowserPage,assertNoBrowserErrors,closeBrowserWithEvidence,saveBrowserContextEvidence} from '../test/support/browser.js';
const artifact=JSON.parse(await readFile('.artifacts/keyboard-focus-fixed.json','utf8')),consumer=await preparePackageConsumer({packageSpec:artifact.file});
let server,browser;
try{
 const section=(await readFile('docs/api/interaction.md','utf8')).split('## Accessible tooltips and touch')[1],html=section.match(/```html\n([\s\S]*?)```/)[1],source=section.match(/```javascript\n([\s\S]*?)```/)[1];
 const requested=path.join(consumer.directory,'tooltip-browser');await mkdir(requested);const root=await realpath(requested);
 await writeFile(path.join(root,'index.html'),`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Accessible observations</title></head><body><main><h1>Accessible observations</h1>${html}</main><script type="module" src="/main.js"></script></body></html>`);
 await writeFile(path.join(root,'main.js'),source+'\nwindow.__accessible=accessibleSession;window.__disposeAccessible=disposeAccessible;');
 const result=await build({root,configFile:false,logLevel:'silent',build:{minify:'esbuild',rollupOptions:{input:path.join(root,'index.html')},write:true}});
 const chunks=(Array.isArray(result)?result:[result]).flatMap(r=>r.output??[]).filter(r=>r.type==='chunk'),modules=[...new Set(chunks.flatMap(c=>Object.keys(c.modules)))];
 assert.equal(modules.some(f=>f.includes('/roadmap9-paints/')),false);assert.equal(modules.some(f=>f.includes('/src/mcp/')||f.includes('/knowledge/')||f.includes('@modelcontextprotocol')),false);
 server=await startStaticServer(path.join(root,'dist'));browser=await chromium.launch({headless:true});const context=await browser.newContext({viewport:{width:720,height:600},hasTouch:true});
 try{
  const {page,errors}=await openBrowserPage(context,server.baseUrl,{waitFor:()=>!!window.__accessible});const surface=page.locator('#accessible-chart'),tooltip=page.locator('#accessible-tooltip');
  await surface.focus();await page.keyboard.press('Home');await page.keyboard.press('Enter');assert.equal(await tooltip.textContent(),'A: x 2, y 3. Selected.');await page.keyboard.press('Escape');assert.equal(await tooltip.isVisible(),false);
  const b=await surface.boundingBox();await page.touchscreen.tap(b.x+294,b.y+118);assert.equal(await tooltip.textContent(),'B: x 8, y 7. Selected.');assert.equal(await page.evaluate(()=>window.__accessible.getState().history.undoCount),2);
  await surface.focus();await page.keyboard.press('Home');await page.locator('#accessible-hide').click();assert.equal(await page.evaluate(()=>window.__accessible.getState().focus.itemKey),null);assert.equal(await page.getByRole('option').count(),2);
  const a11y=await new AxeBuilder({page}).analyze();assert.deepEqual(a11y.violations,[]);
  await page.locator('#accessible-dispose').click();assert.equal(await page.evaluate(()=>window.__accessible.getState().destroyed),true);await surface.focus();await page.keyboard.press('Enter');assert.equal(await tooltip.isVisible(),false);assertNoBrowserErrors(errors,'source-free accessible tooltip');await page.close();
 }catch(error){await saveBrowserContextEvidence(context,error);throw error;}finally{await context.close();}
 console.log(JSON.stringify({node:process.version,sourceFree:true,artifact:artifact.sha256,installedManifest:consumer.installedManifest.version,modules:modules.length,chunkCount:chunks.length,keyboard:true,touch:true,nativeSelection:true,filterFocusFallback:true,explicitTeardown:true,axeViolations:0}));
}finally{if(browser)await closeBrowserWithEvidence(browser);await server?.close();await consumer.cleanup();}
