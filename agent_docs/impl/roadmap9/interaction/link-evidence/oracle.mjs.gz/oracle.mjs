import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {chart,hconcat} from '../src/index.js';
import {createInteractionSession} from '../src/interaction.js';
import {getMarkItems} from '../src/inspection.js';
import {serializeProgram,deserializeProgram} from '../src/persistence.js';
const source=chart().createCanvas({width:300,height:200}).createData({id:'rows',keyField:'id',values:[{id:'a',x:1,y:2,group:1},{id:'b',x:2,y:3,group:'1'},{id:'c',x:3,y:4,group:1}]})
.createScatterPlot({id:'points',x:'x',y:'y',guides:false}).selectMarks({id:'picked',items:[]}).highlightMarks({selection:'picked',color:'red',bringToFront:false,dimOthers:false});
const original=hconcat({programs:['a','b','c','d'].map(id=>({id,program:source}))});
const target=id=>({childPath:[id],id:'points'});
const session=createInteractionSession({program:original,bindings:[
 {type:'linkSelection',id:'tuple',target:target('c'),selection:'picked',resolve:'union',sources:['a','b'].map(id=>({target:target(id),selection:'picked',projection:{type:'fields',sourceFields:['group'],targetFields:['group']}}))},
 {type:'linkSelection',id:'row',target:target('d'),selection:'picked',resolve:'global',sources:[{target:target('a'),selection:'picked',projection:{type:'rows',sourceData:'rows',targetData:'rows'}}]}
]});
const phases=[];session.subscribe(event=>phases.push(event.phase));
for(const id of ['a','b'])session.dispatch({type:'select',target:target(id),payload:{id:'picked',select:{field:'id',op:'eq',value:id}}});
const selected=p=>Object.fromEntries(['a','b','c','d'].map(id=>[id,getMarkItems(p.children[id],{target:'points'}).filter(item=>item.properties.fill==='red').map(item=>item.fields.id)]));
const actual={selected:selected(session.getState().program),restored:selected(deserializeProgram(serializeProgram(session.getState().program))),original:selected(original),phases,revision:session.getState().revision,projectedSourceCounts:session.getState().linkedSelections[0].sources.map(source=>source.keys.length)};
const expected={selected:{a:['a'],b:['b'],c:['a','b','c'],d:['a']},restored:{a:['a'],b:['b'],c:['a','b','c'],d:['a']},original:{a:[],b:[],c:[],d:[]},phases:['commit','settled','commit','settled'],revision:2,projectedSourceCounts:[2,1]};
assert.deepEqual(actual,expected);session.destroy();
await writeFile('.artifacts/interaction-links-oracle.json',JSON.stringify({expected,actual,diff:[]},null,2)+'\n');
console.log('Independent linked tuple/lineage/restore/transaction literals passed');
