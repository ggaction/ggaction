import assert from 'node:assert/strict';
import {readFile,writeFile,realpath} from 'node:fs/promises';
import path from 'node:path';
import {build,preview} from 'vite';
import {chromium} from 'playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {documentationPrograms} from '../scripts/doc-snippets.js';
const artifact=JSON.parse(await readFile('.artifacts/node-move-fixed.json','utf8'));
const snippet=(await documentationPrograms()).find(example=>example.id==='interaction-node-movement');assert.ok(snippet);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});consumer.directory=await realpath(consumer.directory);let server,browser;
try{
 await writeFile(path.join(consumer.directory,'index.html'),'<html lang="en"><head><title>Node movement</title></head><body><canvas id="chart" aria-label="Movable graph nodes"></canvas><script type="module" src="/main.js"></script></body></html>');
 await writeFile(path.join(consumer.directory,'main.js'),snippet.code+'\nwindow.controls={session:nodeSession,dispose:disposeNodeControls};');
 await build({root:consumer.directory,logLevel:'silent',build:{target:'esnext'}});server=await preview({root:consumer.directory,logLevel:'silent',preview:{host:'127.0.0.1',port:0}});
 browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(server.resolvedUrls.local[0]);await page.waitForFunction(()=>window.controls);
 assert.equal(await page.locator('output').textContent(),'First node: 70, 90');
 const box=await page.locator('canvas').boundingBox();
 await page.mouse.move(box.x+72,box.y+92);await page.mouse.down();await page.mouse.move(box.x+112,box.y+122,{steps:10});
 await page.waitForFunction(()=>window.controls.session.getState().previewProgram!==null);
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),0);
 await page.mouse.up();assert.equal(await page.locator('output').textContent(),'First node: 110, 120');
 await page.getByRole('button',{name:'Move first node right',exact:true}).focus();await page.keyboard.press('Enter');
 assert.equal(await page.locator('output').textContent(),'First node: 130, 120');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),2);
 assert.equal(await page.evaluate(()=>document.activeElement.id),'node-right');
 await page.evaluate(()=>window.controls.dispose());assert.deepEqual(errors,[]);
 console.log(JSON.stringify({node:process.version,archive:artifact.sha256,id:snippet.id,sourceFree:true,revision:2,position:[130,120],pointer:true,keyboard:true,disposed:true,errors:[]}));
}finally{await browser?.close();if(server)await new Promise(resolve=>server.httpServer.close(resolve));await consumer.cleanup();}
