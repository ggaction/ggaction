import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile,mkdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../scripts/browser-bundle-size.js';
const artifact=JSON.parse(await readFile(new URL('./accessible-items-fixed.json',import.meta.url),'utf8'));
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
try {
 await copyFile(new URL('../scripts/consumers/fixtures/node/accessible-items.mjs',import.meta.url),path.join(consumer.directory,'accessible-items.mjs'));
 await copyFile(new URL('../scripts/consumers/fixtures/accessible-items.ts',import.meta.url),path.join(consumer.directory,'accessible-items.mts'));
 await writeFile(path.join(consumer.directory,'run.mjs'),`import {cases} from './accessible-items.mjs';for(const c of cases){await c.run();console.log(c.id+' PASS')}`);
 const output=execFileSync(process.execPath,['run.mjs'],{cwd:consumer.directory,encoding:'utf8'});
 execFileSync(process.execPath,[path.resolve('node_modules/typescript/bin/tsc'),'--noEmit','--strict','--exactOptionalPropertyTypes','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext',path.join(consumer.directory,'accessible-items.mts')],{cwd:consumer.directory,encoding:'utf8'});
 const section=(await readFile('docs/api/rendering.md','utf8')).split('### Native item alternatives')[1].split('## Explicit whole-glyph opacity')[0];
 const snippet=section.match(/```javascript\n([\s\S]*?)```/)[1];
 await writeFile(path.join(consumer.directory,'snippet.mjs'),snippet);execFileSync(process.execPath,['snippet.mjs'],{cwd:consumer.directory,encoding:'utf8'});
 const bundles=[];
 for(const specifier of ['ggaction','ggaction/basic','ggaction/svg','ggaction/interaction','ggaction/graph']){
  const result=await measureMinimalBrowserBundle(consumer.directory,{specifier});
  bundles.push(result);
 }
 console.log(JSON.stringify({node:process.version,artifact:artifact.sha256,sourceFree:true,runtime:output.trim().split('\n'),types:'passed',bundles},null,2));
 for (const result of bundles) if(BROWSER_BUNDLE_GZIP_LIMITS[result.specifier] !== undefined) assert.ok(result.gzipBytes <= BROWSER_BUNDLE_GZIP_LIMITS[result.specifier], JSON.stringify(result));
}finally{await consumer.cleanup()}
