import fs from 'node:fs';
const file='src/interaction/session.js';let s=fs.readFileSync(file,'utf8');
function replace(from,to){if(!s.includes(from))throw new Error('Missing '+from.slice(0,70));s=s.replace(from,to);}
replace('let state, revision = 0, transactionSequence = 0, ignoredClick, previewProgram = null;','let state, revision = 0, transactionSequence = 0, ignoredClick, previewProgram = null, previewPreparation = null;');
replace('const snapshot = () => state = freezeOwned({ program, previewProgram, scene: bridge.getState().scene, ...preparation.inspect(),','let activePreparation = preparation;\n  const snapshot = () => state = freezeOwned({ program, previewProgram, scene: bridge.getState().scene, ...preparation.inspect(),\n    previewAssets: previewPreparation?.inspect().assets ?? null,\n    preparation: previewPreparation?.inspect().preparation ?? preparation.inspect().preparation,');
replace('try { preparation.dispose(); } catch (error) { failure = error; }\n    try { if (mounted !== undefined) detach(mounted, "destroy"); } catch (error) { failure ??= error; }','try { if (mounted !== undefined) detach(mounted, "destroy"); } catch (error) { failure = error; }\n    try { preparation.dispose(); } catch (error) { failure ??= error; }');
replace('const previous = program, sessionGeneration = generation, baseRevision = revision;\n    return preparation.start','const previous = program, sessionGeneration = generation, baseRevision = revision;\n    activePreparation = preparation;\n    return preparation.start');
replace('whenSettled() { return preparation.whenSettled(); }','whenSettled() { return activePreparation.whenSettled(); }');
replace('finally { if (token) token.raf = undefined; gesture = undefined; previewProgram = null; }','finally {\n                if (token) token.raf = undefined; gesture = undefined; previewProgram = null;\n                const previous = previewPreparation; previewPreparation = null; snapshot(); previous?.dispose();\n              }');
const start=s.indexOf('            const preview = token => {'),end=s.indexOf('            lease.capture = prepareSelectionCapture',start);
s=s.slice(0,start)+`            const preview = (token, final = false) => {
              if (token.previous !== program) throw new Error("Selection gesture baseline is stale.");
              const result = navigating ? cameraNavigationDraft(token.context, token.pointers) : (moving ? movement.command : regionGestureCommand)(token.context, token.points);
              const command = interactionTransaction(result.command, token.transactionId), draft = prepareEdit(command, result.prepared);
              if (final && preparation.enabled) return { command, draft };
              const next = moving ? draft?.prepared.program ?? program : materializeRegisteredSelectionPreview(draft?.prepared.program ?? program, result.overlay);
              const accept = () => {
                let frame;
                if (moving && draft) {
                  frame = rebindProgramHitFrame(draft.candidate, draft.candidate.scene, nextInteger(bridge.getState().version), transform);
                  nextInteger(nextInteger(frame.version));
                } else if (navigating && token.previewed) frame = rebindProgramHitFrame(base, token.scene, nextInteger(bridge.getState().version), transform);
                return () => {
                  previewProgram = next;
                  if (frame) { bridge.updateFrame(frame); token.previewed = true; lastHit = null; }
                  publish(eventType, { ...details(token, "preview"), affectedOwners: draft?.prepared.affectedOwners ?? freezeOwned([binding.target]) });
                };
              };
              if (preparation.enabled) {
                const owner = token.preparation;
                activePreparation = owner;
                owner.start(next, { sessionGeneration: generation, transactionId: token.transactionId, baseRevision: revision }, {
                  current: tags => !destroyed && mounted === lease && gesture === token && program === token.previous && generation === tags.sessionGeneration && revision === tags.baseRevision,
                  prepare: accept,
                  cancel() {},
                  error: error => { try { lease.capture.fail(error); } catch (failure) { if (failure !== error) throw failure; } }
                }, draft?.resourceRevisions);
              } else accept()();
              return { command, draft };
            };
`+s.slice(end);
replace('begin: point => {\n                const scene = bridge.getState().scene;','begin: point => {\n                if (preparation.enabled && preparation.inspect().assets === null) return null;\n                const scene = bridge.getState().scene;');
replace('transactionSequence = nextInteger(transactionSequence);\n                return gesture = { transactionId:', 'transactionSequence = nextInteger(transactionSequence);\n                if (preparation.enabled) previewPreparation = createInteractionPreparation(request.assetResolver, operation => perform(operation), () => snapshot());\n                return gesture = { preparation: previewPreparation, transactionId:');
replace('result = preview(token);\n                  // Asset preparation','result = preview(token, true);\n                  // Asset preparation');
replace('discard(token, navigating);','discard(token, navigating || preparation.enabled);');
fs.writeFileSync(file,s);
const types='types/interaction.d.ts';s=fs.readFileSync(types,'utf8');s=s.replace('readonly assets: Readonly<InteractionAssets> | null;','readonly assets: Readonly<InteractionAssets> | null;\n  /** Transient handles for the exact previewProgram; never use committed assets for that preview. */\n  readonly previewAssets: Readonly<InteractionAssets> | null;');fs.writeFileSync(types,s);
