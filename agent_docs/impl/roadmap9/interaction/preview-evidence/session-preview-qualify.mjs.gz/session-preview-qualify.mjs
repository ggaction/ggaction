import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const root='agent_docs/impl/roadmap9/interaction/preview-evidence';fs.mkdirSync(root,{recursive:true});
const read=f=>fs.readFileSync(f,'utf8');
const json=f=>{const s=read(f),start=s.indexOf('{'),end=s.indexOf('\n}\n',start)+2;return JSON.parse(s.slice(start,end||undefined));};
const sha=b=>createHash('sha256').update(b).digest('hex');
const h=createHash('sha256');for(const f of execFileSync('git',['ls-files','src','types'],{encoding:'utf8'}).trim().split('\n').sort()){h.update(f+'\0');h.update(fs.readFileSync(f));h.update('\0');}
const record={
 sourceCommit:execFileSync('git',['rev-parse','63df4901c'],{encoding:'utf8'}).trim(),parent:'e2eb5954737eb13d682c3237228bbe786be51bf9',authorization:'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 scope:'Native editing gesture previews reuse the existing preparation owner: exact previewProgram/previewAssets/frame publication, separate committed lease, bounded supersession, final commit preparation and synchronous cancellation cleanup. No new renderer, persisted schema or authoritative cache.',
 runtimeAndTypesFingerprint:h.digest('hex'),
 checks:{focused:302,additionalOwnerAndTypeRegressions:13,previewCases:12,critical:json('.artifacts/session-preview-critical.json'),
 realistic:{tests:16,datasets:5,recipes:3},
 browser:{tests:2,canonicalFragment:'Prepare assets before committing',actualMouseAndBitmap:true,previewWaitCancellationLateBitmapDisposal:true,viewportDeviceScaleFactor:2,rendererPixelRatio:1},
 actualAssets:{image:true,font:true,shadow:true,canvasPngExact:true,svgPayload:true,glyphCropInvariant:true,initialAndCancelledProgramIdentity:true,lateLifetimeCount:100},
 docsAndBoundaries:55,sourcePinnedDocs:49,finalBoundaries:33,manifestPolicy:2,
 built:{pages:172,llmArtifacts:1535,widths:[320,390,768,1440],axeViolations:0,overflow:false,manualInspection:'320px and1440px preparation prose and contained executable example inspected after source pin.'},
 installed:[json('.artifacts/session-preview-consumer20-budget.log'),json('.artifacts/session-preview-consumer22.log'),json('.artifacts/session-preview-consumer24.log')]},
 artifact:json('.artifacts/session-preview-fixed.json'),packageNode20Measurement:json('.artifacts/session-preview-package-measure-node20.json'),
 limits:{entries:1060,packedBytes:1505000,unpackedBytes:6843000,fullGzip:732400,basicGzip:386100,interactionGzip:120000,graphGzip:44100,searchBytes:1037700},
 preservedFailures:[
 'Initial reproduction exposed a preview before its exact asset lease was ready. F now keeps the committed or previous accepted preview until preparation succeeds.',
 'Focused30/31 retained the old navigation expectation that a pending preview is immediately visible. The regression now resolves the preview lease explicitly before final preparation; focused57/57 followed.',
 'Additional assets11/12 used an invalid selectMarks fixture shape. Corrected selectMarks({id,items:[]}); final preview12 plus strict types1 passed.',
 'Docs54/55 retained the old contextual snippet hash. The exact new fragment executed in both browser cases before the reviewed exception hash was updated; docs55/55 and source-pinned49/49 passed.',
 'Initial canonical package validation failed unpacked6842266>6841000. Node20 read-only copied inspector measured1060/1504715/6842266; canonical Node22 pack passed after only unpacked cap6843000. Measurement-only inspector is not reported as a validation pass.',
 'Node20 same-tar runtime20 and strict types passed; interaction119991gzip exceeded119700. Only cap changed to120000 and the same measured five bundles were validated again. Node22/24 independently passed runtime20/types/fivebundles. Initial exit1 is preserved.'
 ],
 reusedEvidence:'The302 source checks include the only changed runtime owner. Later additions modify tests/docs/fixtures only. Existing PNG/PDF rendering and camera mathematics remain unchanged; this checkpoint adds real Canvas/PNG/SVG asset combination evidence and two actual browser flows. No complete repository coverage, complete installed suite, new PDF sweep or animation integration is claimed.',
 remaining:['Public animation current-frame preparation and camera integration','Multiple applicable editing gesture priority/modifier arbitration','Combined AT40/41 worker/session/player closure','STEP074-077 overall qualification'],
 commands:{focused:'node --test --experimental-test-coverage --test-coverage-include=src/interaction/session.js test/unit/interaction-*.test.js test/contracts/interaction-types.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js',additional:'node --test test/unit/interaction-preview-preparation.test.js test/contracts/interaction-types.test.js',realistic:'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned TidyTuesday cache',browser:'node --test --test-name-pattern="canonical asset resolver|canonical preview asset" test/browser/interaction-session.browser.js',installed:'Node20/22/24 node .artifacts/session-preview-consumer.mjs using same7811b16f tar; Node20 cap-only verification stored separately',docs:'docs:generate; docs:preflight; owning49+packageboundaries6; source pin provenance/machine/llms; owning49; build/built; targeted4width browser/Axe'},
 evidenceFiles:[]
};
for(const name of fs.readdirSync('.artifacts').filter(n=>n.startsWith('session-preview-')&&/\.(log|mjs|json)$/.test(n)).sort()){
 const body=gzipSync(fs.readFileSync('.artifacts/'+name)),out=name+'.gz';fs.writeFileSync(root+'/'+out,body);record.evidenceFiles.push({path:out,sha256:sha(body)});
}
for(const name of fs.readdirSync('.artifacts/interaction-preview-docs').filter(n=>n.endsWith('.png')).sort()){
 const body=fs.readFileSync('.artifacts/interaction-preview-docs/'+name);fs.writeFileSync(root+'/'+name,body);record.evidenceFiles.push({path:name,sha256:sha(body)});
}
fs.writeFileSync(root+'/qualification.json',JSON.stringify(record,null,2)+'\n');
