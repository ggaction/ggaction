import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {idleGestureState,reduceGesture} from '../src/interaction/gestures.js';
const binding={id:'brush',kind:'brush'}, expected={terminalEvents:['cancel'],commitCount:0,capturedPointersAfter:0,finalPhase:'idle'};
let state=idleGestureState(),captured=new Set(),terminalEvents=[];
const events=[{type:'down',pointerId:1,pointerType:'mouse',point:{x:0,y:0},binding},...[4,8,12].map(x=>({type:'move',pointerId:1,point:{x,y:0}})),{type:'cancel',reason:'Escape'},{type:'up',pointerId:1,point:{x:12,y:0}}];
for(const event of events){const next=reduceGesture(state,event);state=next.state;for(const effect of next.effects){if(effect.type==='capture')captured.add(effect.pointerId);if(effect.type==='release')captured.delete(effect.pointerId);if(['cancel','commit'].includes(effect.type))terminalEvents.push(effect.type)}}
const actual={terminalEvents,commitCount:terminalEvents.filter(x=>x==='commit').length,capturedPointersAfter:captured.size,finalPhase:state.phase};assert.deepEqual(actual,expected);
await writeFile(new URL('./gesture-kernel-expected-actual-diff.json',import.meta.url),JSON.stringify({scope:'Private effect reducer; actual DOM/program/history validation remains open',input:events,expected,actual,diff:[]},null,2)+'\n');
