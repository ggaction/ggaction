import fs from 'node:fs/promises';import path from 'node:path';import {execFileSync} from 'node:child_process';
const directory=(await fs.readFile('.artifacts/static-delivery-consumer-path.txt','utf8')).trim();
for(const file of ['static-delivery.mjs','fonts.mjs'])await fs.copyFile('scripts/consumers/fixtures/node/'+file,path.join(directory,file));
execFileSync(process.execPath,['run.mjs'],{cwd:directory,stdio:'inherit',timeout:120000});
const output=path.resolve('.artifacts/static-delivery-'+process.version);await fs.mkdir(output,{recursive:true});await fs.cp(path.join(directory,'static-delivery'),path.join(output,'outputs'),{recursive:true});
console.log(JSON.stringify({node:process.version,sourceFree:true,output}));
