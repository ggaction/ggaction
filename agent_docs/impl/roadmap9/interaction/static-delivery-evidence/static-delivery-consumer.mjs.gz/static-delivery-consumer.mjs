import fs from 'node:fs/promises';import path from 'node:path';import {execFileSync} from 'node:child_process';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
const file='/Users/hyeonjeon/.codex/worktrees/roadmap9-integration/ggactionnewbrand/.artifacts/integration-archives/ggaction-ecbd493db25236a7410057f261a8a8a9516bcb74930f5e907ec179a638803629.tgz';
const consumer=await preparePackageConsumer({packageSpec:file});
const output=path.resolve('.artifacts/static-delivery-'+process.version);
try {await fs.mkdir(output,{recursive:true});await fs.writeFile(path.join(output,'consumer-path.txt'),consumer.directory);
 for(const file of ['static-delivery.mjs','fonts.mjs'])await fs.copyFile('scripts/consumers/fixtures/node/'+file,path.join(consumer.directory,file));
 const lock=JSON.parse(await fs.readFile('package-lock.json','utf8'));const canvas=lock.packages['node_modules/@napi-rs/canvas'].version;
 execFileSync('npm',['install','--ignore-scripts','--no-audit','--no-fund','@napi-rs/canvas@'+canvas],{cwd:consumer.directory,stdio:'inherit',timeout:120000});
 await fs.writeFile(path.join(consumer.directory,'run.mjs'),"import {cases} from './static-delivery.mjs';for(const c of cases){await c.run();console.log(c.id+' passed');}");
 execFileSync(process.execPath,['run.mjs'],{cwd:consumer.directory,stdio:'inherit',timeout:120000});
 await fs.cp(path.join(consumer.directory,'static-delivery'),path.join(output,'outputs'),{recursive:true});
 console.log(JSON.stringify({node:process.version,archive:file,sourceFree:true,output}));
}finally{await fs.writeFile('.artifacts/static-delivery-consumer-path.txt',consumer.directory);}
