import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
const file='/Users/hyeonjeon/.codex/worktrees/roadmap9-animation/ggactionnewbrand/.artifacts/integration-archives/ggaction-9b3c3eea486b50efa7684890a2e9897f181a0abed73706ed01d689816da9e69a.tgz';
const sha='9b3c3eea486b50efa7684890a2e9897f181a0abed73706ed01d689816da9e69a';
assert.equal(createHash('sha256').update(await readFile(file)).digest('hex'),sha);
const consumer=await preparePackageConsumer({packageSpec:file});
try {
 const lock=JSON.parse(await readFile(new URL('../package-lock.json',import.meta.url)));
 const canvas=lock.packages['node_modules/@napi-rs/canvas'].version;
 execFileSync('npm',['install','--ignore-scripts','--no-audit','--no-fund','@napi-rs/canvas@'+canvas],{cwd:consumer.directory,encoding:'utf8',timeout:120000});
 for(const name of ['static-delivery.mjs','fonts.mjs']) await writeFile(consumer.directory+'/'+name,await readFile(new URL('../scripts/consumers/fixtures/node/'+name,import.meta.url)));
 const code="import{cases}from'./static-delivery.mjs';if(cases.length!==1)throw Error('case count');await cases[0].run();console.log(cases[0].id);";
 const result=execFileSync(process.execPath,['--input-type=module','-e',code],{cwd:consumer.directory,encoding:'utf8',timeout:120000,maxBuffer:1048576});
 const report={node:process.version,canvasPeer:canvas,archive:sha,case:result.trim(),receipt:JSON.parse(await readFile(consumer.directory+'/static-delivery/receipt.json','utf8'))};
 await writeFile(new URL('./combined-static-delivery-'+process.versions.node.split('.')[0]+'.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report));
}finally{await consumer.cleanup();}
