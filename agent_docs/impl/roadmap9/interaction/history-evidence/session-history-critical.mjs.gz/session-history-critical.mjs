import{readFileSync}from'node:fs';import{assertCriticalCoverage,parseCoverageTable,CRITICAL_COVERAGE_FLOORS}from'../scripts/coverage-policy.js';
const log=readFileSync('.artifacts/session-history-cross.log','utf8'),table=parseCoverageTable(log);table.delete('all files');
const floors=Object.fromEntries([...table.keys()].map(file=>[file,CRITICAL_COVERAGE_FLOORS[file]]));
assertCriticalCoverage(log,floors);console.log(JSON.stringify({scope:'Four changed runtime owners only; not the whole source suite',coverage:Object.fromEntries(table),floors,status:'passed'},null,2));
