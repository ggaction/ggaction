from pathlib import Path
import gzip,hashlib,json,subprocess,shutil
root=Path('agent_docs/impl/roadmap9/interaction/history-evidence');root.mkdir(exist_ok=True)
def j(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src','types'],text=True).splitlines();h=hashlib.sha256()
for f in sorted(set(files)):h.update(f.encode()+b'\0'+Path(f).read_bytes()+b'\0')
r={'parent':'eef9ee9ad','sourceCommit':'1eda23341cdd282a7cc7ad61fe18d7b00d078101','authorization':'agent_docs/impl/roadmap9/AUTHORIZATION.json',
 'scope':'Bounded runtime undo/redo/reset restores exact immutable program plus private selection records and linked projections. External replacement has explicit reset/record history and origin. No authoring action, persisted schema, or renderer change.',
 'runtimeAndTypesFingerprint':h.hexdigest(),'checks':{'interactionTypesDiscoveryBoundary':235,'finalHistoryAnnotation':13,'critical':j('.artifacts/session-history-critical.log'),
 'realistic':{'tests':16,'datasets':5,'recipes':3,'path':'test/contracts/realistic-logical-selection.test.js'},'browser':{'tests':3,'dpr':2,'inputs':['mouse annotation drag','touch drag and redo button','keyboard undo','Escape','reset button']},
 'packageBoundaryAndCoveragePolicy':13,'packagePolicyAndFixtureManifest':3,
 'docs':{'initial':{'total':207,'passed':204,'failed':3},'changedOwning':166,'sourcePinned':48,'architecture':1,'images':4,'newSnippet':1,'builtPages':172,'llmArtifacts':1531,'widths':[320,390,768,1440],'axeViolations':0,'manualImageInspection':[320,1440]},
 'installed':[json.JSONDecoder().raw_decode(Path(f'.artifacts/session-history-consumer{n}.log').read_text())[0] for n in (20,22,24)]},
 'artifact':j('.artifacts/session-history-fixed.json'),'node20PackageMeasurement':j('.artifacts/session-history-measure20.json'),
 'limits':{'entries':1048,'packedBytes':1487000,'unpackedBytes':6766000,'fullGzip':729300,'basicGzip':384500,'svgGzip':25000,'interactionGzip':114100,'graphGzip':44000,'searchBytes':1028100},
 'preservedFailures':['Basic fixture originally called Full-only editors; replaced it with an explicit valid Basic external snapshot.',
 'History cancel originally passed undo/redo/reset as unsupported gesture reasons; now reuses the existing updateProgram reason.',
 'Initial docs207 had new snippet registration and measured search ceiling failures. Owning166 passes after registration, correct Canvas/example contract and a useful visible annotation example. Initial semantic-only/blank program fixture failures remain in logs.',
 'Package new private owner raised entries1047 to1048; measured packed/unpacked and source-free interaction114086 bytes required minimal cap changes. Node20 same-tar14 runtime+types passed before original bundle cap failed; final cap rechecks those exact measurements. Node22/24 complete commands exit0.',
 'Installed interaction manifest retained only3 older IDs despite executing all case exports. Synchronized all14 current IDs; other fixture entries preserved; exhaustive owning check passed.'],
 'reusedEvidence':'No full normal/source coverage/installed/render sweep claimed. Existing E9 exact Canvas/SVG/PNG/PDF proof remains valid because history restores the same program and graphic references. The final nested transform history assertion reruns13 owning tests; runtime source is unchanged from235-test coverage. Source docs initial failures are distinguished from166 changed owning passes.',
 'remaining':['STEP066 asynchronous layout/assets/worker/player settlement and revision-vector attachment','STEP067 async lifecycle, repeated disposal and cross-owner races','Camera navigation/focus/multiple gesture bindings and final AT39-41/STEP074-077 integration'],
 'commands':{'cross':'node --test --experimental-test-coverage --test-coverage-include=src/interaction/history.js --test-coverage-include=src/interaction/session.js --test-coverage-include=src/interaction/input.js --test-coverage-include=src/interaction/selection.js test/unit/interaction-*.test.js test/contracts/interaction-types.test.js test/contracts/source-boundaries.test.js test/contracts/test-discovery.test.js',
 'realistic':'node scripts/run-tests.js realistic contracts/realistic-logical-selection.test.js with pinned TidyTuesday cache',
 'browser':'node --test --test-name-pattern="canonical annotation dragging|canonical annotation buttons|screen annotation controls" test/browser/interaction-session.browser.js',
 'installed':'Node20/22/24 node .artifacts/session-history-consumer.mjs; same archive cap recheck',
 'docs':'docs:generate; test:docs original; changed owning166; docs:build; test:docs:built; four-width browser/Axe; source-pinned provenance follows source commit'},'evidenceFiles':[]}
for p in sorted(Path('.artifacts').glob('session-history-*')):
 if p.is_file() and p.suffix in ['.log','.mjs','.json','.py']:
  out=root/(p.name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
for p in sorted(Path('.artifacts/interaction-history-docs').glob('*.png')):
 out=root/p.name;shutil.copyfile(p,out);r['evidenceFiles'].append({'path':out.name,'sha256':sha(out)})
(root/'qualification.json').write_text(json.dumps(r,indent=2)+'\n')
