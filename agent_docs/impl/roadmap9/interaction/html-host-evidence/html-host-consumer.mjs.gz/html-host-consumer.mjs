import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {documentationPrograms} from '../scripts/doc-snippets.js';
import {testTutorialConsumers} from '../scripts/tutorial-consumer.js';
const artifact=JSON.parse(await fs.readFile('.artifacts/keyboard-focus-fixed.json','utf8'));
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
try {
 assert.equal(consumer.directory.includes('/roadmap9-paints/'),false);
 const examples=(await documentationPrograms()).filter(example=>example.host==='paired-html');
 assert.deepEqual(examples.map(example=>example.id),['interaction-keyboard','interaction-accessible-tooltip']);
 const evidenceFile=path.resolve('.artifacts/html-host-consumer-receipts.json');
 await testTutorialConsumers(consumer.directory,{examples,evidenceFile});
 const receipts=JSON.parse(await fs.readFile(evidenceFile,'utf8'));
 assert.ok(receipts.every(receipt=>receipt.status==='passed'&&receipt.htmlSha256));
 console.log(JSON.stringify({node:process.version,artifact:artifact.sha256,sourceFree:true,actualChromium:true,receipts}));
} finally {await consumer.cleanup();}
