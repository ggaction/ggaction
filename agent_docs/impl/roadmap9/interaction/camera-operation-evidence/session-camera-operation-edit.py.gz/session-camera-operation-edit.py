from pathlib import Path
p=Path('src/interaction/selection.js');s=p.read_text();a='''    const payload = options(command.payload, [], ["scalePx", "translatePx", "centerDeg", "rotateDeg"], "Projection viewport payload");
    return { program: invoke(program, "editProjection", { ...payload, ...address(target, true) }), affectedOwners };''';b='''    const payload = options(command.payload, [], ["scalePx", "translatePx", "centerDeg", "rotateDeg", "operation"], "Projection viewport payload");
    const operation = Object.hasOwn(payload, "operation");
    if (operation) options(payload, ["operation"], [], "Camera viewport payload");
    return { program: invoke(program, operation ? "navigateProjection" : "editProjection", { ...payload, ...address(target, true) }), affectedOwners };''';assert a in s or b in s;p.write_text(s.replace(a,b))
p=Path('types/interaction.d.ts');s=p.read_text().replace('ProjectionSphereParameters,','ProjectionSphereParameters, GeoCameraOperation,',1);a="/** Nonempty native projection transform patch. Pixel units precede composition and host transforms. */\nexport type InteractionViewportPayload = Pick<ProjectionSphereParameters, 'scalePx' | 'translatePx' | 'centerDeg' | 'rotateDeg'>;";b="""/** Absolute transform patch or one native camera operation, exclusively. Full-only. */
export type InteractionViewportPayload = (Pick<ProjectionSphereParameters, 'scalePx' | 'translatePx' | 'centerDeg' | 'rotateDeg'> & { readonly operation?: never })
  | { readonly operation: GeoCameraOperation; readonly scalePx?: never; readonly translatePx?: never; readonly centerDeg?: never; readonly rotateDeg?: never };""";assert a in s;p.write_text(s.replace(a,b))
for name in ['test/contracts/interaction-types.test.js','scripts/consumers/fixtures/interaction.ts']:
 p=Path(name);s=p.read_text();marker="session.dispatch({type:'setViewport',target:'map',payload:{zoom:2}});";assert marker in s;s=s.replace(marker,marker+"""
session.dispatch({type:'setViewport',target:'map',payload:{operation:{type:'pan',deltaPx:[10,-5]}}});
session.dispatch({type:'setViewport',target:{childPath:['left'],id:'map'},payload:{operation:{type:'zoom',anchorPx:[100,100],factor:2,scaleExtent:[0.5,4]}}});
session.dispatch({type:'setViewport',target:'map',payload:{operation:{type:'resize',canvas:{width:400,height:300},scaling:'preserve'}}});
// @ts-expect-error absolute transform and native operation are mutually exclusive
session.dispatch({type:'setViewport',target:'map',payload:{operation:{type:'pan',deltaPx:[1,2]},scalePx:2}});
// @ts-expect-error anchored zoom requires an explicit scale extent
session.dispatch({type:'setViewport',target:'map',payload:{operation:{type:'zoom',anchorPx:[1,2],factor:2}}});
""");p.write_text(s)
p=Path('agent_docs/impl/roadmap9/interaction/STEP066.md');s=p.read_text();s+='''
## D 최소 공개안 — native camera 명령 전달

`AUTHORIZATION.json` remainingApproval 및 2026-10-29 부모의 명시 방향을 재사용한다.
기존 `setViewport`의 payload에 배타적인 `{operation:GeoCameraOperation}` 경로를 추가한다.
원 절대 transform 네 필드와 operation은 함께 넣을 수 없고 unknown/accessor 입력을 거부한다.
명시 projection `{childPath,id}`를 기존 owner resolver로 찾고 receiver의 `navigateProjection`을
호출한다. Full 정적 import, 새 camera 저장 상태, 중복 pan/zoom 수학은 추가하지 않는다.

원 native pan/anchor zoom/pinch/rotate/fit/reset/resize 결과는 공통 transaction → preparation →
commit/history/frame 경로 하나로 전달한다. 준비 실패·취소에서 원 program/scene/history는 보존하고
늦은 lease는 해제한다. Reset baseline은 host가 `getProjectionView`로 명시 확보한다.
이번 checkpoint는 명령 경로이며 pointer/wheel/pinch gesture와 공개 player 연결은 뒤따른다.
''';p.write_text(s)
