from pathlib import Path
p=Path('agent_docs/contract/current/INTERACTION.md');s=p.read_text();s=s.replace('The command preserves type, clipping, precision and geometry. Basic rejects it.','The command preserves type, clipping, precision and geometry. Alternatively, the entire payload is `{operation:GeoCameraOperation}` and invokes Full `navigateProjection`. Operation and absolute transform fields are mutually exclusive. Pan, anchored zoom, pinch, spherical rotation, fit, explicit reset and resize use the native camera contract without a second stored camera. Basic rejects both paths.',1)
a='''`setViewport` delegates validation and materialization to `editProjection`, retaining geometry identity,
feature selection keys and native projection revision semantics. Its payload accepts only `scalePx`,
`translatePx`, `centerDeg` and `rotateDeg`; at least one must be present. Invalid values, unsupported
projection parameters, unknown targets and later dependent failures preserve the previous program,
trace, scene and revision. The command does not derive level-of-detail zoom or cursor anchoring.

Host buttons or typed controls may send absolute transform patches and redraw the committed program.
They retain native keyboard activation and focus. Existing scope routing permits explicit child
projection targets. No navigation listeners, animation or camera state are installed.'''
b='''`setViewport` delegates validation and materialization to the existing Full native owners, retaining
geometry identity, feature selection keys and projection revision semantics. Use either a nonempty
absolute patch with `scalePx`, `translatePx`, `centerDeg` and `rotateDeg`, or the exclusive payload
`{operation:GeoCameraOperation}`. The former invokes `editProjection`; the latter invokes
`navigateProjection` with its existing pan, inverse-anchored zoom, pinch, spherical rotation, fit,
explicit reset and resize contract. All pixel coordinates precede composition and host transforms.
An operation cannot accompany an absolute transform field, and unknown fields reject.

The target is always one explicit projection ID or `{childPath,id}`; the session never chooses another
projection or child. The host obtains reset parameters through `getProjectionView` and supplies them
explicitly. No second camera baseline is stored. The complete native action and dependent closure form
one transaction and history entry, including a resize that edits both Canvas and projection.
Invalid values, unsupported parameters, unknown targets and later dependent failures preserve the
previous program, trace, scene and revision. Asset preparation precedes commit; cancellation or failure
preserves committed program, current frame and history together, while late leases are disposed once.

Host buttons or typed controls may send either payload and redraw the committed program. They retain
native keyboard activation and focus. No pointer navigation listeners, animation or level-of-detail
zoom inference are installed by this direct command.''';assert a in s;s=s.replace(a,b);p.write_text(s)
p=Path('docs/api/interaction.md');s=p.read_text();start=s.index('## Adjust a geographic view from host controls');end=s.index('## Move graph nodes with pointer or keyboard',start);part=s[start:end];part=part.replace('It preserves the geometry resource and feature selection identities.','It preserves the geometry resource and feature selection identities.\n\nAlternatively, pass only `{operation}` to use [native camera operations](../geometry.md#navigateprojection):\npan, anchored zoom, pinch, spherical rotation, fit, reset or resize. The operation and absolute transform\nfields cannot be combined. One successful command adds one history entry, including Canvas resize.\nCapture reset parameters explicitly with `getProjectionView`; the session does not infer a home view.')
part=part.replace('import { createInteractionSession } from "ggaction/interaction";','import { createInteractionSession } from "ggaction/interaction";\nimport { getProjectionView } from "ggaction/inspection";')
a='''const transform = current => {
  const projection = current.semanticSpec.resources.find(resource => resource.kind === "projection" && resource.id === "map");
  return { ...projection.options, ...projection.result };
};''';b='''const transform = current => getProjectionView(current, { target: "map" }).parameters;
const initial = transform(program);''';assert a in part;part=part.replace(a,b)
a='''const move = payload => viewportSession.dispatch({ type: "setViewport", target: "map", payload, origin: "user" });
const pan = () => { const { translatePx: [x, y] } = transform(viewportSession.getState().program); move({ translatePx: [x + 20, y] }); };
const zoom = () => move({ scalePx: transform(viewportSession.getState().program).scalePx * 2 });
const home = () => move({ scalePx: 1, translatePx: [0, 0] });''';b='''const move = operation => viewportSession.dispatch({ type: "setViewport", target: "map", payload: { operation }, origin: "user" });
const pan = () => move({ type: "pan", deltaPx: [20, 0] });
const zoom = () => move({ type: "zoom", anchorPx: [80, 70], factor: 2, scaleExtent: [0.5, 8] });
const home = () => move({ type: "reset", initial });''';assert a in part;part=part.replace(a,b)
a='''For a projection in a composed child, use `{childPath,id}`. The nonempty patch accepts only the four
transform fields above; it does not change projection type, clipping, geometry or level of detail.
Native buttons keep focus and their usual keyboard behavior. This direct command does not install
pointer pan or pinch gestures, infer cursor anchoring, or animate the change. It requires Full authoring.''';b='''For a projection in a composed child, use `{childPath,id}`. Zoom and pinch anchors use native local
projection pixels; convert a host pointer into that coordinate space before dispatching. The native
operation validates inverse visibility and the explicit scale extent. Reset uses the captured parameters.
Both payload forms preserve geometry and level of detail. Native buttons keep focus and keyboard behavior.
Preparation failure or cancellation keeps the committed program, frame and history unchanged. This direct
command requires Full authoring and does not install pointer gestures or animate the change.''';assert a in part;part=part.replace(a,b);s=s[:start]+part+s[end:];p.write_text(s)
p=Path('test/browser/interaction-session.browser.js');s=p.read_text();start=s.index('test("host viewport buttons');end=s.index('\n});',start)+4;part=s[start:end].replace('[["ggaction", "index"], ["ggaction/interaction", "interaction"]]','[["ggaction", "index"], ["ggaction/interaction", "interaction"], ["ggaction/inspection", "inspection"]]').replace('[[140,140],[260,220]]','[[80,70],[200,150]]');s=s[:start]+part+s[end:];p.write_text(s)
p=Path('test/support/scenarios/region-interaction.js');s=p.read_text();a='''  assert.equal(serializeProgram(p), before); session.destroy();
}


function assertNodeMovementSource''';b='''  // A native camera operation consumes the same real source features and item identities.
  const anchor = [rows[0].order * scalePx + translatePx[0], rows[0].value * scalePx + translatePx[1]];
  const factor = recipe === "observations" ? 1.5 : recipe === "categories" ? 2 : 0.5;
  session.dispatch({ type: "setViewport", target: "map", payload: { operation: { type: "zoom", anchorPx: anchor, factor, scaleExtent: [0.1, 10] } } });
  const zoomed = getMarkItems(session.getState().program, { target: "places" });
  for (const [index, item] of zoomed.entries()) {
    assert.equal(item.key, original[index].key);
    const expected = [anchor[0] + (items[index].properties.x - anchor[0]) * factor,
      anchor[1] + (items[index].properties.y - anchor[1]) * factor];
    assert.ok(Math.abs(item.properties.x - expected[0]) < 1e-8);
    assert.ok(Math.abs(item.properties.y - expected[1]) < 1e-8);
  }
  assert.deepEqual(deserializeProgram(serializeProgram(session.getState().program)).graphicSpec, session.getState().program.graphicSpec);
  assert.equal(serializeProgram(p), before); session.destroy();
}


function assertNodeMovementSource''';assert a in s;s=s.replace(a,b);p.write_text(s)
