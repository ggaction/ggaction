import assert from 'node:assert/strict';
import {readFile,writeFile,realpath} from 'node:fs/promises';
import path from 'node:path';
import {build,preview} from 'vite';
import {chromium} from 'playwright';
import {preparePackageConsumer} from '../scripts/package-consumer.js';
import {documentationPrograms} from '../scripts/doc-snippets.js';
const artifact=JSON.parse(await readFile('.artifacts/context-controls-fixed.json','utf8'));
const snippet=(await documentationPrograms()).find(example=>example.id==='interaction-parameter-context');assert.ok(snippet);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});consumer.directory=await realpath(consumer.directory);let server,browser;
try{
 await writeFile(path.join(consumer.directory,'index.html'),'<html lang="en"><head><title>Parameter and context controls</title></head><body><canvas id="chart" aria-label="Adjustable points"></canvas><script type="module" src="/main.js"></script></body></html>');
 await writeFile(path.join(consumer.directory,'main.js'),snippet.code+'\nwindow.controls={session:parameterSession,dispose:disposeControls};');
 await build({root:consumer.directory,logLevel:'silent',build:{target:'esnext'}});server=await preview({root:consumer.directory,logLevel:'silent',preview:{host:'127.0.0.1',port:0}});
 browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(server.resolvedUrls.local[0]);await page.waitForFunction(()=>window.controls);
 await page.getByRole('slider',{name:'Multiplier'}).focus();await page.keyboard.press('ArrowRight');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),1);
 const point=await page.evaluate(()=>{const n=window.controls.session.getState().scene.nodes.find(n=>n.type==='circle');return{x:n.offset[0]+n.properties.x,y:n.offset[1]+n.properties.y};});const box=await page.locator('canvas').boundingBox();
 await page.mouse.click(box.x+point.x,box.y+point.y,{button:'right'});assert.equal(await page.evaluate(()=>document.activeElement.id),'select-context');await page.keyboard.press('Enter');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().revision),2);assert.equal(await page.evaluate(()=>document.activeElement.id),'multiplier');
 assert.equal(await page.evaluate(()=>window.controls.session.getState().scene.nodes.filter(n=>n.type==='circle'&&n.properties.fill==='red').length),1);
 await page.evaluate(()=>window.controls.dispose());assert.deepEqual(errors,[]);
 console.log(JSON.stringify({node:process.version,archive:artifact.sha256,id:snippet.id,sourceFree:true,parameterRevision:1,selectionRevision:2,selectedCount:1,focus:'multiplier',disposed:true,errors:[]}));
}finally{await browser?.close();if(server)await new Promise(resolve=>server.httpServer.close(resolve));await consumer.cleanup();}
