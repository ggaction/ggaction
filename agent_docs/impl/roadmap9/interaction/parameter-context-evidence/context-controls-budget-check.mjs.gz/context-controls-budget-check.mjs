import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {BROWSER_BUNDLE_GZIP_LIMITS} from '../scripts/browser-bundle-size.js';
const raw=await readFile('.artifacts/context-controls-consumer20-measured.log','utf8');
const value=JSON.parse(raw.slice(0,raw.indexOf('\nnode:internal')));
for(const bundle of value.bundles) assert.ok(bundle.gzipBytes <= BROWSER_BUNDLE_GZIP_LIMITS[bundle.specifier], JSON.stringify(bundle));
value.budgetValidation='Passed against minimally updated limits after the preserved measurement failure; runtime and types are the same completed Node20 run.';
await writeFile('.artifacts/context-controls-final-consumer20.log',JSON.stringify(value,null,2)+'\n');
console.log(JSON.stringify({artifact:value.artifact,node:value.node,passed:true,limits:BROWSER_BUNDLE_GZIP_LIMITS}));
