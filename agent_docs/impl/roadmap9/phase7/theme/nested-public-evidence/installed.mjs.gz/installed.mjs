import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {preparePackageConsumer} from '../../scripts/package-consumer.js';
import {testOptionalDependencies} from '../../scripts/consumers/optional-peers.js';
import {testTypeScriptConsumer} from '../../scripts/consumers/types.js';
import {measureMinimalBrowserBundle,BROWSER_BUNDLE_GZIP_LIMITS} from '../../scripts/browser-bundle-size.js';
import {run,runConsumerCases} from '../../scripts/consumers/runtime.js';
const artifact=JSON.parse(await readFile(new URL('./final-package.json',import.meta.url),'utf8'));
const receipt=new URL(`./installed-node${process.versions.node.split('.')[0]}.json`,import.meta.url);
const consumer=await preparePackageConsumer({packageSpec:artifact.file});
try{
  const results=await runConsumerCases([
    {id:'optional-peers',run:()=>testOptionalDependencies(consumer)},
    {id:'nested-responsive-public',async run(){
      await writeFile(path.join(consumer.directory,'nested-responsive-public.js'),(await readFile(new URL('../../examples/nested-responsive/program.js',import.meta.url),'utf8')).replace('"../../src/index.js"','"ggaction"'));
      await writeFile(path.join(consumer.directory,'nested-responsive.mjs'),await readFile(new URL('../../scripts/consumers/fixtures/node/nested-responsive.mjs',import.meta.url)));
      await writeFile(path.join(consumer.directory,'nested-runner.mjs'),`import {writeFile} from 'node:fs/promises';import {cases} from './nested-responsive.mjs';const records=[];for(const entry of cases){await entry.run();records.push({id:entry.id,status:'passed'});}await writeFile('nested-cases.json',JSON.stringify(records));`);
      run(process.execPath,['nested-runner.mjs'],consumer.directory);
      return JSON.parse(await readFile(path.join(consumer.directory,'nested-cases.json'),'utf8'));
    }},
    {id:'types',run:()=>testTypeScriptConsumer(consumer.directory)},
    ...['ggaction','ggaction/basic','ggaction/svg','ggaction/interaction'].map(specifier=>({id:`bundle:${specifier}`,async run(){const result=await measureMinimalBrowserBundle(consumer.directory,{specifier});assert.ok(result.gzipBytes<=BROWSER_BUNDLE_GZIP_LIMITS[specifier],JSON.stringify(result));return result;}}))
  ],receipt.pathname);
  await writeFile(new URL(`./installed-node${process.versions.node.split('.')[0]}-details.json`,import.meta.url),JSON.stringify({node:process.version,sha256:artifact.sha256,peers:consumer.resolvedPeers,results},null,2));
}finally{await consumer.cleanup();}
