import {isSizeShapeChannels} from "../../../grammar/legendCombinations.js";
import { normalizeLegendOrder } from "../../../grammar/categoryOrder.js";
import { validateUserId } from "../../../core/identifiers.js";
import { CATEGORICAL_LEGEND_CHANNELS } from "../../../core/vocabulary.js";
import { validateNonEmptySemanticString } from "./shared.js";
import { validateParallelAxisTitles } from "../../../grammar/parallelAxisTitles.js";

function validateLegend(property, value) {
  if (property === "title") {
    validateNonEmptySemanticString(value, "Legend title");
    return;
  }
  if (!Array.isArray(value) || value.length === 0) {
    throw new TypeError(`Legend ${property} must be a non-empty array.`);
  }
  if (new Set(value).size !== value.length) {
    throw new Error(`Legend ${property} must not contain duplicates.`);
  }
  if (property === "channels") {
    if (!isSizeShapeChannels(value) && !value.every(channel => CATEGORICAL_LEGEND_CHANNELS.includes(channel))) {
      throw new Error("Legend channels support only color, strokeDash, and shape.");
    }
    return;
  }
  for (const id of value) validateUserId(id, "Legend scale id");
}

export function validateGuideSemanticValue(_program, parsed, value) {
  const property = parsed.path.at(-1);
  if (parsed.id === "legend.colorSize") {
    if(property === "title") validateNonEmptySemanticString(value,"Legend title");
    else if(property === "colorChannel") { if(!["color","stroke"].includes(value))throw new Error("Combined legend colorChannel requires color or stroke."); }
    else validateUserId(value,"Legend scale id");
    return;
  }
  if (parsed.id === "axis.parallel" && property === "titles") {
    validateParallelAxisTitles(value);
    return;
  }
  if (["legend.series", "legend.color", "legend.stroke"].includes(parsed.id) && property === "order") {
    normalizeLegendOrder(value);
    return;
  }
  if (parsed.id === "legend.series") {
    validateLegend(property, value);
    return;
  }
  if (!parsed.id.startsWith("grid.") && !parsed.id.startsWith("axis.")) return;
  if (parsed.id === "axis.parallel" && property === "scales") {
    if (!Array.isArray(value) || value.length < 2) {
      throw new TypeError("Parallel axis scales must contain at least two ids.");
    }
    value.forEach(id => validateUserId(id, "Parallel axis scale id"));
  } else if (parsed.id.startsWith("axis.") && property === "channel") {
    if (!["x", "y"].includes(value)) throw new Error("Named Cartesian axis channel requires x or y.");
  } else if (parsed.id.startsWith("axis.") && property === "position") {
    if (!["top", "bottom", "left", "right"].includes(value)) throw new Error("Named Cartesian axis position requires a physical side.");
  } else if (property === "title") {
    validateNonEmptySemanticString(value, "Axis title");
  } else {
    const guideKind = parsed.id.startsWith("grid.") ? "Grid" : "Axis";
    validateUserId(value, `${guideKind} ${property} id`);
  }
}
