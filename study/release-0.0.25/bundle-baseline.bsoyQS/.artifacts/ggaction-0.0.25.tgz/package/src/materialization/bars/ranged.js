import { resolveBarCellOpacities } from "./resolve.js";
import {
  mapContinuousScaleValues,
  mapOrdinalPositionValues,
  mapOrdinalValues,
  readScaleField
} from "../../grammar/scales/index.js";
import { mapScaleConsumerValues } from "../scales/map.js";
import { resolveBarWidth } from "../../grammar/bars/geometry.js";
import { BAR_GRAINS, resolveBarChannels, resolveBarGrain } from "../../grammar/bars/policy.js";
import {
  DEFAULT_BAR_FILL,
  DEFAULT_BAR_STROKE,
  resolveBarAppearance
} from "./resolve.js";

export function deriveRangedRectangles(required, program, width) {
  const { layer, dataset } = required;
  if (width?.interval !== undefined) throw new Error("Bar interval width requires ungrouped aggregate temporal categories.");
  const centered = resolveBarGrain(layer) === BAR_GRAINS.centered;
  const vertical = centered ? resolveBarChannels(layer).orientation === "vertical" : layer.encoding?.y2 !== undefined;
  const categoryChannel = vertical ? "x" : "y";
  const measureChannel = vertical ? "y" : "x";
  const secondaryChannel = `${measureChannel}2`;
  const category = layer.encoding[categoryChannel];
  const primary = layer.encoding[measureChannel];
  const secondary = layer.encoding[secondaryChannel];
  const categoryScale = program.resolvedScales[category.scale];
  const measureScale = program.resolvedScales[primary.scale];
  const categoryValues = readScaleField(dataset.values, category.field, category.fieldType, {
    temporalUnit: category.temporalUnit
  });
  const centers = (centered || categoryScale.type === "time" ? mapContinuousScaleValues : mapOrdinalPositionValues)(
    categoryValues, categoryScale
  );
  const first = mapContinuousScaleValues(
    dataset.values.map(row => row[primary.field]),
    measureScale
  );
  const second = mapContinuousScaleValues(
    dataset.values.map(row => secondary === undefined ? 0 : row[secondary.field]),
    measureScale
  );
  if (centered && width?.band !== undefined) throw new Error("Numeric-center bars require pixel width.");
  const band = resolveBarWidth(centered ? width ?? { pixels: 5 } : width, Math.abs(categoryScale.bandwidth ?? categoryScale.step));
  const config = program.markConfigs[layer.id] ?? {};
  const appearance = config.barAppearance ?? {};
  const color = layer.encoding?.color;
  const fills = color === undefined
    ? dataset.values.map(() => appearance.fill ?? config.fill ?? DEFAULT_BAR_FILL)
    : mapOrdinalValues(dataset.values.map(row => row[color.field]), program.resolvedScales[color.scale].domain, program.resolvedScales[color.scale].range);
  const appearanceConfig = color === undefined
    ? config
    : { ...config, stroke: undefined };
  const stroke = layer.encoding?.stroke;
  const strokes = stroke === undefined ? undefined : mapScaleConsumerValues(
    readScaleField(dataset.values, stroke.field, stroke.fieldType, {
      temporalUnit: stroke.temporalUnit
    }),
    program.resolvedScales[stroke.scale],
    "stroke"
  );
  const opacities = resolveBarCellOpacities(program, layer, dataset.values.map(row => [row]));
  return dataset.values.map((_, index) => vertical ? {
    x: centers[index] - band / 2, y: Math.min(first[index], second[index]), width: band,
    height: Math.abs(second[index] - first[index]), fill: fills[index],
    ...resolveBarAppearance(
      appearanceConfig,
      undefined,
      color === undefined ? DEFAULT_BAR_STROKE : fills[index],
      1
    ),
    ...(strokes === undefined ? {} : { stroke: strokes[index] }),
    ...(opacities === undefined ? {} : { opacity: opacities[index] })
  } : {
    x: Math.min(first[index], second[index]), y: centers[index] - band / 2,
    width: Math.abs(second[index] - first[index]), height: band, fill: fills[index],
    ...resolveBarAppearance(
      appearanceConfig,
      undefined,
      color === undefined ? DEFAULT_BAR_STROKE : fills[index],
      1
    ),
    ...(strokes === undefined ? {} : { stroke: strokes[index] }),
    ...(opacities === undefined ? {} : { opacity: opacities[index] })
  });
}
