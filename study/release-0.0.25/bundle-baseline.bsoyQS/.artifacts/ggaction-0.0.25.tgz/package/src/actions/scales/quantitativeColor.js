import { editScaleForEncoding } from "./edit.js";
import { closedAction } from "../../core/action.js";

import { findSemanticScale } from "../../selectors/scales.js";

const OPTIONS = Object.freeze([
  "id",
  "type",
  "domain",
  "range",
  "interpolate", "whitePoint", "gamma", "midpoint", "base", "exponent", "constant",
  "clamp",
  "reverse",
  "unknown"
]);

export const setQuantitativeColorScale = /* @__PURE__ */ closedAction(
  {
    op: "setQuantitativeColorScale",
    description: "Create or update an internal quantitative color scale."
  }, OPTIONS,
  function (args = {}) {
    if (!["sequential", "log", "pow", "sqrt", "symlog", "quantize", "quantile", "threshold"].includes(args.type)) {
      throw new Error(`Unsupported quantitative color scale type "${args.type}".`);
    }
    const existing = findSemanticScale(this, args.id);
    if (existing !== undefined && existing.type !== args.type) {
      return editScaleForEncoding(this, args);
    }
    let next = this;
    for (const property of ["whitePoint", "gamma"]) {
      if (existing?.[property] !== undefined && args[property] === undefined) {
        next = next.editSemantic({ property: `scale[${args.id}].${property}`, remove: true });
      }
    }
    if (existing?.midpoint !== undefined && args.midpoint === undefined) {
      next = next.editSemantic({ property: `scale[${args.id}].midpoint`, remove: true });
    }
    for (const property of [
      "type", "domain", "range", "interpolate", "whitePoint", "gamma", "midpoint", "base", "exponent", "constant", "clamp", "reverse", "unknown"
    ]) {
      if (!Object.hasOwn(args, property)) continue;
      if (existing?.[property] === args[property]) continue;
      next = next.editSemantic({
        property: `scale[${args.id}].${property}`,
        value: args[property]
      });
    }
    return next;
  }
);
