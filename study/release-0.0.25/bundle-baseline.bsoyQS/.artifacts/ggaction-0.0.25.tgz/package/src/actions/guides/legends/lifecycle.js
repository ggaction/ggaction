import {
  legendGraphicIds, legendResourcePolicy, legendResourcePolicies
} from "../../../materialization/guides/resources.js";
import { findLayer } from "../../../selectors/layers.js";
import { resolveDefinition } from "./categorical/resolve.js";
import { normalizeRecipe, resolveLegendSymbol } from "./categorical/recipes.js";
import { resolveLayout, symbolGraphic } from "./categorical/layout.js";
import { resolveLegendGraphicPlacement } from "../../../materialization/graphicHierarchy.js";

export function removeLegendKinds(program, kinds) {
  const removed = new Set(kinds);
  const retainedSemanticKinds = new Set(
    Object.entries(program.guideConfigs.legend ?? {})
      .filter(([kind]) => !removed.has(kind))
      .map(([kind]) => legendResourcePolicy(kind).semanticKind)
  );
  const semanticKinds = new Set(
    kinds.map(kind => legendResourcePolicy(kind).semanticKind)
  );
  let next = program;
  for (const kind of semanticKinds) {
    if (
      !retainedSemanticKinds.has(kind) &&
      next.semanticSpec.guides.legend?.[kind] !== undefined
    ) {
      next = next.editSemantic({
        property: `guide.legend.${kind}`,
        remove: true
      });
    }
  }
  for (const id of new Set(kinds.flatMap(legendGraphicIds))) {
    if (next.graphicSpec.objects[id] !== undefined) {
      next = next.editGraphics({ target: id, remove: true });
    }
  }
  for (const kind of kinds) {
    next = next._withoutMaterializationConfig(["guides", "legend", kind]);
  }
  return next;
}

export function resolveCategoricalLegendRevision(program, kind, previous, channels, {
  order = program.semanticSpec.guides.legend?.[kind]?.order, validateLayout = true, preferredKind
} = {}) {
  const layer = findLayer(program, previous.target);
  const definition = resolveDefinition(program, layer, channels,
    previous.inferredTitle ? undefined : previous.title, order, preferredKind);
  const {combine: _combine, sizeAreas: _areas, ...shared} = previous;
  const config = {
    ...shared,
    ...definition,
    symbol: normalizeRecipe(resolveLegendSymbol(
      program,
      layer,
      channels,
      previous.inferredSymbol ? undefined : previous.symbol,
      definition.kind
    ), definition.kind, { internal: previous.inferredSymbol })
  };
  if (validateLayout) resolveLayout(program, config);
  return { kind, config, order };
}

export function createCategoricalLegendFromConfig(program, config, order) {
  const { kind } = config;
  let next = program;
  if (kind === "series") {
    next = next
      .editSemantic({
        property: "guide.legend.series.channels",
        value: config.channels
      })
      .editSemantic({
        property: "guide.legend.series.scales",
        value: config.scales
      })
      .editSemantic({
        property: "guide.legend.series.title",
        value: config.title
      });
  } else {
    next = next
      .editSemantic({
        property: `guide.legend.${kind}.scale`,
        value: config.scales[0]
      })
      .editSemantic({
        property: `guide.legend.${kind}.title`,
        value: config.title
      });
  }
  if (order !== undefined && order !== "scale") {
    next = next.editSemantic({
      property: `guide.legend.${kind}.order`,
      value: order
    });
  }
  next = next._withLegendConfig(kind, config);
  if (config.border !== false) {
    next = next.createLegendBackground({ kind });
  }
  next = next
    .createLegendSymbols({ kind })
    .createLegendLabels({ kind });
  return config.titleVisible === false
    ? next
    : next.createLegendTitle({ kind });
}

// Categorical content precedes its sampled companions in both creation and revision.
export function resolveCategoricalLegendPlacement(program) {
  const companions = new Set(legendResourcePolicies()
    .filter(policy => policy.family !== "categorical" && program.guideConfigs.legend?.[policy.kind] !== undefined)
    .flatMap(policy => legendGraphicIds(policy.kind)));
  const before = program.graphicSpec.objects.canvas?.children?.find(id => companions.has(id));
  return resolveLegendGraphicPlacement(program, before === undefined ? {} : { before });
}

export function categoricalSymbolIds(config) {
  return new Set(config.symbol.layers.map(layer => symbolGraphic(config, layer.type)));
}

export function reconcileCategoricalSymbols(program, previous, config) {
  const oldSymbols = categoricalSymbolIds(previous);
  const newSymbols = categoricalSymbolIds(config);
  const sameOrder = oldSymbols.size === newSymbols.size &&
    [...oldSymbols].every((id, index) => id === [...newSymbols][index]);
  let next = program;
  if (!sameOrder) {
    for (const id of oldSymbols) {
      if (next.graphicSpec.objects[id] !== undefined) {
        next = next.editGraphics({ target: id, remove: true });
      }
    }
  }
  for (const layer of config.symbol.layers) {
    if (next.graphicSpec.objects[symbolGraphic(config, layer.type)] === undefined) {
      const suffix = { line: "Lines", point: "Points", swatch: "Swatches" }[layer.type];
      next = next[`createLegendSymbol${suffix}`]({ kind: config.kind });
    }
  }
  return next;
}
