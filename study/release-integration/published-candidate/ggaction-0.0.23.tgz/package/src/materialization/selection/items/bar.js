import { hasRectRadius } from "../../../grammar/roundedRect.js";
import { deriveSeriesBarCells } from "../../../grammar/bars/aggregate.js";
import { readSeriesIdentity } from "../../../grammar/pathSeries.js";
import {
  BAR_GRAINS,
  resolveBarChannels,
  resolveBarColorLayout,
  resolveBarOffsetChannel,
  resolveBarGrain
} from "../../../grammar/bars/policy.js";
import { numericExtent } from "../../../grammar/numeric.js";
import {
  readNominalField,
  readScaleField,
  readTemporalField
} from "../../../grammar/scales/index.js";
import { findSemanticScale } from "../../../selectors/scales.js";
import { deriveHistogramSegments } from "../../bars/histogram.js";
import {
  channelMapFromRow,
  finalizeItems,
  itemKey,
  ownFields,
  uniqueFields
} from "./common.js";

function categoryValues(rows, encoding) {
  return encoding.fieldType === "temporal"
    ? readTemporalField(rows, encoding.field, encoding.temporalUnit)
    : readNominalField(rows, encoding.field);
}

function aggregateMembers(rows, layer, cell, channels) {
  const category = layer.encoding[channels.category];
  const categories = categoryValues(rows, category);
  const categoryValue = cell[channels.category];
  const color = layer.encoding?.color;
  const colors = !["nominal", "ordinal"].includes(color?.fieldType)
    ? undefined
    : readNominalField(rows, color.field);
  const identity = layer.encoding?.group === undefined ? undefined : readSeriesIdentity(rows, layer);
  return rows.filter((_, index) =>
    categories[index] === categoryValue &&
    (identity === undefined ? colors === undefined || colors[index] === cell.color : identity.values[index] === cell.series)
  );
}

function aggregateCellDefinitions(program, layer, dataset) {
  const channels = resolveBarChannels(layer);
  const categoryEncoding = layer.encoding[channels.category];
  const categoryScale = program.resolvedScales[categoryEncoding.scale];
  const colorEncoding = layer.encoding?.color;
  const colorScale = program.resolvedScales[colorEncoding?.scale];
  const offsetChannel = resolveBarOffsetChannel(layer);
  const offsetScale = program.resolvedScales[layer.encoding?.[offsetChannel]?.scale];
  const layout = resolveBarColorLayout(layer);
  const stroke = layer.encoding?.stroke;

  function definition(cell, start, end) {
    const members = aggregateMembers(dataset.values, layer, cell, channels);
    const strokeValues = stroke === undefined ? undefined : readScaleField(
      members,
      stroke.field,
      stroke.fieldType,
      { temporalUnit: stroke.temporalUnit }
    );
    if (strokeValues !== undefined && new Set(strokeValues).size !== 1) {
      throw new Error("Bar stroke requires one value within each aggregate cell.");
    }
    return {
      fields: uniqueFields(members),
      channels: {
        [channels.category]: cell[channels.category],
        [channels.measure]: start,
        [`${channels.measure}2`]: end,
        ...(cell.color === undefined ? {} : { color: cell.color }),
        ...(strokeValues === undefined ? {} : { stroke: strokeValues[0] }),
        ...(layer.encoding?.[offsetChannel] === undefined
          ? {}
          : { [offsetChannel]: cell.series ?? cell.color })
      },
      members
    };
  }

  const categories = categoryScale.type === "time" ? undefined : categoryScale.domain;
  const series = layout === "group" ? offsetScale?.domain
    : layer.encoding.group === undefined && colorEncoding?.fieldType !== "quantitative" ? colorScale?.domain : undefined;
  return deriveSeriesBarCells(dataset.values, layer, categories, series)
    .map(({ cell, start, end }) => definition(cell, start, end));
}

function histogramDefinitions(program, layer, dataset) {
  const xEncoding = layer.encoding.x;
  const colorEncoding = layer.encoding?.color;
  const segments = deriveHistogramSegments({
    dataset,
    layer,
    xEncoding,
    xScale: findSemanticScale(program, xEncoding.scale),
    resolvedScales: program.resolvedScales
  });
  const colorScale = program.resolvedScales[colorEncoding?.scale];
  const stroke = layer.encoding?.stroke;
  return segments.map(segment => {
    const colorValue = segment.colorValue ?? colorScale?.domain[segment.category];
    const strokeValues = stroke === undefined ? undefined : readScaleField(
      segment.members,
      stroke.field,
      stroke.fieldType,
      { temporalUnit: stroke.temporalUnit }
    );
    if (strokeValues !== undefined && new Set(strokeValues).size !== 1) {
      throw new Error("Histogram stroke requires one value within each bin/series cell.");
    }
    return {
      fields: uniqueFields(segment.members),
      channels: {
        x: segment.start,
        x2: segment.end,
        y: segment.stackStart,
        y2: segment.stackEnd,
        ...(colorValue === undefined ? {} : { color: colorValue }),
        ...(strokeValues === undefined ? {} : { stroke: strokeValues[0] })
      },
      members: segment.members
    };
  });
}

function rangedDefinitions(layer, dataset) {
  const measure = resolveBarGrain(layer) === BAR_GRAINS.centered ? resolveBarChannels(layer).measure : undefined;
  return dataset.values.map(row => ({
    fields: ownFields(row),
    channels: { ...channelMapFromRow(row, layer),
      ...(measure !== undefined && layer.encoding[`${measure}2`] === undefined
        ? { [measure]: 0, [`${measure}2`]: row[layer.encoding[measure].field] } : {}) },
    members: [row]
  }));
}

function sharedChannels(definitions) {
  if (definitions.length === 0) return {};
  const shared = { ...definitions[0].channels };
  for (const channel of Object.keys(shared)) {
    if (!definitions.every(definition =>
      definition.channels[channel] === shared[channel]
    )) delete shared[channel];
  }
  return shared;
}

function barStackDefinitions(layer, barGrain, definitions) {
  const layout = resolveBarColorLayout(layer);
  if (!["stack", "fill", "diverging"].includes(layout)) {
    throw new Error(
      `Bar mark "${layer.id}" does not define stacked items at its current "${layout}" layout.`
    );
  }
  if (barGrain === BAR_GRAINS.ranged) {
    throw new Error(`Ranged bar mark "${layer.id}" has no stack grain.`);
  }
  const channels = resolveBarChannels(layer);
  const categoryChannels = barGrain === BAR_GRAINS.histogram
    ? ["x", "x2"]
    : [channels.category];
  const measure = channels.measure;
  const secondary = `${measure}2`;
  const groups = new Map();
  definitions.forEach((definition, index) => {
    const key = JSON.stringify(categoryChannels.map(channel =>
      definition.channels[channel]
    ));
    const group = groups.get(key) ?? [];
    group.push({ definition, index });
    groups.set(key, group);
  });

  return [...groups.values()].map((entries, index) => {
    const grouped = entries.map(entry => entry.definition);
    const endpoints = grouped.flatMap(definition => [
      definition.channels[measure],
      definition.channels[secondary]
    ]).filter(Number.isFinite);
    if (endpoints.length === 0) {
      throw new Error(
        `Bar mark "${layer.id}" stack ${index} has no resolved semantic endpoints.`
      );
    }
    const [minimum, maximum] = numericExtent(endpoints);
    const members = grouped.flatMap(definition => definition.members);
    return {
      key: itemKey(layer, "stack", index),
      fields: uniqueFields(members),
      channels: {
        ...sharedChannels(grouped),
        [measure]: minimum,
        [secondary]: maximum
      },
      members,
      graphicIndices: entries.map(entry => entry.index)
    };
  });
}

export function resolveBarItems(program, layer, dataset, selectionGrain) {
  const grain = resolveBarGrain(layer);
  const definitions = grain === BAR_GRAINS.histogram
    ? histogramDefinitions(program, layer, dataset)
    : grain === BAR_GRAINS.aggregate
      ? aggregateCellDefinitions(program, layer, dataset)
      : [BAR_GRAINS.ranged, BAR_GRAINS.centered].includes(grain)
        ? rangedDefinitions(layer, dataset)
        : undefined;
  if (definitions === undefined) {
    throw new Error(`Bar mark "${layer.id}" is incomplete for selection.`);
  }
  const graphicTypes = hasRectRadius(program.markConfigs[layer.id]?.barAppearance) ? ["rect", "path"] : "rect";
  if (selectionGrain === "stack") {
    return finalizeItems(
      program,
      layer,
      "stack",
      barStackDefinitions(layer, grain, definitions),
      graphicTypes
    );
  }
  return finalizeItems(program, layer, grain, definitions, graphicTypes);
}
